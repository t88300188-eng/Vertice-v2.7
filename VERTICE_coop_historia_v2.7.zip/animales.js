/*!
 * VÉRTICE · Animales (animales.js, v2.3)
 *
 * Perros, gatos, vacas, cerdos, ratas, ovejas, pájaros y conejos viven por el mapa (modo libre e historia).
 *  - SANOS (todas las modalidades): deambulan, pastan y huyen de ti, de los disparos, de los coches y de los infectados.
 *    Los perros son curiosos (se acercan a mirarte y ladran), los pájaros echan a volar, los conejos huyen en zigzag y los rebaños se asustan juntos.
 *  - INFECTADOS (solo en modalidad Difícil): te ven, te oyen, te persiguen y muerden. Cada especie tiene su truco:
 *    perros en manada, gatos y conejos que saltan encima, vaca que embiste, ratas en enjambre, pájaros que se lanzan en picado.
 *  - Reciben balas, golpes, explosiones, fuego, aturdidoras y atropellos como cualquier infectado (index.html / historia.html
 *    los incluyen en `G.animalFoes()`). Los infectados cuentan como bajas; los sanos no.
 *  - Aparecen alrededor del jugador (a 28-68 m, fuera de su vista) y se retiran al alejarse: pocas mallas y pocos cálculos.
 *  - Ajustes → «Animales»: Muchos / Pocos / Sin animales (se guarda con los ajustes).
 *  - En cooperativo cada jugador simula sus propios animales (no se sincronizan).
 */
(function () {
  'use strict';
  var G = window.VERTICE, THREE = window.THREE;
  if (!G || !THREE || !G.Enemy || !G.dir || !G.nav || !G.scene || !G.ctrl) return;
  var Enemy = G.Enemy, T2 = Math.PI * 2, hyp = Math.hypot, rnd = Math.random, TER = G.TERRAIN;

  var clamp = function (v, a, b) { return Math.max(a, Math.min(b, v)); };
  var lerp = function (a, b, t) { return a + (b - a) * t; };
  var wrapPi = function (a) { return a - T2 * Math.round(a / T2); };
  var turn = function (a, b, k) { return a + wrapPi(b - a) * k; };
  var pick = function (a) { return a[Math.floor(rnd() * a.length)]; };
  var toast = function (m, k, ms) { try { G.ui.toast(m, k || '', ms || 3500); } catch (e) { /* sin interfaz */ } };

  function gH(x, z) { try { if (TER && TER.active && TER.active(x, z)) return TER.h(x, z); } catch (e) { /* sin terreno */ } return 0; }
  function inLevel(y, fn) {   // la torre tiene una rejilla de navegación por piso; el mapa libre solo una
    var nav = G.nav; if (typeof nav.setLevel !== 'function' || typeof nav.lvOf !== 'function') return fn();
    var prev = nav.lv; nav.setLevel(nav.lvOf(y));
    try { return fn(); } finally { nav.setLevel(prev); }
  }
  var C = function (h) { return new THREE.Color(h); };
  var mix = function (a, b, t) { return C(a).lerp(C(b), t).getHex(); };
  var rot = function (c, t) { return mix(c, 0x3f4a38, Math.min(0.9, (t == null ? 0.6 : t) + 0.25)); };   // tinte de podredumbre

  // ======================================================================== especies
  // r/h = radio y altura para recibir disparos · hp/zhp = vida sano/infectado · walk/run = paseo y huida · zchase/zwalk = infectado persiguiendo / vagando
  // zdmg/zcool/zreach = mordisco · fear = a qué distancia huye de ti · zsight = vista del infectado · roam = radio de paseo · w = peso de aparición [asentamiento, ciudad, campo]
  var SP = {
    perro:  { n: 'Perro',  zn: 'Perro infectado',  r: 0.42, h: 0.85, hp: 30,  zhp: 52,  walk: 1.4, run: 6.0, zchase: 6.9, zwalk: 1.6, zdmg: 11, zcool: 0.85, zreach: 1.4, fear: 0,  zsight: 38, roam: 14, grp: [1, 2], zgrp: [2, 4], w: [2, 3, 1],      stride: 7,  swing: 0.8,  curious: true, idle: [2, 6] },
    gato:   { n: 'Gato',   zn: 'Gato infectado',   r: 0.28, h: 0.5,  hp: 12,  zhp: 22,  walk: 1.1, run: 6.6, zchase: 6.8, zwalk: 1.5, zdmg: 7,  zcool: 0.7,  zreach: 1.1, fear: 7,  zsight: 30, roam: 10, grp: [1, 1], zgrp: [1, 2], w: [3, 3, 0.3],    stride: 9,  swing: 0.9,  idle: [3, 9], leap: true },
    vaca:   { n: 'Vaca',   zn: 'Vaca infectada',   r: 0.8,  h: 1.5,  hp: 120, zhp: 190, walk: 0.9, run: 4.4, zchase: 3.2, zwalk: 1.0, zdmg: 26, zcool: 1.6,  zreach: 2.0, fear: 4,  zsight: 32, roam: 9,  grp: [2, 3], zgrp: [1, 1], w: [0.2, 0.1, 2.5], stride: 3.6, swing: 0.55, idle: [4, 10], graze: 0.9, charge: true },
    cerdo:  { n: 'Cerdo',  zn: 'Cerdo infectado',  r: 0.5,  h: 0.8,  hp: 55,  zhp: 95,  walk: 1.0, run: 4.9, zchase: 4.2, zwalk: 1.3, zdmg: 15, zcool: 1.1,  zreach: 1.5, fear: 7,  zsight: 28, roam: 9,  grp: [1, 3], zgrp: [1, 2], w: [0.4, 0.5, 2], stride: 6,  swing: 0.7,  idle: [3, 8], graze: 0.55 },
    rata:   { n: 'Rata',   zn: 'Rata infectada',   r: 0.3,  h: 0.28, hp: 4,   zhp: 9,   walk: 1.0, run: 4.6, zchase: 5.4, zwalk: 1.8, zdmg: 4,  zcool: 0.6,  zreach: 0.9, fear: 5,  zsight: 20, roam: 6,  grp: [1, 2], zgrp: [3, 6], w: [3, 4, 0.6],   stride: 22, swing: 1.0,  idle: [0.5, 2], dart: true },
    oveja:  { n: 'Oveja',  zn: 'Oveja infectada',  r: 0.55, h: 0.95, hp: 45,  zhp: 78,  walk: 1.0, run: 5.0, zchase: 3.5, zwalk: 1.2, zdmg: 12, zcool: 1.2,  zreach: 1.5, fear: 9,  zsight: 28, roam: 9,  grp: [2, 4], zgrp: [1, 3], w: [0.2, 0.1, 2.5], stride: 5.5, swing: 0.7, idle: [4, 9], graze: 0.6 },
    pajaro: { n: 'Pájaro', zn: 'Pájaro infectado', r: 0.4, h: 0.5,  hp: 3,   zhp: 7,   walk: 0.7, run: 7.5, zchase: 6.6, zwalk: 1.0, zdmg: 5,  zcool: 1.0,  zreach: 1.1, fear: 8,  zsight: 32, roam: 4,  grp: [1, 3], zgrp: [2, 3], w: [3, 3, 3],     stride: 0,  swing: 0,    idle: [1.5, 5], peck: true, fly: true },
    conejo: { n: 'Conejo', zn: 'Conejo infectado', r: 0.3,  h: 0.42, hp: 7,   zhp: 13,  walk: 0.8, run: 6.2, zchase: 5.6, zwalk: 1.6, zdmg: 6,  zcool: 0.8,  zreach: 1.0, fear: 9,  zsight: 26, roam: 8,  grp: [1, 2], zgrp: [2, 3], w: [1, 0.5, 3],   stride: 0,  swing: 0,    idle: [2, 7], hop: true, zig: true, leap: true }
  };
  var KEYS = Object.keys(SP);

  // Voces (síntesis con el motor de audio del juego). `sano` = llamada normal · `zomb` = gruñido del infectado
  var VOICE = {
    perro:  { sano: { seq: [{ f: 430, s: 250, d: 0.16 }, { f: 450, s: 250, d: 0.16, at: 0.24 }], t: 'sawtooth', lp: 1800, g: 0.2 },  zomb: { f: 92, s: 64, d: 0.95, t: 'sawtooth', lp: 600, vib: [16, 14], g: 0.26, nz: 520 } },
    gato:   { sano: { seq: [{ f: 650, s: 950, d: 0.2 }, { f: 950, s: 520, d: 0.32, at: 0.2 }], t: 'triangle', lp: 2600, g: 0.15 },     zomb: { f: 1100, s: 640, d: 0.6, t: 'sawtooth', lp: 3200, vib: [40, 60], g: 0.14, nz: 2400 } },
    vaca:   { sano: { seq: [{ f: 140, s: 108, d: 1.1 }], t: 'sawtooth', lp: 650, vib: [4, 5], g: 0.26 },                               zomb: { f: 84, s: 58, d: 1.4, t: 'sawtooth', lp: 420, vib: [6, 8], g: 0.3, nz: 260 } },
    cerdo:  { sano: { seq: [{ f: 190, s: 110, d: 0.2 }, { f: 180, s: 105, d: 0.2, at: 0.26 }], t: 'sawtooth', lp: 1100, g: 0.2 },      zomb: { f: 120, s: 68, d: 0.55, t: 'square', lp: 700, vib: [14, 10], g: 0.22, nz: 400 } },
    rata:   { sano: { seq: [{ f: 3400, s: 2600, d: 0.07 }, { f: 3400, s: 2700, d: 0.07, at: 0.1 }, { f: 3300, s: 2600, d: 0.07, at: 0.2 }], t: 'sine', g: 0.06 }, zomb: { f: 2200, s: 1400, d: 0.16, t: 'square', lp: 4200, g: 0.07, nz: 3000 } },
    oveja:  { sano: { seq: [{ f: 340, s: 300, d: 0.75 }], t: 'sawtooth', lp: 1100, vib: [28, 22], g: 0.19 },                           zomb: { f: 240, s: 140, d: 0.95, t: 'sawtooth', lp: 700, vib: [20, 26], g: 0.2, nz: 600 } },
    pajaro: { sano: { seq: [{ f: 3200, s: 4200, d: 0.06 }, { f: 3300, s: 4300, d: 0.06, at: 0.1 }, { f: 3000, s: 4000, d: 0.06, at: 0.2 }], t: 'sine', g: 0.08 }, zomb: { f: 520, s: 250, d: 0.38, t: 'sawtooth', lp: 1800, g: 0.16, nz: 1500 } },
    conejo: { sano: { seq: [{ f: 110, s: 58, d: 0.1 }], t: 'sine', g: 0.14 },                                                         zomb: { f: 1700, s: 900, d: 0.5, t: 'sawtooth', lp: 3000, vib: [35, 50], g: 0.12, nz: 2000 } }
  };
  var lastSnd = 0;
  function say(a, kind) {
    var A = G.audio; if (!A || !A.ctx) return;
    var now = performance.now(), d = hyp(G.ctrl.pos.x - a.pos.x, G.ctrl.pos.z - a.pos.z);
    if (d > 60 || now - lastSnd < 70) return; lastSnd = now;
    var V = VOICE[a.key], P = { x: a.pos.x, y: a.pos.y + a.sp.h * 0.6, z: a.pos.z };
    try {
      if (!a.z) {
        var v = V.sano, k = kind === 'hurt' ? 1.5 : kind === 'die' ? 0.8 : 1;
        v.seq.forEach(function (n) { A._tone({ f: n.f * k, sweep: n.s * (kind === 'die' ? 0.5 : k), dur: kind === 'hurt' ? n.d * 0.8 : n.d * (kind === 'die' ? 2 : 1), gain: v.g * (kind === 'hurt' || kind === 'die' ? 1.25 : 1), type: v.t, lp: v.lp, vib: v.vib, delay: n.at || 0, pos: P }); });
      } else {
        var z = V.zomb, sc = kind === 'die' ? 0.7 : kind === 'attack' ? 1.25 : 1;
        A._tone({ f: z.f * sc, sweep: z.s * (kind === 'die' ? 0.4 : sc), dur: z.d * (kind === 'attack' ? 0.5 : 1), gain: z.g * (kind === 'attack' ? 1.2 : 1), type: z.t, lp: z.lp, vib: z.vib, pos: P });
        A._noise({ type: 'bandpass', f: z.nz, q: 2, dur: Math.min(0.7, z.d * 0.8), gain: 0.1, pos: P });
        if (kind === 'attack') A._noise({ type: 'bandpass', f: 1100, dur: 0.12, gain: 0.18, pos: P });
      }
    } catch (e) { /* sin audio */ }
  }

  // ======================================================================== modelos (geometría fusionada con color por vértice)
  function Builder() { this.p = []; this.n = []; this.c = []; this.i = []; this.v = 0; }
  Builder.prototype.add = function (geo, x, y, z, rx, ry, rz, col) {
    geo.applyMatrix4(new THREE.Matrix4().compose(new THREE.Vector3(x, y, z), new THREE.Quaternion().setFromEuler(new THREE.Euler(rx || 0, ry || 0, rz || 0, 'YXZ')), new THREE.Vector3(1, 1, 1)));
    var P = geo.attributes.position, N = geo.attributes.normal, I = geo.index, c = C(col), j = 0.93 + rnd() * 0.14, k;
    for (k = 0; k < P.count; k++) {
      var ny = N.getY(k), sh = (0.84 + 0.16 * ny) * j;
      this.p.push(P.getX(k), P.getY(k), P.getZ(k)); this.n.push(N.getX(k), N.getY(k), N.getZ(k)); this.c.push(c.r * sh, c.g * sh, c.b * sh);
    }
    for (k = 0; k < I.count; k++) this.i.push(I.getX(k) + this.v);
    this.v += P.count; geo.dispose(); return this;
  };
  Builder.prototype.box = function (w, h, d, x, y, z, col, rx, ry, rz) { return this.add(new THREE.BoxGeometry(w, h, d), x, y, z, rx, ry, rz, col); };
  Builder.prototype.ell = function (sx, sy, sz, x, y, z, col, rx, ry, rz) { var g = new THREE.SphereGeometry(1, 9, 7); g.scale(sx, sy, sz); return this.add(g, x, y, z, rx, ry, rz, col); };
  Builder.prototype.geo = function () {
    var g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(this.p, 3)); g.setAttribute('normal', new THREE.Float32BufferAttribute(this.n, 3)); g.setAttribute('color', new THREE.Float32BufferAttribute(this.c, 3));
    g.setIndex(this.i); g.computeBoundingSphere(); return g;
  };
  // detalles de infectado
  function wound(B, x, y, z, s) { B.ell(s, s * 0.7, s, x, y, z, 0x6b0e0e); B.ell(s * 0.5, s * 0.4, s * 0.5, x, y + s * 0.3, z, 0xa51d1d); }
  function eyes(H, ex, ey, ez, s, zomb, col) { var c = zomb ? 0xff2a1a : (col || 0x151515), q = zomb ? s * 1.4 : s; H.box(q, q, q * 0.6, -ex, ey, ez, c); H.box(q, q, q * 0.6, ex, ey, ez, c); }
  function legSet(defs, mk) { return defs.map(function (d) { var L = new Builder(); mk(L, d); return { b: L, x: d[0], y: d[1], z: d[2], ph: d[3] }; }); }

  var COATS = {
    perro: [0x8a6a3c, 0x2e2a28, 0xb9b1a0, 0x6b4a2a, 0xc2a36a],
    gato: [0xc77a3a, 0x7d7d84, 0x1e1e22, 0xd9d4c8, 0x9a7a52],
    vaca: [{ a: 0xe8e6e0, b: 0x1d1d1d }, { a: 0x7a4a2a, b: 0xe8e0d0 }, { a: 0xb98a5a, b: null }, { a: 0x2c2420, b: null }],
    cerdo: [0xe5a7a5, 0xd9958f, 0x6e5348, 0xe8c0b0],
    rata: [0x6a6055, 0x25221f, 0x7a5a3e, 0x8a8478],
    oveja: [0xece8dc, 0xb8b2a6, 0xded6c2],
    pajaro: [{ a: 0x8a8f98, h: 0x5f6a7a, b: 0xb9bcc4 }, { a: 0x1b1b1f, h: 0x1b1b1f, b: 0x2a2a30 }, { a: 0x8b6a45, h: 0x6a4e30, b: 0xc8b090 }],
    conejo: [0x8a6a4a, 0x8a8a8a, 0xe8e4dc, 0x6a5a48]
  };

  var MK = {};
  MK.perro = function (z, c) {
    var col = z ? rot(c, 0.62) : c, drk = z ? 0x23251f : mix(c, 0x000000, 0.5), lit = z ? 0x8d8f7c : mix(c, 0xffffff, 0.4), B = new Builder(), H = new Builder();
    B.ell(0.15, 0.17, 0.36, 0, 0.54, 0, col); B.ell(0.14, 0.16, 0.17, 0, 0.56, 0.2, col); B.ell(0.13, 0.15, 0.15, 0, 0.54, -0.2, col);
    B.box(0.1, 0.2, 0.12, 0, 0.68, 0.29, col, 0.55, 0, 0); B.box(0.04, 0.04, 0.3, 0, 0.62, -0.42, col, -0.8, 0, 0);
    if (z) { for (var i = 0; i < 3; i++) B.box(0.31, 0.022, 0.035, 0, 0.47 + i * 0.05, 0.06 - i * 0.04, 0xc9c2a8); wound(B, 0.13, 0.62, -0.02, 0.07); wound(B, -0.12, 0.6, -0.16, 0.06); }
    H.ell(0.1, 0.095, 0.12, 0, 0, 0.04, col); H.box(0.07, 0.06, 0.17, 0, -0.035, 0.19, lit); H.box(0.03, 0.03, 0.03, 0, -0.005, 0.28, 0x101010);
    H.box(0.04, 0.1, 0.05, -0.07, 0.1, -0.01, drk, 0, 0, 0.35); H.box(0.04, 0.1, 0.05, 0.07, 0.1, -0.01, drk, 0, 0, -0.35);
    eyes(H, 0.05, 0.03, 0.12, 0.02, z); if (z) H.box(0.055, 0.02, 0.13, 0, -0.1, 0.17, 0x7a1a1a, 0.45, 0, 0);
    return { body: B, head: { b: H, x: 0, y: 0.76, z: 0.36 }, legs: legSet([[-0.09, 0.42, 0.24, 0], [0.09, 0.42, 0.24, Math.PI], [-0.09, 0.42, -0.22, Math.PI], [0.09, 0.42, -0.22, 0]], function (L) { L.box(0.07, 0.42, 0.07, 0, -0.21, 0, col); L.box(0.08, 0.04, 0.11, 0, -0.4, 0.02, drk); }) };
  };
  MK.gato = function (z, c) {
    var col = z ? rot(c, 0.6) : c, lit = z ? 0x8d8f7c : mix(c, 0xffffff, 0.35), B = new Builder(), H = new Builder();
    B.ell(0.085, 0.095, 0.2, 0, 0.27, 0, col); B.ell(0.08, 0.09, 0.1, 0, 0.28, -0.12, col); B.box(0.06, 0.12, 0.07, 0, 0.34, 0.17, col, 0.5, 0, 0);
    B.box(0.03, 0.03, 0.14, 0, 0.33, -0.3, col, -0.5, 0, 0); B.box(0.03, 0.03, 0.14, 0, 0.43, -0.38, col, -1.0, 0, 0); B.box(0.03, 0.03, 0.1, 0, 0.52, -0.4, col, -1.5, 0, 0);
    if (!z) for (var i = 0; i < 3; i++) B.box(0.1, 0.012, 0.03, 0, 0.365, 0.05 - i * 0.08, mix(c, 0x000000, 0.4));
    else { wound(B, 0.08, 0.3, 0.02, 0.05); B.box(0.17, 0.012, 0.02, 0, 0.3, 0.1, 0xc9c2a8); B.box(0.17, 0.012, 0.02, 0, 0.3, 0.05, 0xc9c2a8); }
    H.ell(0.07, 0.065, 0.07, 0, 0, 0.02, col); H.box(0.035, 0.03, 0.04, 0, -0.015, 0.08, lit);
    H.box(0.03, 0.055, 0.02, -0.04, 0.075, 0, col, 0, 0, 0.3); H.box(0.03, 0.055, 0.02, 0.04, 0.075, 0, col, 0, 0, -0.3);
    eyes(H, 0.03, 0.015, 0.07, 0.014, z, 0x9bd04a); if (z) H.box(0.04, 0.012, 0.05, 0, -0.05, 0.06, 0x7a1a1a, 0.4, 0, 0);
    return { body: B, head: { b: H, x: 0, y: 0.4, z: 0.2 }, legs: legSet([[-0.05, 0.25, 0.14, 0], [0.05, 0.25, 0.14, Math.PI], [-0.05, 0.25, -0.13, Math.PI], [0.05, 0.25, -0.13, 0]], function (L) { L.box(0.04, 0.25, 0.04, 0, -0.125, 0, col); L.box(0.045, 0.03, 0.06, 0, -0.24, 0.01, lit); }) };
  };
  MK.vaca = function (z, c) {
    var base = z ? rot(c.a, 0.55) : c.a, patch = c.b == null ? null : (z ? rot(c.b, 0.4) : c.b), pink = z ? 0x8a6a62 : 0xd9a1a0, B = new Builder(), H = new Builder();
    B.ell(0.37, 0.4, 0.78, 0, 1.02, 0, base); B.ell(0.32, 0.36, 0.35, 0, 1.05, 0.5, base); B.ell(0.3, 0.34, 0.3, 0, 1.0, -0.5, base);
    B.box(0.26, 0.3, 0.42, 0, 1.2, 0.9, base, 0.55, 0, 0);
    if (patch) { B.ell(0.2, 0.08, 0.3, 0.1, 1.38, 0.1, patch); B.ell(0.06, 0.2, 0.25, 0.36, 1.05, -0.2, patch); B.ell(0.06, 0.18, 0.2, -0.36, 1.1, 0.3, patch); B.ell(0.16, 0.07, 0.2, -0.15, 1.36, -0.45, patch); }
    B.ell(0.1, 0.07, 0.12, 0, 0.66, -0.35, pink);
    B.box(0.04, 0.5, 0.04, 0, 0.95, -0.84, base, 0.15, 0, 0); B.ell(0.05, 0.09, 0.05, 0, 0.68, -0.87, 0x2a2420);
    if (z) { for (var i = 0; i < 4; i++) B.box(0.75, 0.025, 0.04, 0, 0.96 + i * 0.06, 0.1 - i * 0.05, 0xc9c2a8); wound(B, 0.3, 1.2, 0.35, 0.12); wound(B, -0.3, 1.05, -0.3, 0.1); }
    H.ell(0.14, 0.16, 0.2, 0, -0.05, 0.14, base); H.box(0.13, 0.1, 0.1, 0, -0.12, 0.34, pink); H.box(0.03, 0.12, 0.03, -0.1, 0.14, 0, 0xe8e0c8, 0, 0, 0.5); H.box(0.03, 0.12, 0.03, 0.1, 0.14, 0, 0xe8e0c8, 0, 0, -0.5);
    H.box(0.12, 0.04, 0.06, -0.17, 0.07, -0.02, base, 0, 0, 0.2); H.box(0.12, 0.04, 0.06, 0.17, 0.07, -0.02, base, 0, 0, -0.2);
    if (patch) H.ell(0.1, 0.1, 0.06, 0.04, 0.0, 0.3, patch);
    eyes(H, 0.1, 0.02, 0.2, 0.03, z); if (z) H.box(0.1, 0.03, 0.18, 0, -0.2, 0.27, 0x7a1a1a, 0.45, 0, 0);
    return { body: B, head: { b: H, x: 0, y: 1.27, z: 1.02 }, legs: legSet([[-0.2, 0.74, 0.5, 0], [0.2, 0.74, 0.5, Math.PI], [-0.2, 0.74, -0.5, Math.PI], [0.2, 0.74, -0.5, 0]], function (L) { L.box(0.12, 0.74, 0.12, 0, -0.37, 0, base); L.box(0.13, 0.06, 0.14, 0, -0.71, 0.01, 0x2a2420); }) };
  };
  MK.cerdo = function (z, c) {
    var col = z ? rot(c, 0.5) : c, lit = z ? 0x8a7a70 : mix(c, 0xffffff, 0.25), B = new Builder(), H = new Builder();
    B.ell(0.3, 0.3, 0.52, 0, 0.52, 0, col); B.ell(0.27, 0.28, 0.25, 0, 0.54, 0.3, col); B.box(0.2, 0.2, 0.2, 0, 0.58, 0.5, col); B.box(0.025, 0.025, 0.09, 0, 0.62, -0.55, col, -0.9, 0, 0);
    if (z) { wound(B, 0.28, 0.6, 0.1, 0.1); wound(B, -0.27, 0.5, -0.2, 0.08); B.box(0.6, 0.02, 0.03, 0, 0.46, 0.1, 0xc9c2a8); B.box(0.6, 0.02, 0.03, 0, 0.5, 0.0, 0xc9c2a8); }
    H.ell(0.17, 0.17, 0.18, 0, 0, 0.08, col); H.box(0.13, 0.1, 0.09, 0, -0.03, 0.24, lit); H.box(0.02, 0.03, 0.01, -0.03, -0.03, 0.29, 0x3a1a1a); H.box(0.02, 0.03, 0.01, 0.03, -0.03, 0.29, 0x3a1a1a);
    H.box(0.09, 0.05, 0.08, -0.11, 0.15, 0, col, 0.6, 0, 0.5); H.box(0.09, 0.05, 0.08, 0.11, 0.15, 0, col, 0.6, 0, -0.5); eyes(H, 0.08, 0.05, 0.16, 0.022, z);
    if (z) H.box(0.1, 0.025, 0.14, 0, -0.1, 0.2, 0x7a1a1a, 0.4, 0, 0);
    return { body: B, head: { b: H, x: 0, y: 0.58, z: 0.56 }, legs: legSet([[-0.15, 0.3, 0.3, 0], [0.15, 0.3, 0.3, Math.PI], [-0.15, 0.3, -0.28, Math.PI], [0.15, 0.3, -0.28, 0]], function (L) { L.box(0.09, 0.3, 0.09, 0, -0.15, 0, col); L.box(0.095, 0.04, 0.1, 0, -0.29, 0, 0x2e2622); }) };
  };
  MK.rata = function (z, c) {
    var col = z ? rot(c, 0.55) : c, tail = z ? 0x8a6a62 : 0xc99a8f, B = new Builder(), H = new Builder();
    B.ell(0.065, 0.06, 0.13, 0, 0.1, 0, col); B.ell(0.055, 0.055, 0.08, 0, 0.105, -0.08, col); B.box(0.012, 0.012, 0.26, 0, 0.07, -0.28, tail, 0.15, 0, 0);
    if (z) wound(B, 0.04, 0.12, 0, 0.03);
    H.ell(0.045, 0.045, 0.06, 0, 0, 0.03, col); H.box(0.025, 0.025, 0.05, 0, -0.01, 0.1, col); H.box(0.01, 0.01, 0.01, 0, -0.005, 0.13, 0x201010);
    H.ell(0.025, 0.03, 0.01, -0.035, 0.04, -0.01, tail); H.ell(0.025, 0.03, 0.01, 0.035, 0.04, -0.01, tail); eyes(H, 0.025, 0.015, 0.06, 0.01, z);
    return { body: B, head: { b: H, x: 0, y: 0.11, z: 0.11 }, legs: legSet([[-0.04, 0.07, 0.07, 0], [0.04, 0.07, 0.07, Math.PI], [-0.04, 0.07, -0.07, Math.PI], [0.04, 0.07, -0.07, 0]], function (L) { L.box(0.02, 0.07, 0.03, 0, -0.035, 0.01, tail); }) };
  };
  MK.oveja = function (z, c) {
    var wool = z ? rot(c, 0.45) : c, face = z ? 0x4d4a3c : (c === 0xded6c2 ? 0xd8cdb8 : 0x2f2a27), legc = z ? 0x3a3830 : 0x2f2a27, B = new Builder(), H = new Builder();
    B.ell(0.31, 0.29, 0.46, 0, 0.7, 0, wool); B.ell(0.2, 0.2, 0.2, 0.18, 0.88, 0.1, wool); B.ell(0.2, 0.2, 0.2, -0.18, 0.88, 0.1, wool); B.ell(0.2, 0.2, 0.2, 0, 0.9, -0.2, wool);
    B.ell(0.2, 0.2, 0.2, 0.2, 0.62, -0.3, wool); B.ell(0.2, 0.2, 0.2, -0.2, 0.62, -0.3, wool); B.ell(0.18, 0.2, 0.2, 0, 0.84, 0.3, wool); B.box(0.2, 0.2, 0.2, 0, 0.78, 0.45, wool, 0.4, 0, 0); B.ell(0.07, 0.07, 0.07, 0, 0.7, -0.5, wool);
    if (z) { wound(B, 0.3, 0.75, 0.05, 0.09); wound(B, -0.28, 0.62, -0.2, 0.08); B.box(0.62, 0.02, 0.03, 0, 0.6, 0.1, 0xc9c2a8); }
    H.ell(0.09, 0.12, 0.13, 0, -0.03, 0.07, face); H.box(0.1, 0.03, 0.05, -0.11, 0.02, 0, face, 0, 0, 0.3); H.box(0.1, 0.03, 0.05, 0.11, 0.02, 0, face, 0, 0, -0.3); H.ell(0.09, 0.06, 0.07, 0, 0.09, 0, wool);
    eyes(H, 0.06, 0.0, 0.14, 0.02, z, 0xe0d070); if (z) H.box(0.07, 0.02, 0.1, 0, -0.14, 0.1, 0x7a1a1a, 0.4, 0, 0);
    return { body: B, head: { b: H, x: 0, y: 0.86, z: 0.42 }, legs: legSet([[-0.13, 0.46, 0.28, 0], [0.13, 0.46, 0.28, Math.PI], [-0.13, 0.46, -0.28, Math.PI], [0.13, 0.46, -0.28, 0]], function (L) { L.box(0.06, 0.46, 0.06, 0, -0.23, 0, legc); }) };
  };
  MK.pajaro = function (z, c) {
    var col = z ? rot(c.a, 0.5) : c.a, hd = z ? rot(c.h, 0.5) : c.h, bel = z ? rot(c.b, 0.5) : c.b, beak = z ? 0x6a6a5a : 0xe0a030, B = new Builder(), H = new Builder(), i;
    B.ell(0.06, 0.06, 0.11, 0, 0.13, 0, col); B.ell(0.05, 0.04, 0.09, 0, 0.1, 0.01, bel); B.box(0.06, 0.012, 0.12, 0, 0.14, -0.14, col, -0.15, 0, 0);
    B.box(0.01, 0.08, 0.01, -0.025, 0.04, 0, 0xb09060); B.box(0.01, 0.08, 0.01, 0.025, 0.04, 0, 0xb09060); if (z) wound(B, 0.03, 0.16, 0, 0.03);
    H.ell(0.04, 0.04, 0.045, 0, 0, 0, hd); H.box(0.015, 0.012, 0.045, 0, -0.005, 0.055, beak); eyes(H, 0.025, 0.012, 0.025, 0.01, z);
    var wings = [1, -1].map(function (s) {
      var W = new Builder();
      if (z) { W.box(0.11, 0.012, 0.1, s * 0.055, 0, -0.01, col); W.box(0.07, 0.012, 0.06, s * 0.15, 0, 0.02, col); } else { W.box(0.2, 0.012, 0.1, s * 0.1, 0, -0.01, col); }
      return { b: W, x: s * 0.05, y: 0.15, z: 0, s: s };
    });
    for (i = 0; i < 1; i++) { /* sin patas animadas */ }
    return { body: B, head: { b: H, x: 0, y: 0.19, z: 0.09 }, legs: [], wings: wings };
  };
  MK.conejo = function (z, c) {
    var col = z ? rot(c, 0.55) : c, B = new Builder(), H = new Builder();
    B.ell(0.09, 0.095, 0.15, 0, 0.16, 0, col); B.ell(0.085, 0.1, 0.1, 0, 0.15, -0.09, col); B.box(0.07, 0.08, 0.07, 0, 0.22, 0.1, col, 0.4, 0, 0); B.ell(0.035, 0.035, 0.035, 0, 0.18, -0.17, z ? 0x8a8a7a : 0xf3f0e8);
    if (z) { wound(B, 0.07, 0.19, 0.0, 0.04); B.box(0.17, 0.01, 0.02, 0, 0.14, 0.04, 0xc9c2a8); }
    H.ell(0.055, 0.055, 0.075, 0, 0, 0.03, col); H.box(0.025, 0.15, 0.04, -0.025, 0.12, -0.02, col, -0.25, 0, 0.12); H.box(0.025, 0.15, 0.04, 0.025, 0.12, -0.02, col, -0.25, 0, -0.12); H.box(0.012, 0.012, 0.012, 0, -0.01, 0.1, 0xd08080);
    eyes(H, 0.04, 0.02, 0.06, 0.012, z); if (z) H.box(0.04, 0.012, 0.06, 0, -0.06, 0.07, 0x7a1a1a, 0.4, 0, 0);
    return { body: B, head: { b: H, x: 0, y: 0.25, z: 0.12 }, legs: [[-0.04, 0.1, 0.1, 0, 0.1], [0.04, 0.1, 0.1, Math.PI, 0.1], [-0.06, 0.13, -0.1, Math.PI, 0.13], [0.06, 0.13, -0.1, 0, 0.13]].map(function (d) {
      var L = new Builder(); if (d[4] < 0.12) L.box(0.03, 0.1, 0.035, 0, -0.05, 0, col); else L.box(0.045, 0.13, 0.1, 0, -0.065, 0.02, col); return { b: L, x: d[0], y: d[1], z: d[2], ph: d[3] };
    }) };
  };

  var cache = {}, matH = new THREE.MeshLambertMaterial({ vertexColors: true }), matZ = new THREE.MeshLambertMaterial({ vertexColors: true, emissive: 0x1a0a08 });
  function makeModel(key, z, ci) {
    var k = key + '|' + (z ? 1 : 0) + '|' + ci, S = cache[k];
    if (!S) {
      var raw = MK[key](z, COATS[key][ci]);
      S = cache[k] = { body: raw.body.geo(), head: raw.head && { g: raw.head.b.geo(), x: raw.head.x, y: raw.head.y, z: raw.head.z },
        legs: raw.legs.map(function (l) { return { g: l.b.geo(), x: l.x, y: l.y, z: l.z, ph: l.ph }; }), wings: (raw.wings || []).map(function (w) { return { g: w.b.geo(), x: w.x, y: w.y, z: w.z, s: w.s }; }) };
    }
    var mat = z ? matZ : matH, root = new THREE.Group(), inner = new THREE.Group(), M = { g: root, p: inner, head: null, legs: [], wings: [] };
    root.add(inner); inner.add(new THREE.Mesh(S.body, mat));
    if (S.head) { M.head = new THREE.Mesh(S.head.g, mat); M.head.position.set(S.head.x, S.head.y, S.head.z); inner.add(M.head); }
    S.legs.forEach(function (l) { var m = new THREE.Mesh(l.g, mat); m.position.set(l.x, l.y, l.z); m.userData.ph = l.ph; inner.add(m); M.legs.push(m); });
    S.wings.forEach(function (w) { var m = new THREE.Mesh(w.g, mat); m.position.set(w.x, w.y, w.z); m.userData.s = w.s; inner.add(m); M.wings.push(m); });
    return M;
  }

  // ======================================================================== animal
  var list = [], foes = [], uid = 0, groups = 0;
  var fixKills = 0, shownZ = false;

  function Animal(key, zomb, x, z, ci, grp) {
    var sp = SP[key]; this.id = 'an' + (++uid); this.key = key; this.sp = sp; this.z = !!zomb; this.grp = grp || null;
    this.T = { name: zomb ? sp.zn : sp.n, radius: sp.r, height: sp.h, scale: 1 }; this.isGiant = false; this.isAnimal = true;
    this.pos = { x: x, y: gH(x, z), z: z }; this.yaw = rnd() * T2; this.hp = zomb ? sp.zhp : sp.hp; this.alive = true; this.deadT = 0; this.deadSide = rnd() < 0.5 ? 1 : -1; this.deadAnim = 0;
    this.state = 'idle'; this.stateT = 0; this.dur = 1 + rnd() * 3; this.aware = 0; this.canSee = false; this.lit = false; this.lostT = 0; this.lastKnown = null; this.target = null; this.threat = null;
    this.path = null; this.pi = 0; this.partial = false; this.repath = 0; this.pend = null; this.speedNow = 0; this.cool = 0; this.stun = 0; this.burnT = 0; this.attackT = 0;
    this.phase = rnd() * 6; this.t = rnd() * 10; this.hopP = rnd() * 6; this.yOff = 0; this.hurtT = 0; this.kx = 0; this.kz = 0; this.fly = false; this.flyT = 0;
    this.tickT = rnd() * 0.25; this.dirT = 0; this.direct = true; this.snd = 3 + rnd() * 8; this.zs = 0; this.zig = 0; this.mv = { x: x, z: z, t: 0 }; this.home = { x: x, z: z };
    this.noiseCD = 0; this.chargeCD = 3 + rnd() * 4; this.leapCD = 0; this.charge = null; this.leap = null; this.altAim = 7; this.fdir = 0; this.rm = false;
    this.scale = (0.92 + rnd() * 0.2) * (key === 'rata' ? 0.9 + rnd() * 0.2 : 1);
    this.model = makeModel(key, this.z, Math.floor(rnd() * COATS[key].length)); this.mesh = this.model.g; this.mesh.scale.setScalar(this.scale);
    this.T.radius = sp.r * this.scale; this.T.height = sp.h * this.scale;
    this.mesh.position.set(this.pos.x, this.pos.y, this.pos.z); G.scene.add(this.mesh);
  }
  ['setPath', 'vertPath', 'follow', 'moveDir', 'groundSnap'].forEach(function (n) { if (Enemy.prototype[n]) Animal.prototype[n] = Enemy.prototype[n]; });
  Animal.prototype.die = function () { this.kill(true); };
  Animal.prototype.dispose = function () { G.scene.remove(this.mesh); };

  Animal.prototype.hurt = function (dmg, src, sneak, kb) {
    if (!this.alive) return;
    this.hp -= dmg; this.hurtT = 0.18;
    try { G.Parts.burst(this.pos.x, this.pos.y + this.sp.h * 0.6 * this.scale, this.pos.z, 6, 3, this.z ? 0x4a1010 : 0xaa1a14, this.z ? 0x220808 : 0x550a08, 0.4, 0.06); } catch (e) { /* sin partículas */ }
    if (src && src.x != null) {
      var dx = this.pos.x - src.x, dz = this.pos.z - src.z, L = hyp(dx, dz) || 1, k = clamp((kb == null ? 1 : kb), 0, 3) * (this.sp.h > 1 ? 0.6 : 1.4);
      this.kx += dx / L * k * 2.2; this.kz += dz / L * k * 2.2;
    }
    if (this.hp <= 0) { this.kill(false); return; }
    say(this, 'hurt');
    if (this.z) { this.stun = Math.max(this.stun, 0.18); if (this.state !== 'chase') { this.aware = 1.2; if (src && src.x != null) this.lastKnown = { x: G.ctrl.pos.x, z: G.ctrl.pos.z }; this.startChase(); } }
    else this.scare(src && src.x != null ? src.x : this.pos.x - 1, src && src.z != null ? src.z : this.pos.z, 6 + rnd() * 4);
  };
  Animal.prototype.kill = function (silent) {
    if (!this.alive) return; this.alive = false; this.deadT = 0; this.state = 'dead'; this.path = null;
    if (!silent) { say(this, 'die'); if (!this.z) fixKills++; }
  };

  // ---------------------------------------------------------------- movimiento
  function diffMul(a) { return a.z ? 1 : 1 / (G.diff && G.diff.speed || 1); }   // los sanos no se aceleran en Difícil
  Animal.prototype.steer = function (tx, tz, speed, dt) {
    var dx = tx - this.pos.x, dz = tz - this.pos.z, d = hyp(dx, dz); if (d < 0.4) return true;
    if (this.sp.hop) { this.hopP += dt * (speed > 3 ? 11 : 8); speed *= 0.2 + 1.7 * Math.max(0, Math.sin(this.hopP)); }
    if ((this.dirT -= dt) <= 0) { this.dirT = 0.3; this.direct = G.nav.straight(this.pos, { x: tx, z: tz }); }
    var md = diffMul(this);
    if (this.direct) { this.path = null; this.pgoal = null; this.moveDir(dx / d, dz / d, speed * md, dt); return false; }
    if (!this.path || !this.pgoal || hyp(this.pgoal.x - tx, this.pgoal.z - tz) > 2.5) { this.pgoal = { x: tx, z: tz }; this.setPath(tx, tz); }
    if (this.pend) return false;
    if (!this.path) return 'blocked';
    return this.follow(dt, speed * md) ? true : false;
  };
  Animal.prototype.face = function (x, z, dt, k) { this.yaw = turn(this.yaw, Math.atan2(x - this.pos.x, z - this.pos.z), 1 - Math.exp(-(k || 8) * dt)); };
  function walkOK(a, x, z) {
    if (!G.nav.walkableAt(x, z)) return false;
    if (TER && TER.depth && TER.depth(x, z) > 0.25) return false;
    if (G.inside && G.inside({ x: x, y: a.pos.y + 0.5, z: z })) return false;
    return true;
  }
  Animal.prototype.anchor = function () {
    if (this.grp) { for (var i = 0; i < this.grp.m.length; i++) { var m = this.grp.m[i]; if (m.alive && !m.fly) return m === this ? this.home : m.pos; } }
    return this.home;
  };
  Animal.prototype.pickWander = function (short) {
    var b = this.anchor(), R = short ? Math.min(3, this.sp.roam) : this.sp.roam;
    for (var i = 0; i < 6; i++) {
      var a = rnd() * T2, r = 2 + rnd() * R, tx = b.x + Math.sin(a) * r, tz = b.z + Math.cos(a) * r;
      if (!walkOK(this, tx, tz)) continue;
      this.target = { x: tx, z: tz }; this.state = 'wander'; this.stateT = 0; this.path = null; this.pgoal = null; this.dur = 14; this.dirT = 0; return true;
    }
    this.state = 'idle'; this.stateT = 0; this.dur = 1 + rnd() * 2; return false;
  };
  Animal.prototype.pickIdle = function () {
    var sp = this.sp; this.stateT = 0; this.dur = sp.idle[0] + rnd() * (sp.idle[1] - sp.idle[0]); this.target = null; this.path = null;
    this.state = (sp.graze || sp.peck) && rnd() < 0.7 ? 'graze' : 'idle';
  };
  Animal.prototype.fearR = function (d) {
    var sp = this.sp; if (!sp.fear) return 0; var pl = G.player, v = hyp(G.ctrl.vel ? G.ctrl.vel.x : 0, G.ctrl.vel ? G.ctrl.vel.z : 0), r = sp.fear;
    if (G.veh) return r * 2.4; if (G.crouch || G.prone) r *= 0.55; if (v > 4.6) r *= 1.6; else if (v < 0.3 && !(pl && pl.moving)) r *= 0.6;
    return r;
  };

  // ---------------------------------------------------------------- animales sanos
  Animal.prototype.scare = function (x, z, dur, noProp) {
    if (!this.alive || this.z) return;
    if (this.sp.fly && !this.fly) { this.takeOff(x, z); return; }
    if (this.fly) return;
    var was = this.state === 'flee';
    this.state = 'flee'; this.stateT = 0; this.dur = dur || 4 + rnd() * 4; this.threat = { x: x, z: z }; this.path = null; this.pgoal = null; this.zs = 0; this.zig = 0; this.dirT = 0;
    if (!was && rnd() < 0.5) say(this, 'hurt');
    if (!noProp && this.grp) for (var i = 0; i < this.grp.m.length; i++) { var m = this.grp.m[i]; if (m !== this && m.alive && !m.z && m.state !== 'flee' && hyp(m.pos.x - this.pos.x, m.pos.z - this.pos.z) < 26) m.scare(x, z, dur, true); }
  };
  Animal.prototype.takeOff = function (x, z) {
    this.fly = true; this.state = 'fly'; this.flyT = 0; this.fdir = Math.atan2(this.pos.x - x, this.pos.z - z) + (rnd() - 0.5) * 1.0; this.altAim = 6 + rnd() * 6; this.path = null;
    say(this, 'idle');
    if (this.grp) for (var i = 0; i < this.grp.m.length; i++) { var m = this.grp.m[i]; if (m !== this && m.alive && !m.z && !m.fly && hyp(m.pos.x - this.pos.x, m.pos.z - this.pos.z) < 14) m.takeOff(x, z); }
  };
  Animal.prototype.healthyAI = function (dt) {
    var sp = this.sp, pl = G.ctrl.pos, dx = pl.x - this.pos.x, dz = pl.z - this.pos.z, d = hyp(dx, dz), st = this.state, i;
    if (this.fly) { this.flyAway(dt, d); return; }
    if (st !== 'flee') {
      var fr = this.fearR(d);
      if (fr > 0 && d < fr && Math.abs(pl.y - this.pos.y) < 3.5) { this.scare(pl.x, pl.z); st = this.state; }
      else if ((this.tickT -= dt) <= 0) {   // infectados persiguiendo cerca
        this.tickT = 0.4; var en = G.dir.enemies;
        for (i = 0; i < en.length; i++) { var e = en[i]; if (e.alive && e.state === 'chase' && !e.isGiant && Math.abs(e.pos.x - this.pos.x) < 9 && Math.abs(e.pos.z - this.pos.z) < 9 && hyp(e.pos.x - this.pos.x, e.pos.z - this.pos.z) < 9) { this.scare(e.pos.x, e.pos.z, 5 + rnd() * 3); st = this.state; break; } }
      }
    }
    this.snd -= dt; if (this.snd <= 0) { this.snd = 7 + rnd() * 14; if (d < 40 && st !== 'flee' && (this.key !== 'pajaro' || G.env.night < 0.6) && rnd() < 0.75) say(this, 'idle'); }
    var md;
    switch (st) {
      case 'flee': {
        var th = this.threat, ax = this.pos.x - th.x, az = this.pos.z - th.z, L = hyp(ax, az) || 1, nx; ax /= L; az /= L;
        if (sp.zig) { this.zig -= dt; if (this.zig <= 0) { this.zig = 0.3 + rnd() * 0.35; this.zs = (rnd() < 0.5 ? -1 : 1) * (0.5 + rnd() * 0.7); } var c = Math.cos(this.zs), s = Math.sin(this.zs); nx = ax * c - az * s; az = ax * s + az * c; ax = nx; }
        else if (this.zs) { c = Math.cos(this.zs); s = Math.sin(this.zs); nx = ax * c - az * s; az = ax * s + az * c; ax = nx; }
        var r = this.steer(this.pos.x + ax * 9, this.pos.z + az * 9, sp.run, dt);
        if (r === 'blocked') { this.zs = (rnd() < 0.5 ? -1 : 1) * (1.2 + rnd() * 0.6); this.path = null; }
        if (this.stateT > this.dur && L > Math.max(10, sp.fear * 1.3)) { this.pickIdle(); }
        break;
      }
      case 'approach': {   // perro curioso: se acerca a unos 7 m
        if (d < 7.5) { this.state = 'watch'; this.stateT = 0; this.dur = 6 + rnd() * 8; break; }
        var rr = this.steer(pl.x - dx / d * 6.5, pl.z - dz / d * 6.5, sp.walk * 2.6, dt); if (rr === 'blocked' || this.stateT > 14) this.pickIdle();
        break;
      }
      case 'watch': {
        this.face(pl.x, pl.z, dt, 5); this.speedNow = 0;
        if (d > 26) this.pickIdle();
        else if (d < 4.2) this.steer(this.pos.x - dx / d * 4, this.pos.z - dz / d * 4, sp.walk * 2, dt);
        if ((this.noiseCD -= dt) <= 0) { this.noiseCD = 4 + rnd() * 5; say(this, 'alert'); if (d < 18) G.noise(this.pos.x, this.pos.y, this.pos.z, 14, 'enemy', { threat: 0, tx: this.pos.x, tz: this.pos.z, from: this }); }
        if (this.stateT > this.dur) this.pickWander();
        break;
      }
      case 'wander': {
        md = sp.dart ? 2.4 : sp.walk;
        var w = this.target ? this.steer(this.target.x, this.target.z, md, dt) : true;
        if (w === true || w === 'blocked' || this.stateT > this.dur) { this.pickIdle(); if (sp.dart) { this.dur = 0.4 + rnd() * 1.4; this.state = 'idle'; } }
        break;
      }
      default: {   // 'idle' / 'graze'
        this.speedNow = 0;
        if (this.stateT > this.dur) {
          if (sp.curious && d > 9 && d < 24 && !G.veh && rnd() < 0.5) { this.state = 'approach'; this.stateT = 0; this.path = null; this.pgoal = null; }
          else if (this.grp && !this.leaderIsMe() && hyp(this.anchor().x - this.pos.x, this.anchor().z - this.pos.z) > 7) this.pickWander(true);
          else if (rnd() < (sp.dart ? 1 : 0.7)) this.pickWander(sp.dart);
          else this.pickIdle();
        }
      }
    }
  };
  Animal.prototype.leaderIsMe = function () { return this.grp && this.anchor() === this.home; };
  Animal.prototype.flyAway = function (dt, d) {
    this.flyT += dt; this.yaw = turn(this.yaw, this.fdir, 1 - Math.exp(-2.2 * dt));
    var v = 6.8; this.pos.x += Math.sin(this.yaw) * v * dt; this.pos.z += Math.cos(this.yaw) * v * dt; this.speedNow = v;
    this.pos.y += (gH(this.pos.x, this.pos.z) + this.altAim - this.pos.y) * Math.min(1, 1.5 * dt);
    if (G.pushOut) G.pushOut(this.pos, null, G.boxes, 0.25, this.pos.y - 0.1, this.pos.y + 0.3);
    if (this.flyT > 14 || d > 75) this.rm = true;
  };

  // ---------------------------------------------------------------- animales infectados
  Animal.prototype.perceive = function (d, dx, dz) {
    var sp = this.sp, pl = G.player, plp = G.ctrl.pos, env = G.env, saw = false, lit = false;
    var range = sp.zsight * (pl.visibility == null ? 1 : pl.visibility) * (G.diff && G.diff.sight || 1) * (G.wxSight || 1) * (0.65 + 0.35 * (1 - (env.night || 0)));
    if (d < Math.max(range, 5) && Math.abs(plp.y - this.pos.y) < (this.fly ? 12 : 4)) {
      var inCone = Math.abs(wrapPi(this.yaw - Math.atan2(dx, dz))) < 1.35;
      if (inCone || d < 6) {
        var eye = { x: this.pos.x, y: this.pos.y + sp.h * this.scale * 0.8, z: this.pos.z };
        if (G.lineClear(eye, { x: plp.x, y: plp.y + pl.h * 0.85, z: plp.z }, G.boxes) || G.lineClear(eye, { x: plp.x, y: plp.y + pl.h * 0.5, z: plp.z }, G.boxes)) saw = true;
      }
    }
    if (!saw && env.flashOn && d < 30 * (0.3 + 0.7 * (env.night || 0)) * (G.diff && G.diff.sight || 1) && G.lineClear({ x: this.pos.x, y: this.pos.y + 0.5, z: this.pos.z }, { x: plp.x, y: plp.y + pl.h * 0.9, z: plp.z }, G.boxes)) lit = true;
    this.canSee = saw; this.lit = lit;
    if (saw) { this.aware = Math.min(1.5, this.aware + (d < 8 ? 1.6 : 0.7)); this.lastKnown = { x: plp.x, z: plp.z }; this.lostT = 0; }
    else { this.aware = Math.max(0, this.aware - 0.08); this.lostT += 0.25; }
    if (this.state !== 'chase') {
      if (this.aware >= 1) this.startChase();
      else if (lit && (this.state === 'idle' || this.state === 'wander' || this.state === 'graze')) { this.state = 'investigate'; this.target = { x: plp.x, z: plp.z }; this.stateT = 0; this.path = null; this.pgoal = null; }
    } else if (this.lostT > 6) { this.state = 'search'; this.target = this.lastKnown ? { x: this.lastKnown.x, z: this.lastKnown.z } : { x: this.pos.x, z: this.pos.z }; this.stateT = 0; this.path = null; this.pgoal = null; this.charge = null; }
  };
  Animal.prototype.startChase = function (fromGroup) {
    if (!this.alive || !this.z || this.state === 'chase') return;
    var pl = G.ctrl.pos; this.state = 'chase'; this.stateT = 0; this.aware = 1.2; this.lostT = 0; this.path = null; this.pgoal = null; this.dirT = 0;
    if (!this.lastKnown) this.lastKnown = { x: pl.x, z: pl.z };
    if (!fromGroup) {
      say(this, 'idle');
      if (this.noiseCD <= 0) { this.noiseCD = 8; G.noise(this.pos.x, this.pos.y, this.pos.z, 16, 'enemy', { threat: 0, tx: this.lastKnown.x, tz: this.lastKnown.z, from: this }); }
      if (!shownZ) { shownZ = true; toast('¡Un animal infectado te ha visto!', 'warn', 3500); }
      if (this.grp) for (var i = 0; i < this.grp.m.length; i++) { var m = this.grp.m[i]; if (m !== this && m.alive && hyp(m.pos.x - this.pos.x, m.pos.z - this.pos.z) < 22) { m.lastKnown = { x: this.lastKnown.x, z: this.lastKnown.z }; m.startChase(true); } }
    }
  };
  Animal.prototype.hear = function (n) {
    if (!this.alive) return; var d = hyp(n.x - this.pos.x, n.z - this.pos.z);
    if (!this.z) { if (n.radius >= 22 && d < n.radius * 0.85 && !this.fly) this.scare(n.x, n.z, 5 + rnd() * 3); return; }
    var r = n.radius * (G.diff && G.diff.hear || 1) * (G.wxHear || 1); if (d > r) return;
    if (!G.lineClear({ x: n.x, y: n.y + 1, z: n.z }, { x: this.pos.x, y: this.pos.y + 0.6, z: this.pos.z }, G.boxes)) { r *= 0.5; if (d > r) return; }
    var tx = n.tx != null ? n.tx : n.x, tz = n.tz != null ? n.tz : n.z;
    if (this.state === 'chase') { if (!this.canSee) { this.lastKnown = { x: tx, z: tz }; this.lostT = 0; } return; }
    if (d < r * 0.3) this.aware = Math.max(this.aware, 0.4);
    this.state = 'investigate'; this.target = { x: tx, z: tz }; this.stateT = 0; this.path = null; this.pgoal = null; this.dirT = 0;
  };
  Animal.prototype.bite = function (mult) {
    var sp = this.sp; this.cool = sp.zcool * (G.diff && G.diff.cool || 1); this.attackT = 0.35; say(this, 'attack');
    try { G.hurtPlayer(sp.zdmg * (mult || 1), this); } catch (e) { /* sin jugador */ }
  };
  Animal.prototype.zombieAI = function (dt) {
    var sp = this.sp, pl = G.ctrl.pos, dx = pl.x - this.pos.x, dz = pl.z - this.pos.z, d = hyp(dx, dz), st = this.state;
    if (d > 110 && st !== 'chase') { this.speedNow = 0; return; }
    this.noiseCD = Math.max(0, this.noiseCD - dt); this.leapCD = Math.max(0, this.leapCD - dt); this.chargeCD = Math.max(0, this.chargeCD - dt);
    if ((this.tickT -= dt) <= 0) { this.tickT = 0.25; this.perceive(d, dx, dz); st = this.state; }
    this.snd -= dt; if (this.snd <= 0) { this.snd = (st === 'chase' ? 2.2 : 5.5) + rnd() * 5; if (d < 50) say(this, 'idle'); }
    if (this.leap) { this.leapStep(dt, d); return; }
    if (this.charge) { this.chargeStep(dt, d); return; }
    if (this.fly && st !== 'chase') { this.zombieFly(dt, d); return; }
    switch (st) {
      case 'chase': this.chase(dt, d, dx, dz); break;
      case 'investigate': {
        var r = this.target ? this.steer(this.target.x, this.target.z, sp.zwalk * 1.9, dt) : true;
        if (r === true || r === 'blocked' || this.stateT > 20) { this.state = 'search'; this.stateT = 0; }
        break;
      }
      case 'search': {
        this.speedNow = 0; if (this.target && hyp(this.target.x - this.pos.x, this.target.z - this.pos.z) > 1.5 && this.stateT < 4) { var r2 = this.steer(this.target.x, this.target.z, sp.zwalk * 1.5, dt); if (r2 === 'blocked') this.stateT = 99; }
        if (this.stateT > 7) { this.aware = 0; this.pickWander(); this.state = 'idle'; this.dur = 1; this.stateT = 0; }
        break;
      }
      case 'wander': {
        var r3 = this.target ? this.steer(this.target.x, this.target.z, sp.zwalk, dt) : true;
        if (r3 === true || r3 === 'blocked' || this.stateT > this.dur) { this.state = 'idle'; this.stateT = 0; this.dur = 1.5 + rnd() * 4; }
        break;
      }
      default:
        this.speedNow = 0;
        if (this.stateT > this.dur) { if (!this.pickWander()) { this.state = 'idle'; this.dur = 2; } }
    }
  };
  Animal.prototype.chase = function (dt, d, dx, dz) {
    var sp = this.sp, pl = G.ctrl.pos, tgt = this.canSee || !this.lastKnown ? { x: pl.x, z: pl.z } : this.lastKnown;
    var dy = this.fly ? Math.abs(pl.y + 1.3 - this.pos.y) : Math.abs(pl.y - this.pos.y);
    if (d < sp.zreach + 0.3 && dy < (this.fly ? 1.5 : 1.7) && (this.canSee || d < 1.2)) {
      this.face(pl.x, pl.z, dt, 12); this.speedNow = 0;
      if (this.cool <= 0 && this.stun <= 0) this.bite(); return;
    }
    // trucos de cada especie
    if (this.canSee && d > 2.2) {
      if (sp.charge && this.chargeCD <= 0 && d > 4 && d < 16) { this.charge = { t: 0, wind: 0.85, dir: Math.atan2(dx, dz), hit: false }; this.speedNow = 0; say(this, 'attack'); return; }
      if (sp.leap && this.leapCD <= 0 && d > 2.0 && d < 4.4 && dy < 1.2) { this.leap = { t: 0, dur: 0.42, sx: this.pos.x, sz: this.pos.z, tx: pl.x - dx / d * 0.5, tz: pl.z - dz / d * 0.5, hit: false }; this.leapCD = 2.6 + rnd() * 1.5; return; }
    }
    if (this.fly) { this.flyChase(dt, d, tgt); return; }
    var r = this.steer(tgt.x, tgt.z, sp.zchase, dt);
    if (r === 'blocked') this.lostT += dt * 2;
    else if (r === true && !this.canSee) this.lostT += dt * 3;
  };
  Animal.prototype.zombieFly = function (dt, d) {   // pájaro infectado sin objetivo: planea en círculos cerca de su sitio, o va hacia el ruido
    var st = this.state, tx = null, tz = null, v = 3.0;
    if ((st === 'investigate' || st === 'search') && this.target) { tx = this.target.x; tz = this.target.z; v = 4.2; if (hyp(tx - this.pos.x, tz - this.pos.z) < 2 || this.stateT > (st === 'search' ? 7 : 18)) { this.state = 'wander'; this.stateT = 0; this.aware = 0; tx = null; } }
    if (tx == null) { var hx = this.home.x - this.pos.x, hz = this.home.z - this.pos.z; this.circ = this.circ || (rnd() < 0.5 ? -1 : 1); this.yaw += 0.55 * this.circ * dt; if (hyp(hx, hz) > 16) this.yaw = turn(this.yaw, Math.atan2(hx, hz), 1 - Math.exp(-1.5 * dt)); }
    else this.yaw = turn(this.yaw, Math.atan2(tx - this.pos.x, tz - this.pos.z), 1 - Math.exp(-3 * dt));
    this.pos.x += Math.sin(this.yaw) * v * dt; this.pos.z += Math.cos(this.yaw) * v * dt; this.speedNow = v;
    this.pos.y += (gH(this.pos.x, this.pos.z) + 3.4 + Math.sin(this.t * 0.8 + this.phase) * 0.8 - this.pos.y) * Math.min(1, 1.2 * dt);
    if (G.pushOut) G.pushOut(this.pos, null, G.boxes, 0.25, this.pos.y - 0.1, this.pos.y + 0.3);
  };
  Animal.prototype.flyChase = function (dt, d, tgt) {
    var sp = this.sp, want = Math.atan2(tgt.x - this.pos.x, tgt.z - this.pos.z), v = this.backT > 0 ? -2.5 : sp.zchase * (G.diff && G.diff.speed || 1);
    this.backT = Math.max(0, (this.backT || 0) - dt); this.yaw = turn(this.yaw, want, 1 - Math.exp(-6 * dt));
    this.pos.x += Math.sin(this.yaw) * v * dt; this.pos.z += Math.cos(this.yaw) * v * dt; this.speedNow = Math.abs(v);
    var alt = G.ctrl.pos.y + 1.3 + Math.sin(this.t * 4) * 0.5; if (this.backT > 0) alt += 1.2;
    this.pos.y += (Math.max(gH(this.pos.x, this.pos.z) + 0.4, alt) - this.pos.y) * Math.min(1, 4 * dt);
    if (G.pushOut) G.pushOut(this.pos, null, G.boxes, 0.25, this.pos.y - 0.1, this.pos.y + 0.3);
  };
  Animal.prototype.leapStep = function (dt, d) {
    var L = this.leap; L.t += dt; var k = clamp(L.t / L.dur, 0, 1), px = this.pos.x, pz = this.pos.z;
    this.pos.x = lerp(L.sx, L.tx, k); this.pos.z = lerp(L.sz, L.tz, k); this.yOff = Math.sin(k * Math.PI) * 0.7; this.speedNow = 0; this.yaw = turn(this.yaw, Math.atan2(L.tx - L.sx, L.tz - L.sz), 0.5);
    if (G.pushOut) { var ox = this.pos.x, oz = this.pos.z; G.pushOut(this.pos, null, G.boxes, 0.3, this.pos.y + 0.3, this.pos.y + 1.0); if (hyp(this.pos.x - ox, this.pos.z - oz) > 0.05) { L.t = L.dur; } }
    if (!L.hit && k > 0.7 && hyp(G.ctrl.pos.x - this.pos.x, G.ctrl.pos.z - this.pos.z) < this.sp.zreach + 0.4 && Math.abs(G.ctrl.pos.y - this.pos.y) < 1.6) { L.hit = true; this.bite(1.2); }
    if (k >= 1) { this.leap = null; this.yOff = 0; this.cool = Math.max(this.cool, 0.4); }
  };
  Animal.prototype.chargeStep = function (dt, d) {
    var C = this.charge, pl = G.ctrl.pos; C.t += dt;
    if (C.t < C.wind) { this.speedNow = 0; this.yaw = turn(this.yaw, Math.atan2(pl.x - this.pos.x, pl.z - this.pos.z), 1 - Math.exp(-6 * dt)); C.dir = this.yaw; this.attackT = 0.2; return; }
    var run = C.t - C.wind, sx = this.pos.x, sz = this.pos.z;
    this.yaw = turn(this.yaw, C.dir, 0.5); this.moveDir(Math.sin(C.dir), Math.cos(C.dir), 7.2, dt);
    var hit = hyp(pl.x - this.pos.x, pl.z - this.pos.z) < this.sp.zreach + 0.3 && Math.abs(pl.y - this.pos.y) < 1.7;
    if (hit && !C.hit) { C.hit = true; this.bite(1.5); G.shake = Math.max(G.shake || 0, 1.4); }
    if (run > 1.5 || hit || (run > 0.25 && hyp(this.pos.x - sx, this.pos.z - sz) < 7.2 * dt * 0.25)) { this.charge = null; this.chargeCD = 6 + rnd() * 3; this.stun = 0.9; this.cool = Math.max(this.cool, 0.6); }
  };

  // ---------------------------------------------------------------- por fotograma
  Animal.prototype.update = function (dt) { var self = this; inLevel(this.pos.y, function () { self._upd(dt); }); };
  Animal.prototype._upd = function (dt) {
    this.t += dt;
    if (!this.alive) { this.deadT += dt; if (this.fly && this.deadT < 3) { this.pos.y = Math.max(gH(this.pos.x, this.pos.z), this.pos.y - 8 * dt); } this.animate(dt); return; }
    this.cool = Math.max(0, this.cool - dt); this.attackT = Math.max(0, this.attackT - dt); this.hurtT = Math.max(0, this.hurtT - dt); this.speedNow = 0;
    if (this.burnT > 0) this.burnT -= 0;   // el fuego lo gestiona Gren.burnTick
    if (this.kx || this.kz) {
      this.pos.x += this.kx * dt; this.pos.z += this.kz * dt; var f = Math.exp(-7 * dt); this.kx *= f; this.kz *= f; if (Math.abs(this.kx) + Math.abs(this.kz) < 0.05) { this.kx = 0; this.kz = 0; }
      if (G.pushOut) G.pushOut(this.pos, null, G.boxes, 0.38, this.pos.y + 0.3, this.pos.y + 1.2);
    }
    this.stateT += dt;
    if (this.pend) this.setPath(this.pend.x, this.pend.z);
    if (this.stun > 0) { this.stun -= dt; this.animate(dt); return; }
    if (this.z) this.zombieAI(dt); else this.healthyAI(dt);
    if (!this.fly && !this.leap) this.groundSnap(dt);
    // atascos: si debería moverse y no avanza, cambia de plan
    this.mv.t += dt;
    if (this.mv.t > 1.4) {
      var moved = hyp(this.pos.x - this.mv.x, this.pos.z - this.mv.z); this.mv.x = this.pos.x; this.mv.z = this.pos.z; this.mv.t = 0;
      if (moved < 0.15 && (this.state === 'wander' || this.state === 'flee' || this.state === 'chase' || this.state === 'investigate') && !this.charge && !this.fly && this.attackT <= 0 && this.cool < this.sp.zcool * 0.5) {
        if (this.state === 'wander' || this.state === 'investigate') { this.state = 'idle'; this.stateT = 0; this.dur = 0.5; } else { this.zs = (rnd() < 0.5 ? -1 : 1) * 1.3; this.path = null; this.pgoal = null; this.dirT = 0; }
      }
    }
    this.animate(dt);
  };

  Animal.prototype.animate = function (dt) {
    var M = this.model, g = M.g, p = M.p, sp = this.sp, t = this.t, i, L;
    var sc = this.scale * (this.hurtT > 0 ? 1 + 0.1 * this.hurtT / 0.18 : 1);
    g.scale.setScalar(sc);
    if (!this.alive) {
      this.deadAnim = Math.min(1, this.deadAnim + dt * 3.2); var a = this.deadAnim * Math.PI / 2, c = sp.h * 0.5, hw = sp.r * 0.5;
      g.position.set(this.pos.x, this.pos.y, this.pos.z); g.rotation.set(0, this.yaw, 0); p.rotation.set(0, 0, this.deadSide * a);
      p.position.set(this.deadSide * c * Math.sin(a), hw * Math.sin(a), 0);
      for (i = 0; i < M.legs.length; i++) M.legs[i].rotation.x = lerp(M.legs[i].rotation.x, 0.5 * (i % 2 ? 1 : -1), 0.2);
      if (M.head) M.head.rotation.x = 0.3;
      for (i = 0; i < M.wings.length; i++) M.wings[i].rotation.z = M.wings[i].userData.s * 0.5;
      if (this.deadT > 24) { var k = clamp(1 - (this.deadT - 24) / 4, 0.01, 1); g.scale.setScalar(sc * k); }
      return;
    }
    var moving = this.speedNow > 0.05, yo = this.yOff, ph = 0, amp;
    if (sp.hop) { yo = Math.max(0, Math.sin(this.hopP)) * (moving ? (this.state === 'flee' || this.state === 'chase' ? 0.2 : 0.12) : 0); if (this.leap) yo = this.yOff; }
    else if (moving && !this.fly) { this.phase += this.speedNow * sp.stride * dt; yo = Math.abs(Math.sin(this.phase)) * 0.018 * this.scale * (sp.h > 1 ? 2 : 1); }
    if (this.leap) yo = this.yOff;
    var shamble = this.z ? 1 : 0;
    g.position.set(this.pos.x, this.pos.y + yo, this.pos.z); g.rotation.set(0, this.yaw, 0);
    var roll = 0, pitch = 0;
    if (shamble && !this.fly) { roll = Math.sin(t * 3.3 + this.phase) * (moving ? 0.07 : 0.03); pitch = 0.05; }
    if (this.fly) { pitch = this.z && this.state === 'chase' ? 0.25 : -0.2; roll = Math.sin(t * 5) * 0.12; }
    if (sp.hop && moving) pitch = Math.cos(this.hopP) * -0.25;
    if (this.attackT > 0) { var lk = this.attackT / 0.35; pitch += 0.25 * lk; g.position.x += Math.sin(this.yaw) * 0.22 * lk * this.scale; g.position.z += Math.cos(this.yaw) * 0.22 * lk * this.scale; }
    if (this.charge && this.charge.t < this.charge.wind) pitch += Math.sin(t * 28) * 0.05 - 0.05;
    p.rotation.set(pitch, 0, roll); p.position.set(0, 0, 0);
    // patas
    if (!sp.hop) { amp = sp.swing * clamp(this.speedNow / Math.max(1, sp.run * 0.5), 0.3, 1.25); for (i = 0; i < M.legs.length; i++) { L = M.legs[i]; L.rotation.x = moving ? Math.sin(this.phase + L.userData.ph) * amp : L.rotation.x * (1 - Math.min(1, 10 * dt)); } }
    else {
      var f = Math.max(0, Math.sin(this.hopP)); for (i = 0; i < M.legs.length; i++) { L = M.legs[i]; var back = i > 1; L.rotation.x = moving ? (back ? -f * 0.9 : f * 0.7) : L.rotation.x * 0.8; }
    }
    // cabeza
    if (M.head) {
      var hp = 0, hr = 0;
      if (this.state === 'graze' && !this.z) hp = sp.peck ? 0.9 * Math.max(0, Math.sin(t * 9 + this.phase)) : (sp.graze || 0.5) * 0.9 + Math.sin(t * 2.2) * 0.06;
      else if (this.state === 'watch') hp = -0.1 + Math.sin(t * 1.5) * 0.05;
      else if (this.state === 'idle' && sp.peck) hp = 0.3 * Math.max(0, Math.sin(t * 3 + this.phase));
      if (this.z) { hr = Math.sin(t * 2.1 + this.phase) * 0.28; hp += 0.12 + Math.sin(t * 3.7) * 0.08; }
      if (this.attackT > 0) hp = -0.5 * (this.attackT / 0.35);
      if (this.charge && this.charge.t < this.charge.wind) hp = 0.7;
      M.head.rotation.x = lerp(M.head.rotation.x, hp, 1 - Math.exp(-12 * dt)); M.head.rotation.z = lerp(M.head.rotation.z, hr, 1 - Math.exp(-8 * dt));
    }
    // alas
    for (i = 0; i < M.wings.length; i++) { var W = M.wings[i], s = W.userData.s; W.rotation.z = this.fly ? s * Math.sin(t * (this.z ? 20 : 27) + (this.z ? i * 0.9 : 0)) * 0.85 : s * -1.15; }
  };

  // ======================================================================== director de animales
  function cfg() { return (G.S && G.S.animals) || 'many'; }
  function capN() { var m = cfg(); if (m === 'off') return 0; var q = ({ low: 6, medium: 10, high: 15 })[G.qualityName] || 10; return Math.max(2, Math.round(q * (m === 'few' ? 0.5 : 1))); }
  function hardMode() { return !!(G.S && G.S.mode === 'dificil'); }
  function zoneOf(x, z) { try { if (TER && TER.active && TER.active(x, z)) return 2; } catch (e) { /* nada */ } return z > 38 ? 1 : 0; }
  function counts() { var a = 0, zz = 0; for (var i = 0; i < list.length; i++) { var m = list[i]; if (m.alive) { a++; if (m.z) zz++; } } return { n: a, z: zz }; }
  function chooseKey(zone, zomb) {
    var night = G.env.night || 0, tot = 0, ws = KEYS.map(function (k) {
      var w = SP[k].w[zone] + (zomb ? 0.25 : 0); if (k === 'pajaro') w *= (1 - 0.85 * night); else if (k === 'rata') w *= 0.7 + 0.7 * night; else if (k === 'gato') w *= 0.8 + 0.5 * night; tot += w; return w;
    });
    var r = rnd() * tot; for (var i = 0; i < KEYS.length; i++) { r -= ws[i]; if (r <= 0) return KEYS[i]; } return 'conejo';
  }
  function spawnGroup(x, z, key, zomb) {
    var zone = zoneOf(x, z); key = key || chooseKey(zone, zomb); var sp = SP[key], rg = zomb ? sp.zgrp : sp.grp, n = rg[0] + Math.floor(rnd() * (rg[1] - rg[0] + 1)), grp = { id: ++groups, m: [] }, made = [], ci;
    ci = Math.floor(rnd() * COATS[key].length);
    for (var i = 0; i < n; i++) {
      var px = x + (rnd() - 0.5) * 6, pz = z + (rnd() - 0.5) * 6, c = G.nav.nearest(px, pz, 4); if (!c) continue;
      if (G.inside && G.inside({ x: c.x, y: gH(c.x, c.z) + 0.5, z: c.z })) continue;
      var a = new Animal(key, zomb, c.x, c.z, ci, grp); grp.m.push(a); list.push(a); made.push(a);
      if (zomb && sp.fly) { a.fly = true; a.pos.y += 3.4; a.state = 'wander'; }
      else if (zomb) { a.pickWander(); a.state = 'idle'; a.dur = 1 + rnd() * 3; } else if (sp.fly) { a.state = 'idle'; a.dur = 1 + rnd() * 3; } else a.pickIdle();
    }
    return made;
  }
  function visibleFromPlayer(x, y, z) { try { return G.lineClear(G.camera.position, { x: x, y: y, z: z }, G.boxes); } catch (e) { return false; } }
  function spawnNear() {
    var p = G.ctrl.pos, gy = gH(p.x, p.z); if (p.y - gy > 4.5 || G.sleeping) return false;
    var c = counts(), cap = capN(); if (c.n >= cap) return false;
    return inLevel(0, function () {
      for (var t = 0; t < 8; t++) {
        var a = rnd() * T2, r = 28 + rnd() * 40, x = p.x + Math.sin(a) * r, z = p.z + Math.cos(a) * r;
        if (!G.nav.walkableAt(x, z)) continue;
        if (TER && TER.depth && TER.depth(x, z) > 0.2) continue;
        if (G.inside && G.inside({ x: x, y: gH(x, z) + 0.5, z: z })) continue;
        if (r < 46 && visibleFromPlayer(x, gH(x, z) + 0.6, z)) continue;
        var zomb = hardMode() && rnd() < 0.34 + 0.24 * (G.env.night || 0) && c.z < Math.ceil(cap * 0.6);
        return spawnGroup(x, z, null, zomb).length > 0;
      }
      return false;
    });
  }
  function remove(a, idx) { a.dispose(); if (idx == null) idx = list.indexOf(a); if (idx >= 0) list.splice(idx, 1); }
  function clearAll() { for (var i = list.length - 1; i >= 0; i--) remove(list[i], i); foes.length = 0; }
  function clearZombies() { for (var i = list.length - 1; i >= 0; i--) if (list[i].z) remove(list[i], i); }

  // ---- ajustes: Muchos / Pocos / Sin animales
  function addUI() {
    var note = document.getElementById('modeNote'); if (!note || document.getElementById('sAnimals')) return;
    var row = document.createElement('div'); row.className = 'row';
    row.innerHTML = '<label>Animales</label><select id="sAnimals"><option value="many">Muchos</option><option value="few">Pocos</option><option value="off">Sin animales</option></select><span class="note">en Difícil, algunos están infectados</span>';
    note.parentNode.insertBefore(row, note.nextSibling);
    var sel = row.querySelector('select'); sel.value = cfg();
    sel.addEventListener('change', function () {
      G.S.animals = sel.value; try { Store.set('settings', G.S); } catch (e) { /* sin guardado */ }
      if (sel.value === 'off') clearAll();
    });
  }

  // ---- ruidos: los infectados reaccionan y los sanos se asustan con los disparos
  var onoise = G.noise;
  G.noise = function (x, y, z, radius, src, extra) {
    var r = onoise.apply(this, arguments);
    if (src === 'player' && list.length) { var n = { x: x, y: y, z: z, radius: radius, src: src, tx: extra && extra.tx, tz: extra && extra.tz }; for (var i = 0; i < list.length; i++) { try { list[i].hear(n); } catch (e) { /* nada */ } } }
    return r;
  };
  G.animalFoes = function () { return foes; };

  var started = false, last = performance.now(), warned = false, lastMode = null, seedN = 0, spawnT = 0.5, slowT = 0;
  function loop(now) {
    requestAnimationFrame(loop);
    var dt = Math.min((now - last) / 1000, 0.1); last = now;
    try {
      var st = G.state;
      if (st === 'menu') { if (started) { started = false; clearAll(); } return; }
      if (!started && (st === 'play')) { started = true; seedN = 40; lastMode = hardMode(); addUI(); }
      if (!started || st !== 'play') return;
      var hard = hardMode();
      if (hard !== lastMode) {
        lastMode = hard;
        if (!hard) clearZombies(); else if (cfg() !== 'off') toast('Modalidad Difícil: ¡hay animales infectados!', 'warn', 4500);
        shownZ = false;
      }
      if (cfg() === 'off') { if (list.length) clearAll(); return; }
      // aparición
      spawnT -= dt;
      if (spawnT <= 0) { spawnT = seedN > 0 ? 0.08 : 1.1 + rnd() * 1.2; if (seedN > 0) seedN--; spawnNear(); }
      // cap por calidad / ajuste
      var cap = capN(), c = counts(), over = c.n - cap;
      for (var i = list.length - 1; i >= 0; i--) {
        var a = list[i], d = hyp(G.ctrl.pos.x - a.pos.x, G.ctrl.pos.z - a.pos.z);
        if (a.rm || (!a.alive && a.deadT > 28) || (a.alive && d > (a.z && a.state === 'chase' ? 150 : a.z ? 125 : 100))) { remove(a, i); continue; }
        if (over > 0 && a.alive && d > 60 && a.state !== 'chase') { remove(a, i); over--; continue; }
        a.mesh.visible = d < 95;
        if (a.mesh.visible || a.alive) a.update(dt);
      }
      foes.length = 0; for (var j = 0; j < list.length; j++) if (list[j].alive) foes.push(list[j]);
      if (fixKills > 0) { G.kills = Math.max(0, G.kills - fixKills); fixKills = 0; }   // los animales sanos no cuentan como infectados derrotados
    } catch (err) { if (!warned) { warned = true; console.error('[animales]', err); } }
  }

  addUI();
  window.VERT_AN = { makeModel: makeModel, COATS: COATS, list: list, SP: SP, KEYS: KEYS, cap: capN, hard: hardMode, Animal: Animal, foes: function () { return foes; },
    spawn: function (key, zomb, x, z) { return inLevel(0, function () { return spawnGroup(x, z, key, !!zomb); }); }, spawnNear: spawnNear, clear: clearAll };
  requestAnimationFrame(loop);
})();
