/*!
 * VÉRTICE · Celular y mapa (celular.js, v2.5)
 *
 * Un celular de bolsillo que se abre con P (o el botón 📱) y un mapa para guiarse (M, o la app «Mapa»).
 *  - Batería PROPIA del celular: 100 % en el modo historia, 30 % en el modo libre. Se gasta sola (más con la pantalla, la linterna o la música).
 *    Se recarga con una «Batería» de la mochila (Configuración). Sin batería el celular se apaga.
 *  - Apps: Mensajes, Contactos, Galería, Mapa, Notas, Configuración, Videos, Música, Navegador, Linterna, Calculadora, PH (sin señal) y Cámara.
 *  - Mapa: minimapa arriba a la derecha (gira contigo, N = norte, punto rojo = objetivo) y mapa completo en la app «Mapa»
 *    (zoom, arrastrar, zonas y edificios; en la torre, plano de cada piso).
 *  - Cámara: saca fotos de lo que ves y las guarda en la Galería (hasta 12, solo durante la sesión).
 *  - Música por el altavoz hace ruido y atrae infectados; con auriculares no. La linterna del celular también se nota de cerca.
 *  - Se engancha a `window.VERTICE` como supervivientes.js y animales.js. Para quitarlo, borra la línea <script src="celular.js">.
 */
(function () {
  'use strict';
  var G = window.VERTICE, THREE = window.THREE;
  if (!G || !THREE || !G.LEVEL || !G.ui || !G.ps || !G.camera || !G.ctrl) return;
  var LEVEL = G.LEVEL, STORY = !!LEVEL.towerBox, FH = LEVEL.FH || 3.2, NF = LEVEL.NF || 1;
  var $ = function (id) { return document.getElementById(id); };
  var clamp = function (v, a, b) { return Math.max(a, Math.min(b, v)); };
  var toast = function (m, k, ms) { try { G.ui.toast(m, k || '', ms || 3000); } catch (e) { /* sin interfaz */ } };
  var esc = function (s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); };
  var coarse = !!G.coarse;

  // ======================================================================== estado
  var P = { bat: STORY ? 100 : 30, torch: false, saver: false, mini: true, note: '', photos: [], unlockedUntil: 0 };
  var started = false, pending = null, last = performance.now(), warned = false, w15 = false, w5 = false;
  var isOpen = false, app = null, camMode = false, shot = false, locked = true, noiseT = 0;

  // ======================================================================== utilidades de mundo
  function hours() { var t = G.env ? G.env.t : 0.3; return ((t % 1) + 1) % 1 * 24; }
  function clockText() { var h = hours(), hh = Math.floor(h), mm = Math.floor((h - hh) * 60); return (hh < 10 ? '0' : '') + hh + ':' + (mm < 10 ? '0' : '') + mm; }
  function dayN() { return G.env && G.env.dayCount ? G.env.dayCount : 1; }
  function floorOf(y) { return STORY ? clamp(Math.round((y || 0) / FH) + 1, 1, NF) : 1; }
  function batCount() { try { return G.ps.inv.count('bateria'); } catch (e) { return 0; } }

  // ======================================================================== objetivo (punto rojo)
  function cont(id) { try { return G.containerById(id); } catch (e) { return null; } }
  function inter(name) { for (var i = 0; i < LEVEL.interiors.length; i++) if (LEVEL.interiors[i].name === name) return LEVEL.interiors[i]; return null; }
  function cen(r) { return { x: (r.x0 + r.x1) / 2, z: (r.z0 + r.z1) / 2 }; }
  function objective() {
    var steps = G.STORY_STEPS, st = G.story; if (!steps || !st) return null;
    var s = steps[st.step]; if (!s) return null;
    var id = s.id, p = null, y17 = STORY ? LEVEL.Yf(17) : 0, y = 0, c;
    if (id === 'taquilla') { c = cont('taquilla_sala'); if (c) { p = { x: c.x, z: c.z }; y = y17; } }
    else if (id === 'aviso') { var n = null; LEVEL.notes.forEach(function (q) { if (q.id === 'n_aviso') n = q; }); if (n) { p = { x: n.x, z: n.z }; y = y17; } }
    else if (id === 'salir') {
      if (STORY) { p = { x: 0, z: 0 }; y = y17; } else { var ins = inter('instalacion'); if (ins) p = { x: ins.x1 + 3, z: cen(ins).z }; }
    } else if (id === 'huida' || id === 'refugio' || id === 'lampara' || id === 'radio' || id === 'barricada') {
      c = id === 'barricada' ? cont('reserva_refugio') : null; var r = inter('refugio');
      if (c) p = { x: c.x, z: c.z }; else if (r) p = cen(r);
      y = y17;
      if (!p && STORY) p = { x: 0, z: 0 };
    } else if (id === 'antena') { c = cont('taquilla_operario'); if (c) p = { x: c.x, z: c.z }; y = 0; }
    if (!p) return null;
    return { x: p.x, z: p.z, y: y, f: floorOf(y), text: s.text, hint: s.hint || '' };
  }

  // ======================================================================== mapa base (se dibuja una sola vez por nivel)
  var bases = {};
  function base(lv) {
    var key = STORY ? 'f' + lv : 'free';
    if (bases[key]) return bases[key];
    var T = G.TERRAIN, b = { s: 0, x0: 0, z0: 0, cv: document.createElement('canvas'), w: 0, h: 0 }, g;
    if (!STORY && T) { b.s = 2; b.x0 = T.x0; b.z0 = T.z0; b.w = b.h = T.size * b.s; }
    else { var bd = LEVEL.bounds; b.s = 4; b.x0 = bd.x0; b.z0 = bd.z0; b.w = Math.round((bd.x1 - bd.x0) * b.s); b.h = Math.round((bd.z1 - bd.z0) * b.s); }
    b.cv.width = b.w; b.cv.height = b.h; g = b.cv.getContext('2d');
    g.fillStyle = '#1b1f24'; g.fillRect(0, 0, b.w, b.h);
    var X = function (x) { return (x - b.x0) * b.s; }, Z = function (z) { return (z - b.z0) * b.s; };
    var boxes = G.boxes || [];
    if (!STORY && T) {
      // relieve y agua: una muestra por cada 2 m del terreno
      var n = T.n, tmp = document.createElement('canvas'); tmp.width = tmp.height = n; var tg = tmp.getContext('2d'), img = tg.createImageData(n, n);
      for (var j = 0; j < n; j++) for (var i = 0; i < n; i++) {
        var x = T.x0 + (i + 0.5) * T.cs, z = T.z0 + (j + 0.5) * T.cs, r = 38, gr = 44, bl = 36, k = (j * n + i) * 4, act = false, h = 0, d = 0;
        try { act = T.active(x, z); if (act) { h = T.h(x, z); d = T.depth(x, z); } } catch (e) { act = false; }
        if (act) {
          if (d > 0.03) { r = 40; gr = 86; bl = 118; }
          else if (h > 22) { r = gr = bl = 222; } else if (h > 12) { var m1 = (h - 12) / 10; r = 98 + m1 * 24; gr = 96 + m1 * 20; bl = 78 + m1 * 28; } else { var m0 = clamp((h - 1) / 11, 0, 1); r = 58 + m0 * 40; gr = 92 + m0 * 4; bl = 52 + m0 * 26; }
        }
        img.data[k] = r; img.data[k + 1] = gr; img.data[k + 2] = bl; img.data[k + 3] = 255;
      }
      tg.putImageData(img, 0, 0); g.imageSmoothingEnabled = true; g.drawImage(tmp, 0, 0, b.w, b.h);
      // suelos urbanizados
      g.fillStyle = '#343942';
      for (var f = 0; f < LEVEL.floors.length; f++) { var fl = LEVEL.floors[f]; if (fl[4] > -0.5 && (fl[3] - fl[0]) > 3) g.fillRect(X(fl[0]), Z(fl[2]), (fl[3] - fl[0]) * b.s, (fl[5] - fl[2]) * b.s); }
      // edificios
      for (var q2 = 0; q2 < LEVEL.interiors.length; q2++) { var it = LEVEL.interiors[q2]; g.fillStyle = '#59606b'; g.fillRect(X(it.x0), Z(it.z0), (it.x1 - it.x0) * b.s, (it.z1 - it.z0) * b.s); }
      g.fillStyle = '#c3c9d1';
      for (var a = 0; a < boxes.length; a++) { var bx = boxes[a]; if ((bx.tag === 'wall' || bx.tag === 'solid') && bx.maxY - bx.minY > 1.4 && bx.minY > -1) g.fillRect(X(bx.minX), Z(bx.minZ), Math.max(1.5, (bx.maxX - bx.minX) * b.s), Math.max(1.5, (bx.maxZ - bx.minZ) * b.s)); }
      g.fillStyle = '#3d5a37'; var tr = LEVEL.trees || []; for (var u = 0; u < tr.length; u++) { g.beginPath(); g.arc(X(tr[u].x), Z(tr[u].z), 2.2, 0, 6.3); g.fill(); }
    } else {
      var y0 = LEVEL.Yf ? LEVEL.Yf(lv) : 0, tb = LEVEL.towerBox;
      if (lv === 1) { g.fillStyle = '#2a2f27'; g.fillRect(0, 0, b.w, b.h); }
      if (tb) { g.fillStyle = '#2c313a'; g.fillRect(X(tb[0]), Z(tb[1]), (tb[2] - tb[0]) * b.s, (tb[3] - tb[1]) * b.s); }
      var col = { wall: '#d0d5dc', solid: '#aab1bb', furniture: '#5d6571', door: '#d9a441', glass: '#6fb6d6', container: '#7f8a5a', cover: '#7a808a' };
      for (var m = 0; m < boxes.length; m++) {
        var o = boxes[m], c2 = col[o.tag]; if (!c2) continue;
        if (o.maxY < y0 + 0.5 || o.minY > y0 + 2.3) continue;
        if (lv > 1 && tb && (o.maxX < tb[0] - 1 || o.minX > tb[2] + 1 || o.maxZ < tb[1] - 1 || o.minZ > tb[3] + 1)) continue;
        g.fillStyle = c2; g.fillRect(X(o.minX), Z(o.minZ), Math.max(1.2, (o.maxX - o.minX) * b.s), Math.max(1.2, (o.maxZ - o.minZ) * b.s));
      }
    }
    bases[key] = b; return b;
  }
  function paintBase(g, w, h, cx, cz, ppm, rot, lv) {
    var b = base(lv), k = ppm / b.s;
    g.save(); g.translate(w / 2, h / 2); g.rotate(rot); g.scale(k, k); g.imageSmoothingEnabled = true;
    g.drawImage(b.cv, -(cx - b.x0) * b.s, -(cz - b.z0) * b.s); g.restore();
  }
  function w2s(x, z, w, h, cx, cz, ppm, rot) {
    var dx = (x - cx) * ppm, dz = (z - cz) * ppm, c = Math.cos(rot), s = Math.sin(rot);
    return { x: w / 2 + dx * c - dz * s, y: h / 2 + dx * s + dz * c };
  }
  function arrow(g, x, y, ang, size, col) {
    g.save(); g.translate(x, y); g.rotate(ang); g.fillStyle = col; g.strokeStyle = '#000'; g.lineWidth = 1.5;
    g.beginPath(); g.moveTo(0, -size); g.lineTo(size * 0.7, size * 0.8); g.lineTo(0, size * 0.4); g.lineTo(-size * 0.7, size * 0.8); g.closePath(); g.stroke(); g.fill(); g.restore();
  }
  function pin(g, x, y, r) {
    g.fillStyle = '#e0372c'; g.strokeStyle = '#fff'; g.lineWidth = 2; g.beginPath(); g.arc(x, y, r, 0, 6.3); g.fill(); g.stroke();
    g.fillStyle = '#fff'; g.beginPath(); g.arc(x, y, r * 0.35, 0, 6.3); g.fill();
  }

  // ======================================================================== minimapa del HUD
  var mini = null, mg = null, miniSize = 0;
  function ensureMini() {
    if (mini) return;
    mini = document.createElement('canvas'); mini.id = 'phmini'; mini.className = 'hide'; document.body.appendChild(mini); mg = mini.getContext('2d');
  }
  function drawMini() {
    ensureMini();
    var show = G.state === 'play' && P.mini && P.bat > 0 && !camMode && !document.body.classList.contains('cine');
    if (!show) { mini.classList.add('hide'); return; }
    mini.classList.remove('hide');
    var cs = Math.round(mini.getBoundingClientRect().width) || 110, dpr = Math.min(2, window.devicePixelRatio || 1), px = Math.round(cs * dpr);
    if (mini.width !== px) { mini.width = mini.height = px; }
    var p = G.ctrl.pos, yaw = G.look ? G.look.yaw : 0, lv = floorOf(p.y), ppm = (STORY ? 3.6 : 1.7) * px / 120;
    mg.setTransform(1, 0, 0, 1, 0, 0); mg.fillStyle = '#0b0e12'; mg.fillRect(0, 0, px, px);
    paintBase(mg, px, px, p.x, p.z, ppm, yaw, lv);
    var o = objective();
    if (o && (!STORY || o.f === lv)) {
      var q = w2s(o.x, o.z, px, px, p.x, p.z, ppm, yaw), lim = px / 2 - 9, dx = q.x - px / 2, dy = q.y - px / 2, d = Math.hypot(dx, dy);
      if (d > lim) { var a = Math.atan2(dy, dx); arrow(mg, px / 2 + Math.cos(a) * lim, px / 2 + Math.sin(a) * lim, a + Math.PI / 2, px * 0.045, '#e0372c'); }
      else pin(mg, q.x, q.y, px * 0.035);
    }
    arrow(mg, px / 2, px / 2, 0, px * 0.055, '#ffffff');
    // N (norte): gira al girar la vista
    var nx = px / 2 + Math.sin(yaw) * (px / 2 - px * 0.085), ny = px / 2 - Math.cos(yaw) * (px / 2 - px * 0.085);
    mg.fillStyle = '#000b'; mg.beginPath(); mg.arc(nx, ny, px * 0.065, 0, 6.3); mg.fill();
    mg.fillStyle = '#fff'; mg.font = 'bold ' + Math.round(px * 0.09) + 'px system-ui,sans-serif'; mg.textAlign = 'center'; mg.textBaseline = 'middle'; mg.fillText('N', nx, ny + 1);
    if (STORY) { mg.fillStyle = '#000b'; mg.fillRect(0, px - px * 0.16, px * 0.42, px * 0.16); mg.fillStyle = '#e8e8e8'; mg.font = 'bold ' + Math.round(px * 0.095) + 'px system-ui,sans-serif'; mg.textAlign = 'left'; mg.fillText('Piso ' + lv, 4, px - px * 0.08); }
  }

  // ======================================================================== estilos y esqueleto
  function css() {
    var st = document.createElement('style');
    st.textContent = [
      '#phbtn{position:fixed;top:calc(64px + clamp(84px,25vh,136px) + env(safe-area-inset-top,0px));right:calc(var(--m,10px) + 2 * var(--s,40px) + var(--g,6px) + 14px + (clamp(84px,25vh,136px) - var(--s,40px)) / 2);z-index:9;min-width:40px;height:40px;padding:0 10px;border-radius:20px;border:1px solid #ffffff44;background:#000a;color:#fff;font:600 15px system-ui,sans-serif;display:flex;flex-direction:column;align-items:center;justify-content:center;line-height:1.05}',
      'body.touch #phbtn{min-width:var(--s,48px);height:var(--s,48px);font-size:calc(var(--s,48px) * .4);border-radius:calc(var(--s,48px) / 2)}#phbtn small{font-size:10px;font-weight:400;opacity:.85}#phbtn.low small{color:#ff8a80;opacity:1}#phbtn.hide{display:none}',
      '#phmini{position:fixed;top:calc(56px + env(safe-area-inset-top,0px));right:calc(var(--m,10px) + 2 * var(--s,40px) + var(--g,6px) + 14px);z-index:8;width:clamp(84px,25vh,136px);height:clamp(84px,25vh,136px);border:2px solid #ffffff55;border-radius:6px;background:#000;box-shadow:0 2px 8px #000a;pointer-events:none}#phmini.hide{display:none}',
      'body.cine #phbtn,body.cine #phmini{visibility:hidden}',
      '#panel.ph{background:transparent!important;backdrop-filter:none!important;pointer-events:none!important}#panel.ph .card{display:none}',
      '#phone{position:fixed;inset:0;z-index:25;display:none;align-items:center;justify-content:flex-end;padding:0 4vw;pointer-events:none;font-family:system-ui,-apple-system,"Segoe UI",sans-serif;color:#eef2f7}#phone.on{display:flex}',
      '#phone .fr{pointer-events:auto;position:relative;height:min(94vh,640px);aspect-ratio:9/15.5;max-width:94vw;border-radius:26px;background:#000;border:5px solid #1b1d22;box-shadow:0 0 0 2px #4a4f58,0 12px 40px #000c;display:flex;flex-direction:column;overflow:hidden}',
      '#phone .sb{flex:0 0 auto;display:flex;justify-content:flex-end;align-items:center;gap:6px;padding:6px 14px 2px;font-size:11px;font-weight:600}#phone .sb .bt{display:inline-flex;align-items:center;gap:3px}',
      '#phone .bi{width:20px;height:10px;border:1.5px solid #fff;border-radius:3px;position:relative;padding:1px}#phone .bi:after{content:"";position:absolute;right:-4px;top:2px;width:2px;height:4px;background:#fff;border-radius:0 1px 1px 0}#phone .bi i{display:block;height:100%;background:#fff;border-radius:1px}#phone .bi.low i{background:#ff5a4d}',
      '#phone .hd{flex:0 0 auto;display:flex;align-items:center;gap:8px;padding:4px 14px 6px;border-bottom:1px solid #ffffff22;font-size:17px;font-weight:600}#phone .hd .t{flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}#phone .hd button{background:none;border:0;color:#cfd6de;font-size:20px;padding:2px 6px;cursor:pointer}',
      '#phone .bd{flex:1 1 auto;min-height:0;overflow:auto;position:relative;-webkit-overflow-scrolling:touch}',
      '#phone .nv{flex:0 0 auto;display:flex;justify-content:space-around;align-items:center;height:30px;border-top:1px solid #ffffff14;background:#050607}#phone .nv button{background:none;border:0;color:#d7dde4;font-size:15px;padding:2px 16px;cursor:pointer}',
      '#phone .grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px 2px;padding:12px 6px}@media (max-height:520px){#phone .grid{gap:7px 2px;padding:8px 4px}}',
      '#phone .ap{background:none;border:0;color:#eef2f7;display:flex;flex-direction:column;align-items:center;gap:4px;font-size:10px;cursor:pointer;padding:0;min-width:0;max-width:100%;white-space:nowrap}#phone .ap u{text-decoration:none;display:flex;align-items:center;justify-content:center;width:clamp(36px,11vh,56px);aspect-ratio:1;border-radius:22%;font-size:clamp(18px,5.5vh,28px);box-shadow:inset 0 0 0 1px #ffffff22,0 2px 4px #0008}',
      '#phone .pg{padding:10px 12px;font-size:13px;line-height:1.45}#phone .pg h4{margin:10px 0 4px;font-size:12px;letter-spacing:.06em;color:#9aa6b4;text-transform:uppercase}',
      '#phone .li{display:flex;align-items:center;gap:10px;padding:9px 12px;border-bottom:1px solid #ffffff14;cursor:pointer;font-size:14px}#phone .li small{display:block;color:#98a3b0;font-size:11.5px;margin-top:1px}#phone .li .av{flex:0 0 34px;height:34px;border-radius:50%;background:#3a4048;display:flex;align-items:center;justify-content:center;font-weight:700}',
      '#phone .bub{max-width:82%;padding:7px 10px;border-radius:14px;margin:5px 10px;font-size:13px;line-height:1.35;background:#262b32}#phone .bub.me{margin-left:auto;background:#2f6f3d}#phone .bub small{display:block;opacity:.6;font-size:10px;margin-top:2px}',
      '#phone .btn{background:#2a303a;border:1px solid #ffffff2e;color:#fff;border-radius:10px;padding:8px 12px;font-size:13px;cursor:pointer}#phone .btn.pri{background:#2f6fb0}#phone .btn:disabled{opacity:.4}',
      '#phone .row{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:9px 12px;border-bottom:1px solid #ffffff14;font-size:13.5px}',
      '#phone .big{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;text-align:center;padding:24px 16px;height:100%}#phone .big b{font-size:19px}#phone .big span{color:#98a3b0;font-size:13px}',
      '#phone .lock{position:absolute;inset:0;background:radial-gradient(circle at 70% 30%,#6c6a9c 0,#2a2c4a 28%,#0b0d18 70%);display:flex;flex-direction:column;align-items:center;padding-top:16%;cursor:pointer;z-index:3}#phone .lock .tm{font-size:clamp(36px,10vh,56px);font-weight:300}#phone .lock .dt{font-size:13px;opacity:.8}#phone .lock .hint{position:absolute;bottom:9%;font-size:12px;opacity:.85;text-align:center}',
      '#phone .off{position:absolute;inset:0;background:#000;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;z-index:4;text-align:center;padding:16px}',
      '#phone canvas.mapc{display:block;width:100%;height:100%;touch-action:none;background:#0b0e12}#phone .mapb{position:absolute;right:6px;top:6px;display:flex;flex-direction:column;gap:5px}#phone .mapb.fl2{right:auto;left:6px;top:74px}#phone .mapb button{width:30px;height:30px;border-radius:50%;border:1px solid #ffffff44;background:#000b;color:#fff;font-size:17px;cursor:pointer}',
      '#phone .mapl{position:absolute;left:0;right:0;bottom:0;padding:6px 10px;background:#000c;font-size:11.5px;line-height:1.3}',
      '#phone .calc{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;padding:8px}#phone .calc button{height:clamp(30px,8.2vh,46px);border-radius:50%;border:0;background:#2b3038;color:#fff;font-size:17px;cursor:pointer}#phone .calc .op{background:#e08a1e}#phone .calc .fn{background:#555c68}#phone .calc .z{grid-column:span 2;border-radius:24px;text-align:left;padding-left:18px}',
      '#phone .cd{font-size:34px;text-align:right;padding:14px 14px 4px;font-weight:300;overflow:hidden;white-space:nowrap}',
      '#phone textarea{width:100%;min-height:110px;background:#161a1f;color:#eef2f7;border:1px solid #ffffff26;border-radius:8px;padding:8px;font:13px/1.4 system-ui,sans-serif;resize:vertical}',
      '#phone .ph{display:grid;grid-template-columns:repeat(3,1fr);gap:4px;padding:8px}#phone .ph img{width:100%;aspect-ratio:4/3;object-fit:cover;border-radius:4px;cursor:pointer;display:block}',
      '#phcam{position:fixed;inset:0;z-index:25;display:none;pointer-events:none}#phcam.on{display:block}#phcam .vf{position:absolute;inset:8% 14%;border:2px solid #ffffff88;border-radius:6px}#phcam .vf:before,#phcam .vf:after{content:"";position:absolute;background:#ffffff40}#phcam .vf:before{left:33.3%;right:33.3%;top:0;bottom:0;border-left:1px solid #fff4;border-right:1px solid #fff4;background:none}#phcam .vf:after{top:33.3%;bottom:33.3%;left:0;right:0;border-top:1px solid #fff4;border-bottom:1px solid #fff4;background:none}',
      '#phcam .sh{pointer-events:auto;position:absolute;right:max(18px,env(safe-area-inset-right,0px));top:50%;transform:translateY(-50%);width:68px;height:68px;border-radius:50%;border:4px solid #fff;background:#ffffff33;cursor:pointer}#phcam .sh:active{background:#fff}#phcam .bk{pointer-events:auto;position:absolute;left:max(14px,env(safe-area-inset-left,0px));top:12px;border:0;border-radius:18px;background:#000a;color:#fff;font-size:14px;padding:8px 14px;cursor:pointer}#phcam .tx{position:absolute;left:0;right:0;bottom:10px;text-align:center;font-size:12px;color:#fff;text-shadow:0 1px 3px #000}',
      '#phcam .fl{position:absolute;inset:0;background:#fff;opacity:0;transition:opacity .25s}'
    ].join('\n');
    document.head.appendChild(st);
  }
  var root = null, body = null, hdT = null, camEl = null, btn = null;
  function build() {
    if (root) return;
    css();
    root = document.createElement('div'); root.id = 'phone';
    root.innerHTML = '<div class="fr"><div class="sb"><span id="phs4">4G</span><span id="phsb"></span><span class="bt"><span class="bi" id="phbi"><i></i></span><span id="phbp"></span></span></div>' +
      '<div class="hd"><span id="phhi">📞</span><span class="t" id="phht">Teléfono</span><button id="phx" aria-label="Cerrar">✕</button></div><div class="bd" id="phbd"></div>' +
      '<div class="nv"><button id="phnb" aria-label="Atrás">◀</button><button id="phnh" aria-label="Inicio">●</button><button id="phnc" aria-label="Cerrar">■</button></div></div>';
    document.body.appendChild(root); body = $('phbd'); hdT = $('phht');
    $('phx').onclick = $('phnc').onclick = function () { closePhone(); };
    $('phnh').onclick = function () { if (P.bat > 0) goHome(); };
    $('phnb').onclick = function () { if (app && app.back && app.back()) return; goHome(); };
    camEl = document.createElement('div'); camEl.id = 'phcam';
    camEl.innerHTML = '<div class="vf"></div><button class="bk" id="phcb">◀ Volver</button><button class="sh" id="phsh" aria-label="Tomar foto"></button><div class="tx">' + (coarse ? 'Toca el botón para sacar la foto' : 'Enter · sacar foto · Esc · volver') + '</div><div class="fl" id="phfl"></div>';
    document.body.appendChild(camEl);
    $('phcb').onclick = function () { exitCam(true); }; $('phsh').onclick = function () { takeShot(); };
    btn = document.createElement('button'); btn.id = 'phbtn'; btn.className = 'hide'; btn.setAttribute('aria-label', 'Celular'); document.body.appendChild(btn);
    btn.addEventListener('click', function (e) { e.preventDefault(); if (isOpen) closePhone(); else openPhone(); });
    ensureMini();
  }

  // ======================================================================== abrir / cerrar
  function modalOther() { return ['inv', 'loot', 'note', 'chapter', 'selftest'].some(function (i) { try { return G.ui.visible(i); } catch (e) { return false; } }) || (G.ui.visible('panel') && !isOpen); }
  function openPhone(appId) {
    if (G.state !== 'play' || isOpen || modalOther() || G.cine || !G.ps.alive) return;
    build(); isOpen = true;
    var p = $('panel'); p.classList.add('ph'); G.ui.show('panel');
    if (!coarse) { try { G.input.unlock(); } catch (e) { /* nada */ } }
    root.classList.add('on'); body.innerHTML = ''; app = null;
    if (P.bat <= 0) { dead(); } else if (appId) { P.unlockedUntil = performance.now() + 30000; run(appId); } else if (performance.now() < P.unlockedUntil) goHome(); else lockScreen();
    status();
  }
  function closePhone(noRelock) {
    if (!isOpen) return;
    isOpen = false; if (app && app.stop) app.stop(); app = null; camMode = false;
    P.unlockedUntil = performance.now() + 20000;
    if (root) root.classList.remove('on'); if (camEl) camEl.classList.remove('on');
    var p = $('panel'); p.classList.remove('ph'); if (G.ui.visible('panel')) G.ui.hide('panel');
    if (!noRelock && G.state === 'play' && !coarse) { try { G.input.lock(); } catch (e) { /* nada */ } }
  }
  function status() {
    if (!root) return;
    var pc = Math.round(P.bat), low = pc <= 15;
    $('phbi').firstChild.style.width = clamp(P.bat, 0, 100) + '%'; $('phbi').className = 'bi' + (low ? ' low' : ''); $('phbp').textContent = pc + '%';
    $('phsb').textContent = clockText();
  }
  function setHead(icon, title) { $('phhi').textContent = icon; hdT.textContent = title; }
  function goHome() { if (app && app.stop) app.stop(); app = null; camMode = false; setHead('📞', 'Teléfono'); home(); }
  function lockScreen() {
    body.innerHTML = '<div class="lock" id="phlk"><div class="tm">' + clockText() + '</div><div class="dt">Día ' + dayN() + (STORY ? ' · Torre Mirador' : '') + '</div><div class="hint">🔒<br>' + (coarse ? 'Toca para desbloquear' : 'Clic o Enter para desbloquear') + '</div></div>';
    $('phlk').onclick = function () { P.unlockedUntil = performance.now() + 30000; goHome(); };
    setHead('🔒', 'Celular');
  }
  function dead() {
    setHead('🔋', 'Sin batería'); var n = batCount();
    body.innerHTML = '<div class="off"><div style="font-size:42px">🪫</div><b>Batería agotada</b><span style="color:#98a3b0;font-size:13px">El celular está apagado.</span>' +
      '<button class="btn pri" id="phch"' + (n ? '' : ' disabled') + '>Cargar con una batería (' + n + ')</button></div>';
    $('phch').onclick = function () { if (charge()) { goHome(); } };
  }
  function charge() {
    if (!batCount()) { toast('No tienes baterías', 'warn', 1600); return false; }
    if (P.bat > 85) { toast('El celular ya está casi cargado', '', 1600); return false; }
    try { G.ps.inv.remove('bateria', 1); } catch (e) { return false; }
    P.bat = Math.min(100, P.bat + 45); w15 = w5 = false; toast('Celular cargado: ' + Math.round(P.bat) + ' %', '', 2000); status(); return true;
  }

  // ======================================================================== apps
  var APPS = [];
  function def(id, name, glyph, bg, run) { APPS.push({ id: id, name: name, glyph: glyph, bg: bg, run: run }); }
  function run(id) {
    var a = APPS.filter(function (x) { return x.id === id; })[0]; if (!a) return;
    if (app && app.stop) app.stop(); body.innerHTML = ''; setHead(a.glyph, a.name);
    app = { id: id }; var r = a.run(body, app); if (r) { app.stop = r.stop; app.back = r.back; }
  }
  function home() {
    var h = '<div class="grid">';
    APPS.forEach(function (a) {
      var ic = a.id === 'ph' ? '<u style="background:' + a.bg + ';color:#111;font-weight:900;font-size:clamp(15px,4.6vh,24px);font-family:Arial Black,Arial,sans-serif;letter-spacing:-.04em">PH</u>' : '<u style="background:' + a.bg + '">' + a.glyph + '</u>';
      h += '<button class="ap" data-a="' + a.id + '">' + ic + a.name + '</button>';
    });
    body.innerHTML = h + '</div>';
    Array.prototype.forEach.call(body.querySelectorAll('.ap'), function (b) { b.onclick = function () { run(b.getAttribute('data-a')); }; });
  }

  // ---- Mensajes
  var THREADS = STORY ? [
    { n: 'Alerta oficial', av: '⚠', msgs: [['them', 'ALERTA: Evacuación ordenada. Permanezca en su domicilio, cierre puertas y ventanas. No use los ascensores.', '03:05'], ['them', 'Protocolo 7 activo. Espere instrucciones del transporte.', '03:12']] },
    { n: 'Imbachi', av: 'I', msgs: [['them', '¿Estás en la torre? Yo bajé al patio. Hay ruido en las escaleras.', '03:20'], ['them', 'No hagas ruido, lo oyen todo. Cuando puedas búscame por el noreste del patio.', '03:22']] },
    { n: 'Valentina', av: 'V', msgs: [['them', 'Estoy en el piso 15. El ascensor no funciona y hay algo en el pasillo.', '03:31'], ['them', 'Llévate una linterna.', '03:31']] },
    { n: 'Wilmarys', av: 'W', msgs: [['them', 'Me quedé en el piso 11 con las vendas. Si te hieres, ven.', '03:40']] }
  ] : [
    { n: 'Alerta oficial', av: '⚠', msgs: [['them', 'ALERTA: Zona de cuarentena activa. Evite aglomeraciones. Siga la señal de radio de emergencia.', '02:50'], ['them', 'Transporte 3 en camino a la instalación de evacuación.', '03:12']] },
    { n: 'Imbachi', av: 'I', msgs: [['them', 'Estoy en la bodega del asentamiento. No salgas de noche sin linterna.', '04:02'], ['them', 'Si encuentras a Valentina o a Wilmarys, avísame.', '04:05']] },
    { n: 'Valentina', av: 'V', msgs: [['them', 'Estoy en la casa. Tengo agua para dos días. Cuidado con el arroyo, ahí se oye todo.', '04:30']] },
    { n: 'Wilmarys', av: 'W', msgs: [['them', 'Estoy al este del asentamiento. Si necesitas vendas, tengo.', '05:11']] }
  ];
  def('mensajes', 'Mensajes', '💬', 'linear-gradient(#58d46b,#1f9d3a)', function (el, me) {
    function list() { setHead('💬', 'Mensajes'); me.back = null; el.innerHTML = THREADS.map(function (t, i) { var l = t.msgs[t.msgs.length - 1]; return '<div class="li" data-i="' + i + '"><div class="av">' + t.av + '</div><div style="min-width:0"><b>' + esc(t.n) + '</b><small>' + esc(l[1].slice(0, 48)) + '…</small></div></div>'; }).join('');
      Array.prototype.forEach.call(el.querySelectorAll('.li'), function (b) { b.onclick = function () { thread(+b.getAttribute('data-i')); }; }); }
    function thread(i) { var t = THREADS[i]; setHead('💬', t.n); me.back = function () { list(); return true; };
      el.innerHTML = '<div style="padding:6px 0">' + t.msgs.map(function (m) { return '<div class="bub ' + (m[0] === 'me' ? 'me' : '') + '">' + esc(m[1]) + '<small>' + m[2] + '</small></div>'; }).join('') + '</div><div class="pg" style="color:#ff9a90;text-align:center">No se pueden enviar mensajes: la red está saturada.</div>'; }
    list(); return { back: function () { return me.back ? me.back() : false; } };
  });

  // ---- Contactos
  def('contactos', 'Contactos', '👤', 'linear-gradient(#6a717c,#3b4048)', function (el) {
    var C = [['Imbachi', 'I'], ['Valentina', 'V'], ['Wilmarys', 'W'], ['Emergencias 123', '✚'], ['Línea de cuarentena', '☢']];
    el.innerHTML = C.map(function (c, i) { return '<div class="li" data-i="' + i + '"><div class="av">' + c[1] + '</div><div><b>' + c[0] + '</b><small>Móvil</small></div></div>'; }).join('');
    Array.prototype.forEach.call(el.querySelectorAll('.li'), function (b) { b.onclick = function () { var c = C[+b.getAttribute('data-i')]; el.innerHTML = '<div class="big"><div class="av" style="width:64px;height:64px;border-radius:50%;background:#3a4048;display:flex;align-items:center;justify-content:center;font-size:26px">' + c[1] + '</div><b>' + c[0] + '</b><span>Llamando…</span></div>';
      setTimeout(function () { if (el.querySelector('.big span')) el.querySelector('.big span').textContent = 'Sin señal: no se pudo completar la llamada.'; }, 1800); }; });
  });

  // ---- Galería
  def('galeria', 'Galería', '🖼', 'linear-gradient(#4b7cf0,#7a3fc0)', function (el, me) {
    function grid() { setHead('🖼', 'Galería'); me.back = null;
      if (!P.photos.length) { el.innerHTML = '<div class="big"><div style="font-size:40px">🖼</div><b>Sin fotos</b><span>Saca fotos con la app Cámara.</span></div>'; return; }
      el.innerHTML = '<div class="ph">' + P.photos.map(function (p, i) { return '<img data-i="' + i + '" src="' + p.url + '" alt="Foto ' + (i + 1) + '">'; }).join('') + '</div>';
      Array.prototype.forEach.call(el.querySelectorAll('img'), function (im) { im.onclick = function () { view(+im.getAttribute('data-i')); }; }); }
    function view(i) { var p = P.photos[i]; setHead('🖼', 'Foto ' + (i + 1) + '/' + P.photos.length); me.back = function () { grid(); return true; };
      el.innerHTML = '<div style="padding:8px"><img src="' + p.url + '" style="width:100%;border-radius:6px;display:block" alt=""><div class="pg" style="text-align:center">Día ' + p.day + ' · ' + p.time + '</div><div style="text-align:center"><button class="btn" id="phdel">🗑 Borrar</button></div></div>';
      $('phdel').onclick = function () { P.photos.splice(i, 1); grid(); }; }
    grid(); return { back: function () { return me.back ? me.back() : false; } };
  });

  // ---- Cámara
  def('camara', 'Cámara', '📷', 'linear-gradient(#2d3138,#0d0f12)', function () {
    setTimeout(function () { enterCam(); }, 0); return {};
  });
  function enterCam() {
    if (!isOpen) return; camMode = true; root.classList.remove('on'); camEl.classList.add('on');
    if (!coarse) { try { G.input.lock(); } catch (e) { /* nada */ } }
  }
  function exitCam(toPhone) {
    camMode = false; camEl.classList.remove('on'); if (!isOpen) return;
    if (toPhone) { root.classList.add('on'); if (!coarse) { try { G.input.unlock(); } catch (e) { /* nada */ } } goHome(); } else closePhone();
  }
  function takeShot() { if (camMode) shot = true; }
  function grabShot() {
    shot = false;
    try {
      var src = $('c'), w = 480, h = Math.round(480 * src.height / Math.max(1, src.width)), cv = document.createElement('canvas'); cv.width = w; cv.height = h;
      cv.getContext('2d').drawImage(src, 0, 0, w, h); var url = cv.toDataURL('image/jpeg', 0.72);
      P.photos.push({ url: url, day: dayN(), time: clockText() }); if (P.photos.length > 12) P.photos.shift();
      var f = $('phfl'); f.style.transition = 'none'; f.style.opacity = '.9'; setTimeout(function () { f.style.transition = 'opacity .3s'; f.style.opacity = '0'; }, 30);
      click(); toast('Foto guardada en la Galería (' + P.photos.length + ')', '', 1500);
    } catch (e) { toast('No se pudo sacar la foto', 'warn', 1500); }
  }

  // ---- Mapa
  def('mapa', 'Mapa', '📍', 'linear-gradient(#6ec16f,#f4f4f4)', function (el, me) {
    el.innerHTML = '<canvas class="mapc"></canvas><div class="mapb"><button data-z="1" aria-label="Acercar">＋</button><button data-z="-1" aria-label="Alejar">－</button><button data-z="0" aria-label="Centrar">⌖</button></div>' + (STORY ? '<div class="mapb fl2"><button data-f="1" aria-label="Piso arriba">▲</button><button data-f="-1" aria-label="Piso abajo">▼</button></div>' : '') + '<div class="mapl"></div>';
    var cv = el.querySelector('canvas'), lg = el.querySelector('.mapl'), g = cv.getContext('2d'), p0 = G.ctrl.pos;
    var V = { cx: p0.x, cz: p0.z, ppm: STORY ? 3.4 : 2, follow: true, lv: floorOf(p0.y), manualLv: false }, raf = 0, drag = null;
    var minP = STORY ? 1.6 : 0.3, maxP = STORY ? 9 : 7;
    function fit() { var r = cv.getBoundingClientRect(), d = Math.min(2, window.devicePixelRatio || 1); if (cv.width !== Math.round(r.width * d)) { cv.width = Math.round(r.width * d); cv.height = Math.round(r.height * d); } return d; }
    function label(txt, x, z, sz, col) { var q = w2s(x, z, cv.width, cv.height, V.cx, V.cz, V.ppm * dd, 0); if (q.x < -60 || q.y < -20 || q.x > cv.width + 60 || q.y > cv.height + 20) return; g.font = '600 ' + sz + 'px system-ui,sans-serif'; g.textAlign = 'center'; g.fillStyle = '#000a'; g.fillText(txt, q.x + 1, q.y + 1); g.fillStyle = col || '#fff'; g.fillText(txt, q.x, q.y); }
    var dd = 1;
    function frame() {
      raf = requestAnimationFrame(frame); if (!isOpen || camMode) return;
      dd = fit(); var p = G.ctrl.pos, yaw = G.look ? G.look.yaw : 0, W = cv.width, H = cv.height;
      if (V.follow) { V.cx = p.x; V.cz = p.z; if (!V.manualLv) V.lv = floorOf(p.y); }
      g.setTransform(1, 0, 0, 1, 0, 0); g.fillStyle = '#0b0e12'; g.fillRect(0, 0, W, H);
      paintBase(g, W, H, V.cx, V.cz, V.ppm * dd, 0, V.lv);
      g.textBaseline = 'middle';
      if (!STORY) {
        (LEVEL.zones || []).forEach(function (z) { label(z.name.toUpperCase(), (z.x0 + z.x1) / 2, (z.z0 + z.z1) / 2, Math.round(11 * dd), '#ffe8a8aa'); });
        var big = V.ppm >= 2.2;
        LEVEL.interiors.forEach(function (r) { var nm = r.name; if (!/\d/.test(nm)) { label(nm === 'instalacion' ? 'Instalación' : nm.charAt(0).toUpperCase() + nm.slice(1), (r.x0 + r.x1) / 2, r.z0 - 2, Math.round(11 * dd), '#fff'); } else if (big && V.ppm >= 3.2) label(nm.replace(/\d+/g, ''), (r.x0 + r.x1) / 2, (r.z0 + r.z1) / 2, Math.round(9 * dd), '#cfd6de'); });
      } else if (V.lv === 17) { var rf = inter('refugio'); if (rf) label('Tu apartamento', (rf.x0 + rf.x1) / 2, (rf.z0 + rf.z1) / 2, Math.round(11 * dd), '#ffe8a8'); }
      var o = objective(), lgT = '';
      if (o) { if (!STORY || o.f === V.lv) { var q = w2s(o.x, o.z, W, H, V.cx, V.cz, V.ppm * dd, 0); pin(g, q.x, q.y, 8 * dd); } lgT = '<b style="color:#ff8a80">●</b> ' + esc(o.text) + (STORY && o.f !== V.lv ? ' <i>(piso ' + o.f + ')</i>' : ''); }
      if (!STORY || floorOf(p.y) === V.lv) { var s = w2s(p.x, p.z, W, H, V.cx, V.cz, V.ppm * dd, 0); arrow(g, s.x, s.y, -yaw, 10 * dd, '#fff'); }
      // brújula
      g.fillStyle = '#000a'; g.beginPath(); g.arc(24 * dd, 24 * dd, 15 * dd, 0, 6.3); g.fill(); g.fillStyle = '#fff'; g.font = 'bold ' + Math.round(13 * dd) + 'px system-ui,sans-serif'; g.textAlign = 'center'; g.fillText('N', 24 * dd, 24 * dd + 1);
      if (STORY) { g.fillStyle = '#000b'; g.fillRect(8 * dd, 46 * dd, 62 * dd, 20 * dd); g.fillStyle = '#fff'; g.font = '600 ' + Math.round(12 * dd) + 'px system-ui,sans-serif'; g.fillText('Piso ' + V.lv, 39 * dd, 56 * dd); }
      var html = '<b>▲</b> Tú · ' + (lgT || 'Sin objetivo marcado') + ' · ' + (V.follow ? 'siguiéndote' : 'libre (⌖ para centrar)');
      if (lg._h !== html) { lg._h = html; lg.innerHTML = html; }
    }
    el.querySelectorAll('.mapb button').forEach(function (b) { b.onclick = function () {
      var z = b.getAttribute('data-z'), f = b.getAttribute('data-f');
      if (z === '1') V.ppm = clamp(V.ppm * 1.4, minP, maxP); else if (z === '-1') V.ppm = clamp(V.ppm / 1.4, minP, maxP); else if (z === '0') { V.follow = true; V.manualLv = false; V.lv = floorOf(G.ctrl.pos.y); }
      if (f) { V.manualLv = true; V.lv = clamp(V.lv + (+f), 1, NF); }
    }; });
    cv.addEventListener('pointerdown', function (e) { drag = { x: e.clientX, y: e.clientY }; try { cv.setPointerCapture(e.pointerId); } catch (x) { /* nada */ } });
    cv.addEventListener('pointermove', function (e) { if (!drag) return; var k = 1 / V.ppm; V.cx -= (e.clientX - drag.x) * k; V.cz -= (e.clientY - drag.y) * k; drag = { x: e.clientX, y: e.clientY }; V.follow = false; });
    cv.addEventListener('pointerup', function () { drag = null; }); cv.addEventListener('pointercancel', function () { drag = null; });
    cv.addEventListener('wheel', function (e) { e.preventDefault(); V.ppm = clamp(V.ppm * (e.deltaY < 0 ? 1.15 : 1 / 1.15), minP, maxP); }, { passive: false });
    raf = requestAnimationFrame(frame);
    return { stop: function () { cancelAnimationFrame(raf); } };
  });

  // ---- Notas
  def('notas', 'Notas', '📝', 'linear-gradient(#fbf3d6,#e8d79a)', function (el, me) {
    function main() {
      setHead('📝', 'Notas'); me.back = null;
      var o = objective(), found = (G.story && G.story.notes) || [], h = '<div class="pg"><h4>Objetivo actual</h4>' + (o ? '<b>' + esc(o.text) + '</b><div style="color:#b9c4d0;margin-top:3px">' + esc(o.hint) + '</div>' : (G.STORY_STEPS && G.story && G.story.step >= G.STORY_STEPS.length ? 'Capítulo completado. Sobrevive hasta el amanecer.' : 'Sobrevive hasta el amanecer.')) + '<h4>Notas encontradas</h4></div>';
      var any = false; LEVEL.notes.forEach(function (n) { if (found.indexOf(n.id) >= 0) { any = true; h += '<div class="li" data-id="' + n.id + '"><div class="av">📄</div><div><b>' + esc(n.title) + '</b></div></div>'; } });
      if (!any) h += '<div class="pg" style="color:#98a3b0">Aún no has leído ninguna nota.</div>';
      h += '<div class="pg"><h4>Mi nota</h4><textarea id="phnt" maxlength="600" placeholder="Escribe aquí…"></textarea></div>';
      el.innerHTML = h; var ta = $('phnt'); ta.value = P.note; ta.oninput = function () { P.note = ta.value; };
      ['keydown', 'keyup', 'keypress'].forEach(function (k) { ta.addEventListener(k, function (e) { e.stopPropagation(); }); });
      Array.prototype.forEach.call(el.querySelectorAll('.li'), function (b) { b.onclick = function () { var n = LEVEL.notes.filter(function (q) { return q.id === b.getAttribute('data-id'); })[0]; if (!n) return; setHead('📝', n.title); me.back = function () { main(); return true; }; el.innerHTML = '<div class="pg">' + esc(n.text) + '</div>'; }; });
    }
    main(); return { back: function () { return me.back ? me.back() : false; } };
  });

  // ---- Configuración
  def('config', 'Configuración', '⚙', 'linear-gradient(#6d7480,#3a3f47)', function (el) {
    function draw() {
      var n = batCount();
      el.innerHTML = '<div class="row"><span>🔋 Batería</span><b>' + Math.round(P.bat) + ' %</b></div>' +
        '<div class="row"><span>Cargar con una batería<br><small style="color:#98a3b0">Tienes ' + n + ' · +45 %</small></span><button class="btn pri" id="phc"' + (n ? '' : ' disabled') + '>Cargar</button></div>' +
        '<div class="row"><span>Ahorro de energía<br><small style="color:#98a3b0">Gasta la mitad</small></span><input type="checkbox" id="phsv"' + (P.saver ? ' checked' : '') + '></div>' +
        '<div class="row"><span>Minimapa en pantalla</span><input type="checkbox" id="phmn"' + (P.mini ? ' checked' : '') + '></div>' +
        '<div class="pg" style="color:#98a3b0"><h4>Atajos</h4><b>P</b> celular · <b>M</b> mapa · <b>Esc</b> cerrar<br>La música por altavoz y la linterna del celular se oyen y se ven de cerca.</div>';
      $('phc').onclick = function () { charge(); draw(); }; $('phsv').onchange = function () { P.saver = this.checked; }; $('phmn').onchange = function () { P.mini = this.checked; };
    }
    draw();
  });

  // ---- Videos / Navegador / PH (sin conexión)
  def('videos', 'Videos', '▶', '#e53935', function (el) { el.innerHTML = '<div class="big"><div style="font-size:40px">📡</div><b>Sin conexión</b><span>No hay videos descargados.</span></div>'; });
  def('navegador', 'Navegador', '🌐', 'linear-gradient(#3b7be0,#1b3f8f)', function (el) {
    el.innerHTML = '<div class="row" style="background:#1a1e24"><span style="color:#98a3b0">🔎 Buscar o escribir dirección</span></div><div class="big"><div style="font-size:40px">🌐</div><b>No hay conexión a internet</b><span>Las torres de la zona no responden.</span><button class="btn" id="phrt">Reintentar</button></div>';
    $('phrt').onclick = function () { toast('Sin conexión', 'warn', 1200); };
  });
  def('ph', 'PH', 'PH', '#ff9000', function (el) {
    el.innerHTML = '<div class="big"><div style="font-size:42px">📵</div><b>Sin señal</b><span>No se puede conectar.</span><button class="btn" id="phrt">Reintentar</button></div>';
    $('phrt').onclick = function () { el.querySelector('span').textContent = 'Buscando señal…'; setTimeout(function () { var s = el.querySelector('span'); if (s) s.textContent = 'Sin señal.'; }, 1500); };
  });

  // ---- Linterna
    function setTorch(on) {
    if (on && P.bat <= 0) { toast('Sin batería', 'warn', 1400); on = false; }
    P.torch = on; click();
  }
  def('linterna', 'Linterna', '🔦', 'linear-gradient(#6b727d,#363b43)', function (el) {
    function draw() { el.innerHTML = '<div class="big"><div style="font-size:64px;filter:' + (P.torch ? 'none' : 'grayscale(1) opacity(.6)') + '">🔦</div><b>' + (P.torch ? 'Encendida' : 'Apagada') + '</b><span>Gasta batería rápido. Atrae a los infectados cercanos.</span><button class="btn pri" id="pht">' + (P.torch ? 'Apagar' : 'Encender') + '</button></div>'; $('pht').onclick = function () { setTorch(!P.torch); draw(); }; }
    draw();
  });

  // ---- Calculadora
  def('calc', 'Calculadora', '▦', 'linear-gradient(#6d7480,#3a3f47)', function (el) {
    var d = '0', acc = null, op = null, fresh = true;
    var K = [['C', 'fn'], ['±', 'fn'], ['%', 'fn'], ['÷', 'op'], ['7'], ['8'], ['9'], ['×', 'op'], ['4'], ['5'], ['6'], ['−', 'op'], ['1'], ['2'], ['3'], ['+', 'op'], ['0', 'z'], ['.'], ['=', 'op']];
    el.innerHTML = '<div class="cd" id="phcd">0</div><div class="calc">' + K.map(function (k) { return '<button class="' + (k[1] || '') + '" data-k="' + k[0] + '">' + k[0] + '</button>'; }).join('') + '</div>';
    function show() { var s = String(d); if (s.length > 12) s = (+d).toPrecision(9).replace(/\.?0+$/, ''); $('phcd').textContent = s; }
    function apply() { var a = acc, b = parseFloat(d), r = b; if (op === '+') r = a + b; else if (op === '−') r = a - b; else if (op === '×') r = a * b; else if (op === '÷') r = b === 0 ? NaN : a / b; return isFinite(r) ? +r.toFixed(10) : 'Error'; }
    function key(k) {
      if (d === 'Error' && k !== 'C') return;
      if (/^[0-9]$/.test(k)) { d = fresh || d === '0' ? k : d + k; fresh = false; }
      else if (k === '.') { if (fresh) { d = '0.'; fresh = false; } else if (d.indexOf('.') < 0) d += '.'; }
      else if (k === 'C') { d = '0'; acc = null; op = null; fresh = true; }
      else if (k === '±') { d = String(-parseFloat(d)); }
      else if (k === '%') { d = String(parseFloat(d) / 100); fresh = true; }
      else if (k === '=') { if (op !== null && acc !== null) { d = String(apply()); acc = null; op = null; fresh = true; } }
      else { if (op !== null && acc !== null && !fresh) { d = String(apply()); } acc = parseFloat(d); op = k; fresh = true; if (d === 'Error') { acc = null; op = null; } }
      show();
    }
    Array.prototype.forEach.call(el.querySelectorAll('.calc button'), function (b) { b.onclick = function () { key(b.getAttribute('data-k')); }; });
  });

  // ---- Música
  var AC = null, mus = { on: false, i: 0, timer: null, speaker: true };
  function ac() { if (!AC) { try { AC = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { AC = null; } } if (AC && AC.state === 'suspended') { try { AC.resume(); } catch (e) { /* nada */ } } return AC; }
  function tone(f, t0, d, type, g, lp) {
    var a = ac(); if (!a) return; var o = a.createOscillator(), v = a.createGain(), fl = a.createBiquadFilter(), vol = (G.S && G.S.vol != null ? G.S.vol : 0.8);
    o.type = type; o.frequency.value = f; fl.type = 'lowpass'; fl.frequency.value = lp || 1800;
    v.gain.setValueAtTime(0.0001, t0); v.gain.linearRampToValueAtTime(g * vol, t0 + 0.05); v.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
    o.connect(fl); fl.connect(v); v.connect(a.destination); o.start(t0); o.stop(t0 + d + 0.05);
  }
  function click() { var a = ac(); if (!a) return; tone(1800, a.currentTime, 0.04, 'square', 0.05, 3000); }
  var TRACKS = [
    { n: 'Silencio', len: 8, play: function (t) { tone(110, t, 7.5, 'sine', 0.16, 600); tone(164.8, t, 7.5, 'sine', 0.1, 600); tone(659, t + 2, 2.6, 'triangle', 0.05, 2200); tone(523, t + 4.6, 2.6, 'triangle', 0.045, 2200); } },
    { n: 'Pulso', len: 8, play: function (t) { for (var i = 0; i < 16; i++) { tone(i % 4 === 0 ? 62 : 55, t + i * 0.5, 0.3, 'sine', 0.3, 300); if (i % 4 === 2) tone(220, t + i * 0.5, 0.2, 'triangle', 0.06, 900); } } },
    { n: 'Radio vieja', len: 8, play: function (t) { var N = [[0, 220, 0.4], [0.5, 247, 0.4], [1, 262, 0.8], [2, 247, 0.4], [2.5, 220, 0.4], [3, 196, 1.2]]; for (var r = 0; r < 2; r++) N.forEach(function (n) { tone(n[1], t + r * 4 + n[0], n[2], 'sawtooth', 0.06, 900); }); } }
  ];
  function musPlay(i) { musStop(); var a = ac(); if (!a || P.bat <= 0) return; mus.on = true; mus.i = i; var tk = TRACKS[i]; (function bar() { if (!mus.on) return; tk.play(a.currentTime + 0.05); mus.timer = setTimeout(bar, tk.len * 1000 - 100); })(); }
  function musStop() { mus.on = false; if (mus.timer) { clearTimeout(mus.timer); mus.timer = null; } }
  def('musica', 'Música', '♪', 'linear-gradient(#2b84f2,#1740b8)', function (el) {
    function draw() {
      el.innerHTML = TRACKS.map(function (t, i) { return '<div class="li" data-i="' + i + '"><div class="av">' + (mus.on && mus.i === i ? '⏸' : '▶') + '</div><div><b>' + t.n + '</b><small>' + (mus.on && mus.i === i ? 'Sonando' : 'Guardada en el celular') + '</small></div></div>'; }).join('') +
        '<div class="row"><span>' + (mus.speaker ? '🔊 Altavoz' : '🎧 Auriculares') + '<br><small style="color:#98a3b0">' + (mus.speaker ? 'Hace ruido: atrae infectados' : 'Silencioso para el exterior') + '</small></span><button class="btn" id="phsp">Cambiar</button></div>';
      Array.prototype.forEach.call(el.querySelectorAll('.li'), function (b) { b.onclick = function () { var i = +b.getAttribute('data-i'); if (mus.on && mus.i === i) musStop(); else musPlay(i); draw(); }; });
      $('phsp').onclick = function () { mus.speaker = !mus.speaker; draw(); };
    }
    draw();
  });

  // ======================================================================== teclas
  document.addEventListener('keydown', function (e) {
    if (e.repeat) return; var tg = e.target; if (tg && (tg.tagName === 'TEXTAREA' || tg.tagName === 'INPUT') && e.code !== 'Escape') return;
    if (G.state !== 'play') return;
    if (e.code === 'KeyP') { if (isOpen) closePhone(); else openPhone(); e.preventDefault(); }
    else if (e.code === 'KeyM') { if (isOpen && app && app.id === 'mapa') closePhone(); else if (isOpen) { if (P.bat > 0) run('mapa'); } else openPhone('mapa'); e.preventDefault(); }
    else if (e.code === 'Escape' && isOpen) { if (camMode) exitCam(true); else closePhone(); e.preventDefault(); }
    else if (e.code === 'Enter' && isOpen) { if (camMode) takeShot(); else if (root && root.querySelector('#phlk')) { P.unlockedUntil = performance.now() + 30000; goHome(); } e.preventDefault(); }
  }, true);

  // ======================================================================== guardado
  function serialize() { return { bat: +P.bat.toFixed(2), saver: P.saver, mini: P.mini, note: P.note, torch: false }; }
  if (G.SaveSys) {
    var os = G.SaveSys.save, ol = G.SaveSys.load;
    G.SaveSys.save = function (d) { try { if (started && d && typeof d === 'object') d.ph = serialize(); } catch (e) { /* nada */ } return os.call(this, d); };
    G.SaveSys.load = function () { var r = ol.call(this); pending = r && r.ok && r.data && r.data.ph ? r.data.ph : null; return r; };
  }

  // ======================================================================== bucle
  function reset() { P.bat = STORY ? 100 : 30; P.torch = false; P.saver = false; P.note = ''; P.photos = []; P.unlockedUntil = 0; w15 = w5 = false; setTorch(false); musStop(); }
  function loop(now) {
    requestAnimationFrame(loop);
    var dt = Math.min((now - last) / 1000, 0.1); last = now;
    try {
      var st = G.state;
      if (!started && st === 'play') {
        started = true; build(); reset();
        if (G.loaded && pending) { P.bat = clamp(+pending.bat || 0, 0, 100); P.saver = !!pending.saver; P.mini = pending.mini !== false; P.note = String(pending.note || ''); }
        pending = null;
      } else if (started && st === 'menu') { started = false; closePhone(true); reset(); if (btn) btn.classList.add('hide'); }
      if (!started) { if (mini) mini.classList.add('hide'); return; }
      if (shot) grabShot();
      if (st !== 'play') { if (isOpen) closePhone(true); if (btn) btn.classList.add('hide'); if (mini) mini.classList.add('hide'); if (st === 'dead' && P.torch) setTorch(false); return; }
      // batería
      var rate = 0.012 + (isOpen && !camMode ? 0.05 : 0) + (camMode ? 0.04 : 0) + (P.torch ? 0.08 : 0) + (mus.on ? 0.02 : 0); if (P.saver) rate *= 0.5;
      P.bat -= rate * dt;
      if (P.bat <= 15 && !w15) { w15 = true; toast('Batería del celular baja: 15 %', 'warn', 2500); }
      if (P.bat <= 5 && !w5) { w5 = true; toast('Batería del celular crítica: 5 %', 'warn', 2500); }
      if (P.bat <= 0) { P.bat = 0; if (P.torch) setTorch(false); if (mus.on) musStop(); if (isOpen) { if (camMode) { camMode = false; camEl.classList.remove('on'); root.classList.add('on'); if (!coarse) { try { G.input.unlock(); } catch (e) { /* nada */ } } } dead(); } if (!w5 || w15) { /* aviso único */ } if (P._offToast !== 1) { P._offToast = 1; toast('El celular se quedó sin batería', 'warn', 3000); } } else P._offToast = 0;
      // ruido que se oye de cerca
      noiseT -= dt;
      if (noiseT <= 0 && (P.torch || (mus.on && mus.speaker))) {
        noiseT = 3; var p = G.ctrl.pos; try { if (G.noise) G.noise(p.x, p.y, p.z, mus.on && mus.speaker ? 11 : 6, P.torch && !(mus.on && mus.speaker) ? 'linterna' : 'musica'); } catch (e) { /* nada */ }
      }
      // botón
      if (btn) { btn.classList.toggle('hide', camMode || !!G.cine); btn.classList.toggle('low', P.bat <= 15); btn.innerHTML = '📱<small>' + Math.round(P.bat) + '%</small>'; }
      if (isOpen) status();
      drawMini();
    } catch (err) { if (!warned) { warned = true; console.error('[celular]', err); } }
  }

  // linterna del celular: reutiliza el foco de la linterna del juego (Env.flash) sin añadir luces nuevas a la escena
  try {
    var env = G.env, envUpdate = env.update;
    env.update = function () { var r = envUpdate.apply(this, arguments); if (P.torch && !this.flashOn && this.flash) this.flash.intensity = 1.5; return r; };
  } catch (e) { /* sin linterna de celular */ }

  window.VERTICE_PHONE = { open: openPhone, close: closePhone, state: P, objective: objective };
  requestAnimationFrame(loop);
})();
