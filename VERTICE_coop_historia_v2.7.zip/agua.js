/*!
 * VÉRTICE · Agua (agua.js, v2.7)
 *
 * Todo lo nuevo de los ríos del modo libre (index.html):
 *  - NADO ANIMADO: crol (brazada alterna, patada de tijera, torso que rola y cabeza que gira a respirar) al avanzar en superficie,
 *    nado bajo el agua más lento y con el cuerpo tendido, y «patada de bicicleta» con brazos que reman cuando flotas quieto.
 *    En primera persona se ven tus brazos entrando al agua, la cámara rola con cada brazada y salen ondas en la superficie.
 *    También lo ven los demás jugadores en cooperativo (vertice-mp.js llama a VERT_AGUA.remote).
 *  - PECES: bancos de peces plateados, naranjas, azules y verdes (y unos pocos bagres grandes) que recorren los ríos; huyen si te acercas y a veces saltan.
 *  - AHOGADOS: zombis acuáticos, los ÚNICOS que nadan. Esperan de pie en el fondo (a veces vigilando un cofre), te sienten al nadar
 *    desde lejos, suben hacia ti y te muerden; no pueden salir del agua. Nadando solo se pelea con machete, bate o hacha.
 *  - COFRES: LEVEL.riverChests (se generan en index.html, buildWild) brillan débilmente en el lecho; burbujas los delatan.
 *  - Cada jugador simula sus propios peces y ahogados (como los animales de animales.js: no se sincronizan en cooperativo).
 */
(function () {
  'use strict';
  var G = window.VERTICE, THREE = window.THREE;
  if (!G || !THREE || !G.Enemy || !G.TERRAIN || !G.ctrl || !G.scene || !G.Chars) return;
  var TER = G.TERRAIN, WL = TER.WL, hyp = Math.hypot, PI = Math.PI, T2 = PI * 2, rnd = Math.random;
  var clamp = function (v, a, b) { return Math.max(a, Math.min(b, v)); };
  var lerp = function (a, b, t) { return a + (b - a) * t; };
  var smooth = function (a, b, x) { var t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
  var wrapPi = function (a) { return a - T2 * Math.round(a / T2); };
  var turn = function (a, b, k) { return a + wrapPi(b - a) * k; };
  var warned = {};
  var warn = function (tag, e) { if (!warned[tag]) { warned[tag] = 1; try { console.error('[agua] ' + tag, e); } catch (x) { /* nada */ } } };
  var toast = function (m, k, ms) { try { G.ui.toast(m, k || '', ms || 3500); } catch (e) { /* sin interfaz */ } };
  var inWater = function (x, z, d) { return TER.active(x, z) && TER.depth(x, z) > (d == null ? 0.35 : d); };
  var isSwimAt = function (x, y, z) { return TER.active(x, z) && TER.depth(x, z) > 1.0 && y < WL + 0.2; };

  // ======================================================================== ondas en la superficie
  var ripples = [], ripGeo = new THREE.RingGeometry(0.42, 0.5, 28).rotateX(-PI / 2);
  function ripple(x, z, big) {
    var r = null, i;
    for (i = 0; i < ripples.length; i++) if (!ripples[i].on) { r = ripples[i]; break; }
    if (!r) {
      if (ripples.length >= 14) return;
      var m = new THREE.Mesh(ripGeo, new THREE.MeshBasicMaterial({ color: 0xd8f2f4, transparent: true, opacity: 0.5, depthWrite: false }));
      m.renderOrder = 2; m.frustumCulled = false; G.scene.add(m); r = { m: m, on: false, t: 0, big: 1 }; ripples.push(r);
    }
    r.on = true; r.t = 0; r.big = big ? 1.7 : 1; r.m.visible = true; r.m.position.set(x, WL + 0.03, z); r.m.scale.setScalar(0.3);
  }
  function tickRipples(dt) {
    for (var i = 0; i < ripples.length; i++) {
      var r = ripples[i]; if (!r.on) continue;
      r.t += dt; var u = r.t / 1.1;
      if (u >= 1) { r.on = false; r.m.visible = false; continue; }
      r.m.scale.setScalar((0.3 + u * 1.9) * r.big); r.m.material.opacity = 0.5 * (1 - u) * (1 - u);
    }
  }

  // ======================================================================== pose de nado (la comparten tu personaje y los remotos)
  // m = personaje de buildChar. o = { swim, speed, under, pit, atk }. Si no nadas solo se retira el balanceo del torso.
  function swimPose(m, o, dt) {
    var sw = m._sw || (m._sw = { h: 0, ph: 0, stroke: 0, lastArm: 0 });
    sw.stroke = 0;
    if (!o.swim) { if (Math.abs(m.tor.rotation.z) > 0.002) m.tor.rotation.z *= Math.exp(-10 * dt); sw.h *= Math.exp(-6 * dt); return false; }
    var ex = function (t) { return 1 - Math.exp(-t * dt); }, moving = o.speed > 0.4, under = o.under ? 1 : 0;
    sw.h += ((moving ? 1 : 0) - sw.h) * ex(moving ? 6 : 3.5);
    var h = sw.h;
    sw.ph += dt * (moving ? (under ? 5.0 : 6.6) : 4.0);
    var ph = sw.ph, cr = ph * 0.5, half = Math.floor(cr / PI);
    if (moving && half !== sw.lastArm) { sw.stroke = (half & 1) + 1; }
    sw.lastArm = half;
    // cuerpo: tendido al avanzar (cabeza al frente), derecho al flotar. La pelvis se recoloca para que el centro quede en la superficie (o cerca del fondo si buceas).
    var txF = -(1.28 + 0.17 * under), tyF = (under ? 0.5 : 0.95) - 0.9 * Math.cos(txF), tzF = -0.9 * Math.sin(txF);
    m.rig.rotation.x = txF * h; m.rig.position.y = tyF * h; m.rig.position.z = tzF * h; m.rig.rotation.z = 0;
    // piernas: tijera al avanzar, bicicleta al flotar
    var hipY = 0;
    for (var i = 0; i < m.legs.length; i++) {
      var L = m.legs[i], off = i ? PI : 0, k = Math.sin(ph + off);
      var hipC = k * 0.42, knC = -(0.2 + 0.3 * Math.max(0, Math.sin(ph + off + 1.1)));
      var hipT = 0.55 + 0.35 * Math.sin(ph * 0.9 + off), knT = -(0.9 + 0.4 * Math.sin(ph * 0.9 + off + 1.2));
      L.hip.rotation.x = lerp(hipT, hipC, h); L.kn.rotation.x = lerp(knT, knC, h);
      hipY = Math.max(hipY, 0.45 * Math.cos(L.hip.rotation.x) + 0.45 * Math.cos(L.hip.rotation.x + L.kn.rotation.x));
    }
    m.pel.position.y = hipY; m.pel.rotation.x = -0.05;
    // brazos: crol (molinillo: se estiran al frente, tiran bajo el cuerpo y recuperan por encima) o remada corta al flotar
    if (!o.atk) {
      for (i = 0; i < m.arms.length; i++) {
        var A = m.arms[i], side = i ? -1 : 1, phi = cr + (i ? PI : 0);
        if (h > 0.5) { A.sh.rotation.set(PI - phi, 0, side * 0.12); var s = Math.sin(phi); A.el.rotation.x = 0.25 + (s < 0 ? -s * 0.95 : 0.12 * s); }
        else { A.sh.rotation.set(0.75 + 0.35 * Math.sin(ph * 1.3 + (i ? PI : 0)), 0, side * (0.85 + 0.2 * Math.cos(ph * 1.3))); A.el.rotation.x = 0.5 + 0.25 * Math.sin(ph * 1.3 + 1); }
      }
    }
    // torso que rola con cada brazada y cabeza que mira al frente (y gira a respirar en superficie)
    m.tor.rotation.z = Math.sin(cr) * 0.28 * h;
    m.hd.rotation.x = (under ? 0.35 : 1.0) * h + clamp((o.pit || 0) * 0.5, -0.5, 0.5);
    m.hd.rotation.y += (under ? 0 : Math.sin(cr + 0.4) * 0.4 * h - m.hd.rotation.y) * 0.5;
    if (!o.atk) for (var n in m.pv) m.pv[n].visible = false;
    return true;
  }

  // ---- tu personaje: tercera persona (cuerpo) y primera persona (brazos, balanceo de cámara, ondas)
  var Chars = G.Chars, _cu = Chars.update, fpArms = null, fpId = null, fpPh = 0, rippleT = 0, firstSwim = true;
  function buildFPArms(id) {
    if (fpArms) { G.camera.remove(fpArms.g); }
    var ch = (G.CH && G.CH[id]) || {}, jk = new THREE.MeshStandardMaterial({ color: ch.jacket != null ? ch.jacket : 0x3b3a33, roughness: 0.9 }),
      sk = new THREE.MeshStandardMaterial({ color: ch.skin || '#c29578', roughness: 0.8 }), g = new THREE.Group(), arms = [];
    g.name = 'brazos_nado';
    for (var i = 0; i < 2; i++) {
      var piv = new THREE.Group(), box = function (w, h, d, z, mat) { var b = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat); b.position.z = z; piv.add(b); return b; };
      box(0.105, 0.105, 0.34, -0.17, jk); box(0.085, 0.085, 0.3, -0.49, sk); box(0.1, 0.045, 0.13, -0.69, sk); box(0.03, 0.03, 0.08, -0.77, sk).position.x = -0.03;
      piv.visible = false; g.add(piv); arms.push(piv);
    }
    g.visible = false; G.camera.add(g); fpArms = { g: g, arms: arms }; fpId = id;
  }
  function fpSwim(m, sw, swim, dt) {
    var tp = !!G.S.tp, show = swim && !tp && !G.atk && sw.h > 0.3;
    if (swim && !tp) { try { G.weapon.visible = !!G.atk; } catch (e) { /* sin arma */ } }
    if (!fpArms || fpId !== Chars.id) { if (!swim) return; buildFPArms(Chars.id); }
    fpArms.g.visible = show;
    if (!show) return;
    var cr = sw.ph * 0.5, i, e = function (t) { return t * t * (3 - 2 * t); };
    for (i = 0; i < 2; i++) {
      var A = fpArms.arms[i], side = i ? 1 : -1, u = (((cr + (i ? PI : 0)) % T2) + T2) % T2 / T2;
      if (u < 0.6) {
        var t = u / 0.6, k = e(t);
        A.visible = true; A.position.set(side * (0.27 + 0.07 * Math.sin(t * PI)), -0.3 - 0.12 * k, -0.15 + 0.4 * k); A.rotation.set(lerp(0.2, -1.8, k), -side * 0.12, -side * (0.1 + 0.18 * Math.sin(t * PI)));
      } else if (u > 0.94) { A.visible = true; A.position.set(side * 0.27, -0.3, -0.15); A.rotation.set(0.2 + (u - 0.94) * 4, 0, 0); }
      else A.visible = false;
    }
    // la cámara rola un poco con cada brazada (sin tocar la altura: así no parpadea la línea del agua)
    G.camera.rotation.z += Math.sin(cr) * 0.032 * sw.h; G.camera.rotation.x += Math.cos(cr * 2) * 0.008 * sw.h;
  }
  Chars.update = function (dt, x, y, z) {
    _cu.call(this, dt, x, y, z);
    try {
      var c = G.ctrl, m = Chars.cur; if (!m) return;
      var swim = !!c.swimming && G.ps.alive && !G.veh, under = !!G.player.under, sp = hyp(c.vel.x, c.vel.z);
      var on = swimPose(m, { swim: swim, speed: sp, under: under, pit: G.look.pitch, atk: !!G.atk }, dt);
      if (swim && firstSwim && G.state === 'play') { firstSwim = false; toast('Agáchate (C) para bucear · salta para subir · en el fondo hay cofres… y ahogados', 'ok', 5200); }
      fpSwim(m, m._sw, on, dt);
      if (on && m._sw.stroke && !under) ripple(c.pos.x - Math.sin(m.yaw || 0) * 0.3, c.pos.z - Math.cos(m.yaw || 0) * 0.3, false);
      if (on && !under && sp > 0.4) { rippleT -= dt; if (rippleT <= 0) { rippleT = 0.55; ripple(c.pos.x, c.pos.z, false); } }
    } catch (err) { warn('nado', err); }
  };
  // ---- jugadores remotos (cooperativo)
  function remote(av, r, st, dt) {
    if (!av.real || st.c) return;
    var p = r.pos, swim = isSwimAt(p.x, p.y, p.z), under = p.y < WL - 1.6;
    var on = swimPose(av.m, { swim: swim, speed: r.speed, under: under, pit: r.pitch, atk: !!st.t }, dt);
    if (on && av.m._sw.stroke && !under) ripple(p.x, p.z, false);
  }

  // ======================================================================== peces
  var fish = [], schools = [], fishMesh = null, tailMesh = null, tmpM = new THREE.Matrix4(), tmpT = new THREE.Matrix4(), tmpQ = new THREE.Quaternion(), tmpE = new THREE.Euler(0, 0, 0, 'YXZ'),
    tmpP = new THREE.Vector3(), tmpS = new THREE.Vector3(), ZERO = new THREE.Matrix4().makeScale(0, 0, 0), tmpC = new THREE.Color();
  function fishGeos() {
    var b = new THREE.SphereGeometry(1, 10, 7); b.scale(0.11, 0.2, 0.42); b.translate(0, 0, 0.04);
    var bp = b.toNonIndexed(), P = Array.prototype.slice.call(bp.attributes.position.array), N = Array.prototype.slice.call(bp.attributes.normal.array);
    var tri = function (a, bb, c, nx, ny, nz) { P.push(a[0], a[1], a[2], bb[0], bb[1], bb[2], c[0], c[1], c[2]); for (var i = 0; i < 3; i++) N.push(nx, ny, nz); };
    tri([0, 0.16, 0.2], [0, 0.34, -0.08], [0, 0.16, -0.16], 1, 0, 0); tri([0, 0.16, 0.2], [0, 0.16, -0.16], [0, 0.34, -0.08], -1, 0, 0);   // aleta dorsal
    tri([0.07, -0.05, 0.12], [0.2, -0.14, -0.02], [0.07, -0.08, -0.03], 0, 1, 0); tri([-0.07, -0.05, 0.12], [-0.07, -0.08, -0.03], [-0.2, -0.14, -0.02], 0, 1, 0);   // aletas pectorales
    var body = new THREE.BufferGeometry(); body.setAttribute('position', new THREE.Float32BufferAttribute(P, 3)); body.setAttribute('normal', new THREE.Float32BufferAttribute(N, 3));
    var tail = new THREE.BufferGeometry(); tail.setAttribute('position', new THREE.Float32BufferAttribute([0, 0, 0, 0, 0.2, -0.3, 0, -0.2, -0.3, 0, 0, 0, 0, -0.2, -0.3, 0, 0.2, -0.3], 3));
    tail.setAttribute('normal', new THREE.Float32BufferAttribute([1, 0, 0, 1, 0, 0, 1, 0, 0, -1, 0, 0, -1, 0, 0, -1, 0, 0], 3));
    return { body: body, tail: tail };
  }
  var PAL = [0xc4d2d8, 0xd0dadc, 0xe08a3a, 0x6f95b8, 0x8f9e55, 0xd8c070, 0x9aa8b0];
  function buildFish() {
    var rr = (typeof mulberry === 'function' ? mulberry(20261103) : Math.random), rivers = TER.rivers, CAP = 230;
    var geos = fishGeos(), mat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.4, metalness: 0.35, side: THREE.DoubleSide });
    fishMesh = new THREE.InstancedMesh(geos.body, mat, CAP); tailMesh = new THREE.InstancedMesh(geos.tail, mat, CAP);
    fishMesh.frustumCulled = tailMesh.frustumCulled = false; fishMesh.name = tailMesh.name = 'peces';
    var want = 26, tries = 0;
    while (schools.length < want && tries++ < 400) {
      var r = rivers[Math.floor(rr() * rivers.length)], n = r.dense.length, s = 3 + rr() * (n - 7), i = Math.floor(s), a = r.dense[i], lat = (rr() - 0.5) * 1.1;
      var b = r.dense[i + 1], vx = b[0] - a[0], vz = b[1] - a[1], ln = hyp(vx, vz) || 1, cx = a[0] - vz / ln * lat * a[2] * 0.8, cz = a[1] + vx / ln * lat * a[2] * 0.8;
      if (TER.depth(cx, cz) < 1.4) continue;
      var big = schools.length % 7 === 6, count = big ? 1 : 5 + Math.floor(rr() * 5), pal = PAL[Math.floor(rr() * PAL.length)];
      if (fish.length + count > CAP) break;
      var sc = { r: r, s: s, dir: rr() < 0.5 ? -1 : 1, v: 0.9 + rr() * 1.1, lat: lat, dfrac: rr() * 0.85, fear: 0, cx: cx, cz: cz, hd: 0, near: false, leapCd: 10 + rr() * 40, members: [], seg: 5 };
      for (var q = 0; q < count; q++) {
        var f = { sc: sc, ox: (rr() - 0.5) * 1.8, oz: (rr() - 0.5) * 2.2, oy: (rr() - 0.5) * 0.7, ph: rr() * 6.28, size: big ? 0.95 + rr() * 0.3 : 0.28 + rr() * 0.3, col: pal, leap: null, idx: fish.length };
        sc.members.push(f); fish.push(f);
        tmpC.setHex(f.col); tmpC.offsetHSL(0, (rr() - 0.5) * 0.08, (rr() - 0.5) * 0.12); fishMesh.setColorAt(f.idx, tmpC); tailMesh.setColorAt(f.idx, tmpC);
        fishMesh.setMatrixAt(f.idx, ZERO); tailMesh.setMatrixAt(f.idx, ZERO);
      }
      schools.push(sc);
    }
    fishMesh.count = tailMesh.count = fish.length;
    fishMesh.instanceMatrix.needsUpdate = tailMesh.instanceMatrix.needsUpdate = true; if (fishMesh.instanceColor) fishMesh.instanceColor.needsUpdate = tailMesh.instanceColor.needsUpdate = true;
    G.scene.add(fishMesh, tailMesh);
  }
  function placeFish(f, x, y, z, yaw, pitch, wag, size) {
    tmpE.set(pitch, yaw, 0, 'YXZ'); tmpQ.setFromEuler(tmpE); tmpP.set(x, y, z); tmpS.set(size, size, size);
    tmpM.compose(tmpP, tmpQ, tmpS); fishMesh.setMatrixAt(f.idx, tmpM);
    tmpT.makeRotationY(wag); tmpT.setPosition(0, 0, -0.4); tmpM.multiply(tmpT); tailMesh.setMatrixAt(f.idx, tmpM);
  }
  function hideFish(f) { fishMesh.setMatrixAt(f.idx, ZERO); tailMesh.setMatrixAt(f.idx, ZERO); }
  var fishT = 0, rest = 0;
  function tickFish(dt) {
    if (!fishMesh) return;
    fishT += dt; var cam = G.camera.position, pl = G.ctrl.pos, plWet = G.ctrl.swimming || TER.depth(pl.x, pl.z) > 0.3, dirty = false;
    for (var si = 0; si < schools.length; si++) {
      var sc = schools[si], dd = hyp(sc.cx - cam.x, sc.cz - cam.z), act = dd < 85;
      if (!act) { if (sc.near) { sc.near = false; for (var h = 0; h < sc.members.length; h++) hideFish(sc.members[h]); dirty = true; } continue; }
      sc.near = true; dirty = true;
      // el banco avanza por el río; si te acercas huye río arriba o abajo, alejándose de ti
      var dpl = hyp(sc.cx - pl.x, sc.cz - pl.z);
      if (plWet && dpl < 8 && sc.fear <= 0) {
        sc.fear = 2.6;
        var dense = sc.r.dense, i0 = clamp(Math.floor(sc.s), 1, dense.length - 3), tx = (dense[i0 + 1][0] - dense[i0][0]) * sc.dir, tz = (dense[i0 + 1][1] - dense[i0][1]) * sc.dir;
        if (tx * (sc.cx - pl.x) + tz * (sc.cz - pl.z) < 0) sc.dir = -sc.dir;
      }
      sc.fear = Math.max(0, sc.fear - dt);
      var v = sc.v * (sc.fear > 0 ? 3.4 : 1), dense2 = sc.r.dense, nD = dense2.length;
      sc.s += sc.dir * v * dt / sc.seg;
      if (sc.s < 2.2) { sc.s = 2.2; sc.dir = 1; } else if (sc.s > nD - 3.2) { sc.s = nD - 3.2; sc.dir = -1; }
      var i = Math.floor(sc.s), f = sc.s - i, A = dense2[i], B = dense2[i + 1], vx = B[0] - A[0], vz = B[1] - A[1], ln = hyp(vx, vz) || 1, w = lerp(A[2], B[2], f);
      var px = lerp(A[0], B[0], f), pz = lerp(A[1], B[1], f), nx = -vz / ln, nz = vx / ln, lat = sc.lat + Math.sin(fishT * 0.15 + si) * 0.15;
      var cx = px + nx * lat * w * 0.8, cz = pz + nz * lat * w * 0.8;
      if (TER.depth(cx, cz) < 1.1) { sc.lat *= 0.9; cx = px; cz = pz; }
      sc.cx = cx; sc.cz = cz; var hd = Math.atan2(vx * sc.dir, vz * sc.dir); sc.hd = sc.near ? turn(sc.hd, hd, 0.2) : hd;
      var sH = Math.sin(sc.hd), cH = Math.cos(sc.hd);
      // salto ocasional: solo si estás cerca para verlo
      sc.leapCd -= dt;
      if (sc.leapCd <= 0) { sc.leapCd = 25 + rnd() * 45; if (dd < 45 && TER.depth(cx, cz) > 1.6) { var lf = sc.members[Math.floor(rnd() * sc.members.length)]; if (!lf.leap) lf.leap = { t: 0 }; } }
      for (var q = 0; q < sc.members.length; q++) {
        var m = sc.members[q], spread = sc.fear > 0 ? 1.8 : 1, wob = Math.sin(fishT * 0.8 + m.ph) * 0.35, ox = (m.ox * spread + wob), oz = m.oz * spread + Math.cos(fishT * 0.6 + m.ph) * 0.4;
        var fx = cx + cH * ox + sH * oz, fz = cz - sH * ox + cH * oz, depth = TER.depth(fx, fz);
        if (depth < 0.7) { fx = cx; fz = cz; depth = TER.depth(fx, fz); if (depth < 0.7) { hideFish(m); continue; } }
        var bed = WL - depth, y = clamp(WL - 0.55 - sc.dfrac * (depth - 1.0) + m.oy + Math.sin(fishT * 0.9 + m.ph) * 0.1, bed + 0.18, WL - 0.28), yaw = sc.hd + Math.sin(fishT * 0.7 + m.ph) * 0.3, pitch = 0;
        var wag = Math.sin(fishT * (7 + v * 2.2) + m.ph) * 0.55, size = m.size;
        if (m.leap) {   // arco fuera del agua
          var L = m.leap; L.t += dt; var u = L.t / 0.95;
          if (L.t - dt <= 0) { ripple(fx, fz, true); try { if (dd < 30 && G.audio.splash) G.audio.splash(0.18); } catch (e) { /* sin audio */ } }
          if (u >= 1) { m.leap = null; ripple(fx, fz, true); } else { y = WL - 0.3 + 1.0 * Math.sin(u * PI); pitch = lerp(-0.9, 0.9, u); wag = Math.sin(fishT * 30) * 0.7; }
        }
        placeFish(m, fx, y, fz, yaw, pitch, wag, size);
      }
    }
    if (dirty) { fishMesh.instanceMatrix.needsUpdate = tailMesh.instanceMatrix.needsUpdate = true; }
  }

  // ======================================================================== burbujas y destellos de cofres
  var bub = null, bubN = 90, bubA = [], chestFx = [], glowTex = null;
  function mkTex(f) { var c = document.createElement('canvas'); c.width = c.height = 32; f(c.getContext('2d')); return new THREE.CanvasTexture(c); }
  function buildFx() {
    glowTex = mkTex(function (g) { var r = g.createRadialGradient(16, 16, 0, 16, 16, 16); r.addColorStop(0, 'rgba(255,236,160,1)'); r.addColorStop(0.35, 'rgba(255,200,90,0.5)'); r.addColorStop(1, 'rgba(255,190,60,0)'); g.fillStyle = r; g.fillRect(0, 0, 32, 32); });
    var bt = mkTex(function (g) { g.strokeStyle = 'rgba(235,250,255,0.95)'; g.lineWidth = 3; g.beginPath(); g.arc(16, 16, 11, 0, T2); g.stroke(); g.fillStyle = 'rgba(255,255,255,0.35)'; g.beginPath(); g.arc(12, 12, 3, 0, T2); g.fill(); });
    var geo = new THREE.BufferGeometry(), pos = new Float32Array(bubN * 3); for (var i = 0; i < bubN; i++) { pos[i * 3 + 1] = -999; bubA.push({ on: false, x: 0, y: 0, z: 0, vy: 0, sw: 0 }); }
    geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
    bub = new THREE.Points(geo, new THREE.PointsMaterial({ map: bt, size: 0.16, sizeAttenuation: true, transparent: true, depthWrite: false, opacity: 0.85 })); bub.frustumCulled = false; bub.name = 'burbujas'; G.scene.add(bub);
    var cs = (G.LEVEL && G.LEVEL.riverChests) || [];
    for (var k = 0; k < cs.length; k++) {
      var sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTex, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, opacity: 0.4, fog: true }));
      sp.scale.set(1.5, 1.5, 1); sp.position.set(cs[k].x, cs[k].y + 0.75, cs[k].z); sp.renderOrder = 3; G.scene.add(sp);
      chestFx.push({ c: cs[k], sp: sp, t: rnd() * 6, em: rnd() });
    }
  }
  function emitBubble(x, y, z) {
    for (var i = 0; i < bubN; i++) if (!bubA[i].on) { var b = bubA[i]; b.on = true; b.x = x; b.y = y; b.z = z; b.vy = 0.55 + rnd() * 0.4; b.sw = rnd() * 6; return; }
  }
  var emitT = 0;
  function tickFx(dt) {
    if (!bub) return;
    var cam = G.camera.position, pa = bub.geometry.attributes.position.array, i, b;
    for (i = 0; i < chestFx.length; i++) {
      var f = chestFx[i], d = hyp(f.c.x - cam.x, f.c.z - cam.z), c = G.containerById ? G.containerById(f.c.id) : null, opened = !!(c && c.opened);
      f.sp.visible = !opened && d < 70; f.t += dt;
      if (f.sp.visible) f.sp.material.opacity = 0.28 + 0.2 * Math.sin(f.t * 2.2);
      if (d < 38 && (!opened || f.em < 0.5)) { f.em -= dt; if (f.em <= 0) { f.em = 0.9 + rnd() * 1.4; emitBubble(f.c.x + (rnd() - 0.5) * 0.5, f.c.y + 0.6, f.c.z + (rnd() - 0.5) * 0.5); } }
    }
    // tus burbujas: sueltas al bucear (más cuando te falta el aire)
    emitT -= dt;
    if (G.player.under && G.ctrl.swimming && emitT <= 0) { var low = G.Swim ? 0 : 0; emitT = 0.7 + rnd() * 0.8; emitBubble(cam.x + (rnd() - 0.5) * 0.2, cam.y - 0.1, cam.z + (rnd() - 0.5) * 0.2); }
    for (i = 0; i < bubN; i++) {
      b = bubA[i];
      if (!b.on) { pa[i * 3 + 1] = -999; continue; }
      b.y += b.vy * dt; b.sw += dt * 2; b.x += Math.sin(b.sw) * 0.08 * dt; b.z += Math.cos(b.sw * 0.8) * 0.08 * dt;
      if (b.y > WL - 0.02) { b.on = false; pa[i * 3 + 1] = -999; continue; }
      pa[i * 3] = b.x; pa[i * 3 + 1] = b.y; pa[i * 3 + 2] = b.z;
    }
    bub.geometry.attributes.position.needsUpdate = true;
  }

  // ======================================================================== ahogados
  var Enemy = G.Enemy, AE = window.AudioEngine || null, drowned = [], foes = [], lairs = [];
  // sus voces usan las del gordo (gorgoteo grave y húmedo)
  (function () {
    var P = (G.audio && Object.getPrototypeOf(G.audio)) || (AE && AE.prototype); if (!P) return;
    ['moan', 'snarl', 'zpain', 'zdie'].forEach(function (k) { var o = P[k]; if (typeof o !== 'function') return; P[k] = function (pos, type, a) { return o.call(this, pos, type === 'drowned' ? 'bloater' : type, a); }; });
  })();

  class Drowned extends Enemy {
    constructor(lair) {
      super('drowned', lair.x, lair.z, null);
      var bed = TER.h(lair.x, lair.z); this.lair = lair; this.bed = bed; this.cy = bed + 0.88; this.pos.y = this.cy - 0.88;
      this.resident = true; this.state = 'lurk'; this.pitchK = 0.1; this.lurkT = 1 + rnd() * 3; this.goal = null; this.lostT = 0; this.cool = 0; this.windT = 0; this.last = null;
      this.yaw = rnd() * T2; this.sway = rnd() * 6;
    }
  }
  var D = Drowned.prototype;
  D.canGo = function (x, z) { return TER.active(x, z) && TER.depth(x, z) >= 0.9; };
  D.step = function (dx, dz, sp, dt) {   // se mueve solo por agua (≥ 0,9 m): al llegar a la orilla se desliza o se detiene
    var nx = this.pos.x + dx * sp * dt, nz = this.pos.z + dz * sp * dt;
    if (this.canGo(nx, nz)) { this.pos.x = nx; this.pos.z = nz; }
    else if (this.canGo(nx, this.pos.z)) this.pos.x = nx; else if (this.canGo(this.pos.x, nz)) this.pos.z = nz;
    for (var i = 0; i < drowned.length; i++) {   // no se amontonan
      var o = drowned[i]; if (o === this || !o.alive) continue;
      var ex = this.pos.x - o.pos.x, ez = this.pos.z - o.pos.z, dd = ex * ex + ez * ez;
      if (dd < 0.9 && dd > 1e-6) { var d = Math.sqrt(dd), k = (0.95 - d) * 0.5; if (this.canGo(this.pos.x + ex / d * k, this.pos.z + ez / d * k)) { this.pos.x += ex / d * k; this.pos.z += ez / d * k; } }
    }
  };
  D.aggro = function (x, z) {
    if (this.state !== 'chase') { this.state = 'chase'; this.stateT = 0; try { G.audio.moan(this.pos, this.type, 1.2); if (G.onSpotted) G.onSpotted(this); } catch (e) { /* sin audio */ } }
    this.last = { x: x, z: z }; this.lostT = 0;
  };
  D.hear = function (n) {
    if (!this.alive || n.src !== 'player') return;
    var d = hyp(n.x - this.pos.x, n.z - this.pos.z), r = n.radius * (this.T.hear || 1) * ((G.diff && G.diff.hear) || 1) * 0.7;
    if (d < r && (inWater(n.x, n.z, 0.3) || d < 6)) { if (this.state === 'chase') { this.last = { x: n.x, z: n.z }; this.lostT = 0; } else this.aggro(n.x, n.z); }
  };
  D.update = function (dt) {
    var pl = G.ctrl.pos, dx = pl.x - this.pos.x, dz = pl.z - this.pos.z, dist = hyp(dx, dz), Dm = G.diff || { sight: 1, speed: 1, cool: 1 };
    if (!this.alive) { this.deadT += dt; this.cy = Math.min(WL - 0.45, this.cy + 0.3 * dt) + Math.sin(this.deadT * 1.3) * 0.0015; this.pos.y = this.cy - 0.88; this.speedNow = 0; if (dist < 140) this.animate(dt); return; }
    if (dist > 130) { this.speedNow = 0; this.ph2 = (this.ph2 || 0) + dt; if (this.ph2 > 1) { this.ph2 = 0; this.animate(0.016); } return; }
    this.stateT = (this.stateT || 0) + dt; this.cool = Math.max(0, this.cool - dt);
    if (this.stun > 0) { this.stun -= dt; this.speedNow = 0; this.animate(dt); return; }
    var swimmer = G.ctrl.swimming, moving = G.ctrl.moving || hyp(G.ctrl.vel.x, G.ctrl.vel.z) > 0.8;
    // sentidos: nadar los delata desde lejos (el agua transmite); de pie en la orilla solo si estás muy cerca
    var R = (swimmer ? (moving ? 24 : 14) : inWater(pl.x, pl.z, 0.15) ? 9 : (moving ? 7 : 4)) * (Dm.sight || 1);
    if (dist < R && G.ps.alive && Math.abs((pl.y + 0.9) - this.cy) < 8) this.aggro(pl.x, pl.z);
    var sp = 0;
    if (this.state === 'chase') {
      var tgt = this.last || pl, tdx = tgt.x - this.pos.x, tdz = tgt.z - this.pos.z, td = hyp(tdx, tdz) || 1, T = this.T, plWet = swimmer || inWater(pl.x, pl.z, 0.15);
      if (dist < R * 1.15 && G.ps.alive) { this.last = { x: pl.x, z: pl.z }; this.lostT = 0; } else this.lostT += dt;
      // profundidad: se pone a tu altura (en superficie si estás en la orilla)
      var ty = plWet ? clamp(pl.y + 0.9, this.bed + 0.55, WL - 0.5) : WL - 0.6;
      this.cy += clamp(ty - this.cy, -2.0 * dt, 2.0 * dt);
      if (this.windT > 0) { this.windT -= dt; this.yaw = turn(this.yaw, Math.atan2(dx, dz), 1 - Math.exp(-10 * dt)); if (this.windT <= 0) { if (dist < T.reach + 0.6 && Math.abs((pl.y + 0.9) - this.cy) < 1.7 && G.ps.alive) G.hurtPlayer(T.dmg, this); this.cool = T.cooldown * (Dm.cool || 1); } }
      else {
        if (td > 1.1) { var spd = T.sp.chase * (Dm.speed || 1) * (this.cy > WL - 1.0 ? 1 : 0.9); this.yaw = turn(this.yaw, Math.atan2(tdx, tdz), 1 - Math.exp(-8 * dt)); this.step(tdx / td, tdz / td, spd, dt); sp = spd; }
        if (dist < T.reach && Math.abs((pl.y + 0.9) - this.cy) < 1.7 && this.cool <= 0 && G.ps.alive) { this.windT = T.windup; try { G.audio.snarl(this.pos, this.type); } catch (e) { /* sin audio */ } }
        else if (dist < T.reach) this.yaw = turn(this.yaw, Math.atan2(dx, dz), 1 - Math.exp(-8 * dt));
      }
      if (this.lostT > 7 || !G.ps.alive) { this.state = 'lurk'; this.goal = null; this.lurkT = 1; }
    } else {
      // al acecho: camina despacio por el fondo cerca de su guarida
      this.lurkT -= dt;
      if (!this.goal && this.lurkT <= 0) {
        var a = rnd() * T2, r = 1.5 + rnd() * 5, gx = this.lair.x + Math.sin(a) * r, gz = this.lair.z + Math.cos(a) * r;
        if (TER.depth(gx, gz) >= 1.5) this.goal = { x: gx, z: gz }; this.lurkT = 2 + rnd() * 5;
      }
      if (this.goal) {
        var gdx = this.goal.x - this.pos.x, gdz = this.goal.z - this.pos.z, gd = hyp(gdx, gdz);
        if (gd < 0.4) this.goal = null; else { this.yaw = turn(this.yaw, Math.atan2(gdx, gdz), 1 - Math.exp(-3 * dt)); this.step(gdx / gd, gdz / gd, 0.7, dt); sp = 0.7; }
      }
      var bed2 = TER.h(this.pos.x, this.pos.z); this.bed = bed2; this.cy += (bed2 + 0.88 - this.cy) * Math.min(1, 3 * dt);
    }
    if (this.state === 'chase') this.bed = TER.h(this.pos.x, this.pos.z);
    this.speedNow = sp; this.pos.y = this.cy - 0.88;
    // gorgoteos y burbujas
    this.moanT -= dt;
    if (this.moanT <= 0) { this.moanT = this.state === 'chase' ? 2 + rnd() * 2 : 6 + rnd() * 8; try { G.audio.moan(this.pos, this.type, this.state === 'chase' ? 1 : 0.5); } catch (e) { /* sin audio */ } }
    this.animate(dt);
  };
  D.hurt = function (dmg, from, sneak, kb) {
    if (!this.alive) return;
    this.hp -= dmg; this.stun = sneak ? 0.6 : 0.3; this.stunMax = this.stun; this.lastHit = performance.now();
    if (from) { var dx = this.pos.x - from.x, dz = this.pos.z - from.z, d = hyp(dx, dz) || 1, k = 0.5 * (kb == null ? 1 : kb); this.hitDir = { x: dx / d, z: dz / d }; if (this.canGo(this.pos.x + dx / d * k, this.pos.z + dz / d * k)) { this.pos.x += dx / d * k; this.pos.z += dz / d * k; } this.aggro(from.x, from.z); }
    if (this.hp <= 0) { this.die(); return; }
    try { G.audio.zpain(this.pos, this.type); } catch (e) { /* sin audio */ }
  };
  D.die = function (silent) {
    if (!this.alive) return;
    this.alive = false; this.state = 'dead'; this.deadT = 0; this.windT = 0;
    if (!silent) { try { G.audio.zdie(this.pos, this.type); } catch (e) { /* sin audio */ } }
    for (var i = 0; i < 5; i++) emitBubble(this.pos.x + (rnd() - 0.5) * 0.6, this.cy + rnd() * 0.5, this.pos.z + (rnd() - 0.5) * 0.6);
    if (this.lair) this.lair.respawnT = 300;
  };
  D._pose = function (dt) {
    var p = this.parts, g = this.mesh, B = this.B, alive = this.alive, t = (performance.now() / 1000) + this.sway;
    this.phase += this.speedNow * dt * 2.4 + dt * (this.state === 'chase' ? 2.2 : 0.6);
    // postura: de pie en el fondo → inclinado hacia delante al nadar (más tendido cuanto más lejos del suelo)
    var off = this.cy - 0.88 - this.bed, swimming = alive ? (this.state === 'chase' && (off > 0.35 || this.speedNow > 1.0) ? 1 : 0) : 1;
    this.pitchK += (swimming - this.pitchK) * (1 - Math.exp(-5 * dt));
    var pitch = alive ? 0.12 + this.pitchK * 1.08 : 1.35, yaw = this.yaw, sw = this.pitchK, ph = this.phase;
    g.rotation.order = 'YXZ'; g.rotation.set(pitch, yaw, 0);
    // el centro del cuerpo está en (pos.x, cy, pos.z); el pivote son los pies
    var L = 0.88 * this.T.scale, fx = Math.sin(yaw) * L * Math.sin(pitch), fz = Math.cos(yaw) * L * Math.sin(pitch);
    g.position.set(this.pos.x - fx, this.cy - L * Math.cos(pitch), this.pos.z - fz);
    p.legL.scale.y = p.legR.scale.y = 1;
    if (!alive) {
      p.armL.rotation.x = p.armR.rotation.x = -0.6 + Math.sin(t * 1.4) * 0.12; p.legL.rotation.x = 0.2 + Math.sin(t * 1.1) * 0.1; p.legR.rotation.x = 0.1 - Math.sin(t * 1.1) * 0.1;
      p.head.rotation.x = B.headX + 0.4; p.torso.rotation.x = B.lean; p.torso.rotation.z = 0; return;
    }
    var k = Math.sin(ph), reach = this.windT > 0 ? -2.5 + (1 - this.windT / this.T.windup) * 0.5 : -1.35;
    // piernas: patada irregular al nadar, paso lento por el fondo
    p.legL.rotation.x = k * lerp(0.28, 0.55, sw); p.legR.rotation.x = -k * lerp(0.28, 0.55, sw);
    // brazos: al nadar se estiran al frente y braceando por turnos; al acecho cuelgan balanceándose
    var arm = this.state === 'chase' ? reach : -0.3 + Math.sin(t * 0.8) * 0.08;
    p.armL.rotation.x = arm + (this.state === 'chase' ? Math.sin(ph * 0.7) * 0.45 : 0); p.armR.rotation.x = arm - (this.state === 'chase' ? Math.sin(ph * 0.7) * 0.45 : 0);
    p.armL.rotation.z = p.armR.rotation.z = 0;
    p.torso.rotation.x = B.lean + Math.sin(ph * 0.5) * 0.05; p.torso.rotation.z = Math.sin(ph * 0.7) * 0.12 * sw;
    p.head.rotation.x = B.headX - 0.3 * sw + (this.state === 'lurk' ? Math.sin(t * 0.5) * 0.08 : 0); p.head.rotation.z = Math.sin(t * 0.6) * (this.state === 'lurk' ? 0.22 : 0.08);
    if (this.stun > 0 && this.hitDir) { var u = this.stun / (this.stunMax || 0.3); p.torso.rotation.x += Math.sin(Math.min(1, u) * PI) * 0.35; }
  };
  D.animate = function (dt) { this._pose(dt); if (this.slot >= 0) { try { var P = window.ZPool; if (P) P.sync(this); } catch (e) { warn('zpool', e); } } };
  D.dispose = function () { Enemy.prototype.dispose.call(this); };

  // ---- guaridas: se crean en index.html (buildWild) y aquí se ocupan según la modalidad
  function lairList() { return ((G.LEVEL && G.LEVEL.drownedSpawns) || []); }
  function keepLair(i) { var pop = (G.diff && G.diff.pop) || 1; return pop >= 1 || ((i * 0.6180339887) % 1) < pop; }
  function fillLairs() {
    clearDrowned(); lairs = lairList();
    for (var i = 0; i < lairs.length; i++) { lairs[i].respawnT = 0; lairs[i].mob = null; if (keepLair(i)) spawnAt(lairs[i]); }
  }
  function spawnAt(l) { var e = new Drowned(l); l.mob = e; drowned.push(e); return e; }
  function clearDrowned() { for (var i = drowned.length - 1; i >= 0; i--) { try { drowned[i].dispose(); } catch (e) { /* nada */ } } drowned.length = 0; foes.length = 0; }

  // ---- ruidos: los ahogados reaccionan a lo que hace el jugador en el agua
  var onoise = G.noise;
  G.noise = function (x, y, z, radius, src, extra) {
    var r = onoise.apply(this, arguments);
    if (src === 'player' && drowned.length) { var n = { x: x, y: y, z: z, radius: radius, src: src }; for (var i = 0; i < drowned.length; i++) { try { drowned[i].hear(n); } catch (e) { /* nada */ } } }
    return r;
  };
  var prevFoes = G.animalFoes || function () { return []; };
  G.animalFoes = function () { var a = prevFoes(); return foes.length ? a.concat(foes) : a; };

  // ======================================================================== bucle principal
  var started = false, last = performance.now(), lastMode = null, lairT = 5;
  function loop(now) {
    requestAnimationFrame(loop);
    var dt = Math.min((now - last) / 1000, 0.1); last = now;
    try {
      var st = G.state;
      if (st === 'menu') { if (started) { started = false; clearDrowned(); } return; }
      if (!started && st === 'play') {
        started = true; lastMode = G.S && G.S.mode; if (!fishMesh) buildFish(); if (!bub) buildFx(); fillLairs();
      }
      if (!started || st !== 'play') return;
      if (G.S && G.S.mode !== lastMode) { lastMode = G.S.mode; fillLairs(); }
      tickRipples(dt); tickFish(dt); tickFx(dt);
      for (var i = drowned.length - 1; i >= 0; i--) {
        var e = drowned[i];
        if (!e.alive && e.deadT > 30) { e.dispose(); drowned.splice(i, 1); continue; }
        e.update(dt);
      }
      foes.length = 0; for (var j = 0; j < drowned.length; j++) if (drowned[j].alive) foes.push(drowned[j]);
      // reaparición de guaridas vaciadas (cada ~5 min, con el jugador lejos)
      lairT -= dt;
      if (lairT <= 0) {
        lairT = 3; var pl = G.ctrl.pos;
        for (var q = 0; q < lairs.length; q++) { var l = lairs[q]; if (l.mob && !l.mob.alive && l.respawnT > 0) { l.respawnT -= 3; if (l.respawnT <= 0 && hyp(pl.x - l.x, pl.z - l.z) > 80 && keepLair(q)) { var k = drowned.indexOf(l.mob); if (k >= 0) { drowned[k].dispose(); drowned.splice(k, 1); } spawnAt(l); } } }
      }
    } catch (err) { warn('bucle', err); }
  }
  requestAnimationFrame(loop);

  window.VERT_AGUA = {
    swimPose: swimPose, remote: remote, ripple: ripple, drowned: drowned, fish: fish, schools: schools, Drowned: Drowned,
    swimming: isSwimAt,
    // pruebas: ir a un cofre del fondo / crear un ahogado delante
    tpChest: function (i) { var c = G.LEVEL.riverChests[i | 0]; if (!c) return null; G.ctrl.teleport(c.x + 2.5, WL - 1.15, c.z); return c; },
    spawn: function (x, z) { var l = { x: x, z: z, respawnT: 0 }; return spawnAt(l); },
  };
})();
