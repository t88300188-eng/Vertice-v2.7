/*!
 * VÉRTICE · Animación de combate cuerpo a cuerpo (melee-anim.js, v2.4)
 *
 * Machete, bate con clavos y hacha de bombero con golpes de verdad: preparación (se echa hacia atrás), golpe rápido,
 * continuación y recuperación. Los golpes seguidos (menos de ~0,65 s entre uno y otro) encadenan un combo:
 *   machete: tajo diagonal ↘ → tajo de revés ↗ → estocada
 *   bate:    golpe desde arriba → golpe horizontal
 *   hacha:   hachazo desde arriba → hachazo diagonal
 * Además: estela de corte en pantalla (primera persona), sacudida y bajada de cámara en el impacto (más fuerte con el hacha),
 * y en tercera persona el cuerpo gira y las dos manos sujetan el bate y el hacha.
 * El daño y el momento del impacto no cambian: el golpe cae justo cuando se frena el movimiento (windup de cada arma).
 * index.html / historia.html llaman a VERT_MELEE.start / tick / fp / tp (ver v2.4 en el LEEME).
 */
(function () {
  'use strict';
  var clamp = function (v, a, b) { return Math.max(a, Math.min(b, v)); };
  var E = { io: function (u) { return u * u * (3 - 2 * u); }, inn: function (u) { return u * u * u; }, out: function (u) { return 1 - Math.pow(1 - u, 3); } };

  // Poses de primera persona: [sx, sy, rx, ry, rz, z] (A = preparación · B = impacto · C = continuación)
  var IFP = [0.3, -0.27, -0.5, 0.2, 0, -0.45];
  // Tercera persona: [hombro der. x, hombro der. z, codo der., giro del torso, hombro izq. x, hombro izq. z, codo izq.]
  var ITP = [0.4, -0.06, 0.8, 0, 0, 0.06, 0.15];

  var SPEC = {
    machete: { dur: 0.46, follow: 0.1, strike: 0.09, shake: 0.12, dip: 0.3, two: false, combos: [
      { fa: [0.4, -0.1, 0.6, 0.55, 0.9, -0.38], fb: [-0.12, -0.36, -1.05, -0.45, -1.0, -0.62], fc: [-0.24, -0.4, -1.25, -0.6, -1.2, -0.58],
        ta: [2.5, -0.5, 0.6, 0.5, 0, 0.06, 0.15], tb: [0.7, 0.25, 0.2, -0.7, 0, 0.06, 0.15], tc: [0.4, 0.4, 0.3, -0.9, 0, 0.06, 0.15], ang: 0.65, dir: 1 },
      { fa: [-0.08, -0.42, -1.0, -0.3, -0.9, -0.45], fb: [0.42, -0.15, 0.4, 0.7, 0.9, -0.6], fc: [0.52, -0.1, 0.55, 0.85, 1.05, -0.55],
        ta: [1.0, 0.5, 0.7, -0.6, 0, 0.06, 0.15], tb: [1.7, -0.5, 0.2, 0.8, 0, 0.06, 0.15], tc: [1.9, -0.6, 0.3, 1.0, 0, 0.06, 0.15], ang: -0.65, dir: 1 },
      { fa: [0.3, -0.22, -0.2, 0.1, 0.1, -0.16], fb: [0.12, -0.2, -0.05, -0.05, 0, -0.92], fc: [0.1, -0.2, -0.05, -0.05, 0, -0.98],
        ta: [1.3, -0.1, 1.5, 0.3, 0, 0.06, 0.15], tb: [1.55, -0.05, 0.1, -0.1, 0, 0.06, 0.15], tc: [1.55, 0, 0.1, -0.15, 0, 0.06, 0.15], ang: 0, dir: 0 }
    ] },
    bate: { dur: 0.44, follow: 0.1, strike: 0.08, shake: 0.2, dip: 0.55, two: true, combos: [
      { fa: [0.28, 0.02, 1.15, 0.1, 0.3, -0.4], fb: [0.1, -0.4, -1.15, 0, -0.1, -0.6], fc: [0.08, -0.5, -1.3, 0, -0.1, -0.58],
        ta: [2.9, -0.1, 0.5, 0.3, 2.9, 0.3, 0.5], tb: [0.6, 0, 0.2, -0.5, 0.8, 0.3, 0.3], tc: [0.35, 0, 0.3, -0.6, 0.6, 0.3, 0.3], ang: 1.5, dir: 1 },
      { fa: [0.55, -0.2, -0.2, 1.0, 1.1, -0.35], fb: [-0.35, -0.25, -0.3, -0.9, -1.1, -0.6], fc: [-0.5, -0.25, -0.3, -1.1, -1.3, -0.55],
        ta: [1.5, -0.9, 0.3, 1.0, 1.4, -0.4, 0.4], tb: [1.4, 0.7, 0.2, -1.0, 1.3, 0.9, 0.3], tc: [1.4, 0.9, 0.2, -1.2, 1.3, 1.1, 0.3], ang: 0.05, dir: -1 }
    ] },
    hacha: { dur: 0.8, follow: 0.16, strike: 0.12, shake: 0.38, dip: 0.9, two: true, combos: [
      { fa: [0.25, 0.1, 1.35, 0.1, 0.2, -0.3], fb: [0.05, -0.5, -1.25, 0, 0, -0.65], fc: [0.02, -0.6, -1.4, 0, 0, -0.6],
        ta: [3.0, -0.1, 0.5, 0.35, 3.0, 0.3, 0.5], tb: [0.5, 0, 0.2, -0.5, 0.7, 0.3, 0.3], tc: [0.3, 0, 0.3, -0.65, 0.5, 0.3, 0.3], ang: 1.5, dir: 1 },
      { fa: [0.45, 0.05, 1.1, 0.5, 0.7, -0.3], fb: [-0.05, -0.5, -1.1, -0.3, -0.5, -0.65], fc: [-0.12, -0.58, -1.25, -0.4, -0.6, -0.6],
        ta: [2.6, -0.7, 0.5, 0.6, 2.6, 0.1, 0.5], tb: [0.7, 0.4, 0.2, -0.7, 0.9, 0.5, 0.3], tc: [0.4, 0.5, 0.3, -0.85, 0.6, 0.6, 0.3], ang: 0.9, dir: 1 }
    ] }
  };

  var last = null;
  function start(kind, MS) {
    var S = SPEC[kind]; if (!S) return { t: 0, hit: false };
    var now = performance.now(), combo = last && last.kind === kind && now < last.end ? (last.combo + 1) % S.combos.length : 0;
    last = { kind: kind, combo: combo, end: now + (S.dur + 0.65) * 1000 };
    return { t: 0, hit: false, kind: kind, combo: combo, dur: S.dur, fx: false, windup: MS && MS.windup != null ? MS.windup : 0.16 };
  }

  // tiempos normalizados: tA = fin de la preparación · tB = impacto · tC = fin de la continuación
  function times(atk, S) {
    var tB = clamp(atk.windup / atk.dur, 0.12, 0.7), tA = Math.max(0.08, tB - S.strike / atk.dur), tC = Math.min(0.92, tB + S.follow / atk.dur);
    return { a: tA, b: tB, c: tC };
  }
  function sample(p, T, I, A, B, C) {
    var a, b, u;
    if (p < T.a) { a = I; b = A; u = E.io(p / T.a); }
    else if (p < T.b) { a = A; b = B; u = E.inn((p - T.a) / (T.b - T.a)); }
    else if (p < T.c) { a = B; b = C; u = E.out((p - T.b) / (T.c - T.b)); }
    else { a = C; b = I; u = E.io((p - T.c) / (1 - T.c)); }
    var o = new Array(a.length); for (var i = 0; i < a.length; i++) o[i] = a[i] + (b[i] - a[i]) * u; return o;
  }
  function ctx(atk) {
    var S = atk && SPEC[atk.kind]; if (!S || !atk.dur) return null;
    return { S: S, C: S.combos[atk.combo % S.combos.length], T: times(atk, S), p: clamp(atk.t / atk.dur, 0, 1) };
  }

  function fp(atk) {
    var c = ctx(atk); if (!c) return null;
    var v = sample(c.p, c.T, IFP, c.C.fa, c.C.fb, c.C.fc);
    return { sx: v[0], sy: v[1], rx: v[2], ry: v[3], rz: v[4], z: v[5] };
  }
  function tp(atk) {
    var c = ctx(atk); if (!c) return null;
    var v = sample(c.p, c.T, ITP, c.C.ta, c.C.tb, c.C.tc);
    return { rx: v[0], rz: v[1], el: v[2], twist: v[3], lx: v[4], lz: v[5], lel: v[6], two: c.S.two };
  }

  // ---- estela de corte en pantalla (primera persona)
  var pivot = null, slash = null;
  function ensureTrail() {
    var G = window.VERTICE; if (pivot || !G || !G.camera || !window.THREE) return !!pivot;
    var THREE = window.THREE, cv = document.createElement('canvas'); cv.width = 256; cv.height = 64;
    var g = cv.getContext('2d'), grd = g.createLinearGradient(0, 0, 256, 0);
    grd.addColorStop(0, 'rgba(255,255,255,0)'); grd.addColorStop(0.55, 'rgba(235,242,250,0.55)'); grd.addColorStop(1, 'rgba(255,255,255,0.95)');
    g.fillStyle = grd; g.beginPath(); g.moveTo(0, 32); g.quadraticCurveTo(128, 2, 256, 14); g.quadraticCurveTo(140, 22, 0, 32); g.fill();
    g.beginPath(); g.moveTo(0, 32); g.quadraticCurveTo(128, 62, 256, 50); g.quadraticCurveTo(140, 42, 0, 32); g.globalAlpha = 0.35; g.fill();
    var tex = new THREE.CanvasTexture(cv);
    slash = new THREE.Mesh(new THREE.PlaneGeometry(0.95, 0.24), new THREE.MeshBasicMaterial({ map: tex, transparent: true, opacity: 0, depthWrite: false, depthTest: false, blending: THREE.AdditiveBlending, fog: false }));
    slash.renderOrder = 20; pivot = new THREE.Group(); pivot.position.set(0, -0.02, -0.75); pivot.add(slash); pivot.visible = false; G.camera.add(pivot);
    return true;
  }
  function tick(atk, dt) {
    var G = window.VERTICE;
    if (!atk || !G) { if (pivot && pivot.visible) pivot.visible = false; return; }
    var c = ctx(atk); if (!c) return;
    if (!atk.fx && atk.t >= atk.windup) {   // impacto: sacudida y bajada de cámara
      atk.fx = true; G.shake = Math.max(G.shake || 0, c.S.shake); G.camDip = Math.max(G.camDip || 0, c.S.dip);
    }
    var fpv = G.S && !G.S.tp;
    if (!fpv || c.C.dir === 0 || !ensureTrail()) { if (pivot) pivot.visible = false; return; }
    var T = c.T, p = c.p, op = 0, k = 0;
    if (p >= T.a && p < T.b) { k = E.inn((p - T.a) / (T.b - T.a)); op = k; }
    else if (p >= T.b && p < T.c + 0.12) { k = 1; op = 1 - clamp((p - T.b) / (T.c + 0.12 - T.b), 0, 1); }
    pivot.visible = op > 0.02; pivot.rotation.z = c.C.ang;
    var dir = atk.kind === 'bate' && atk.combo === 1 ? -1 : 1;
    slash.position.x = (-0.38 + 0.76 * (p < T.b ? k : 1)) * dir; slash.scale.x = dir; slash.material.opacity = op * (atk.kind === 'hacha' ? 0.8 : atk.kind === 'bate' ? 0.5 : 0.65);
    slash.material.color.set(atk.kind === 'machete' ? 0xdfe9f2 : atk.kind === 'hacha' ? 0xffd9b0 : 0xe8dcc8);
  }

  window.VERT_MELEE = { SPEC: SPEC, start: start, tick: tick, fp: fp, tp: tp };
})();
