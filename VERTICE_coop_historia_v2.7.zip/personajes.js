/*!
 * VÉRTICE · Personajes nuevos: Imbachi, Valentina y Wilmarys  (personajes.js, v2.1)
 *
 * Se carga ANTES del script principal de index.html / historia.html. Define:
 *   window.VERTICE_CHARS = { presets, mods, smoke }
 *  - presets: fichas para el selector de personaje (se mezclan en CH).
 *  - mods:    funciones que reconstruyen la ropa y el pelo sobre el esqueleto de buildChar() (mismo rig que Vértice y Lena,
 *             así caminan, apuntan, se agachan y se ven en multijugador igual que los demás).
 *  - smoke:   frases de la cinemática de fumar.
 * Imbachi mide lo mismo que el protagonista (1,78 m).
 */
(function () {
  'use strict';

  var presets = {
    imbachi: {
      name: 'Imbachi', role: 'Superviviente · Rastreador', info: '1,78 m · delgado y rápido · pelo largo y rizado',
      h: 1.78, male: 1, mod: 'imbachi', stubble: 0, tired: 0,
      skin: '#b4856a', eye: '#2a1a12', hair: 0x0f0b0a, hairCss: '#0f0b0a',
      jacket: 0x4b4d3a, under: 0x141416, pants: 0x3f3c30, boots: 0x3a2c22, scarf: 0x33363a, glove: 0x1a1a1c, pack: 0x45442f, patch: 0x8a5a2a,
      pal: ['#141416', '#4b4d3a', '#3f3c30', '#7d1f1c', '#0f0b0a'], scars: [],
      // aliado
      ally: { role: 'Combatiente', hp: 120, speed: 1.0, acc: 0.78, gun: 'pistola', ammo: 36, melee: 'machete' }
    },
    valentina: {
      name: 'Valentina', role: 'Superviviente · Corredora', info: '1,66 m · ágil y callejera · pelo largo y liso',
      h: 1.66, male: 0, mod: 'valentina', tired: 0,
      skin: '#c9a084', eye: '#2a1a12', hair: 0x0c0a0a, hairCss: '#0c0a0a',
      jacket: 0x010101, panel: 0x141416, under: 0x141416, pants: 0x7d97b4, boots: 0x151517, scarf: 0x2a2a2e, glove: 0xc9a084, pack: 0x2a2a2e, patch: 0x7c2420,
      lipCol: 'rgba(120,52,52,.9)', lash: 1,
      pal: ['#141416', '#7d97b4', '#c9a084', '#e9e5dc', '#0c0a0a'], scars: [],
      ally: { role: 'Corredora', hp: 85, speed: 1.18, acc: 0.62, gun: 'pistola', ammo: 24, melee: 'machete' }
    },
    wilmarys: {
      name: 'Wilmarys', role: 'Superviviente · Sanadora', info: '1,62 m · estilo callejero · pelo largo y rizado, corona de flores',
      h: 1.62, male: 0, mod: 'wilmarys', tired: 0,
      skin: '#b98a6c', eye: '#2a1a12', hair: 0x0b0909, hairCss: '#0b0909',
      jacket: 0x2b2622, panel: 0x16161a, under: 0x16161a, pants: 0x26262a, boots: 0x141416, scarf: 0x2a2a2e, glove: 0x141416, pack: 0x2a2a2e, patch: 0x7c2420,
      lipCol: 'rgba(110,48,52,.9)', lash: 1, blush: 1,
      pal: ['#16161a', '#2b2622', '#26262a', '#f2efe8', '#0b0909'], scars: [],
      ally: { role: 'Sanadora', hp: 80, speed: 1.0, acc: 0.55, gun: 'pistola', ammo: 18, melee: 'machete', healer: true }
    }
  };

  // ---------- utilidades ----------
  function rng(seed) { var s = seed; return function () { s = (s * 16807) % 2147483647; return s / 2147483647; }; }

  // Deja solo los hijos indicados (el resto de ropa base se descarta y se reconstruye)
  function strip(p, keep) {
    for (var i = p.children.length - 1; i >= 0; i--) {
      var ch = p.children[i];
      if (keep && keep.indexOf(ch) >= 0) continue;
      p.remove(ch);
      if (ch.traverse) ch.traverse(function (o) { if (o.geometry) o.geometry.dispose(); });
    }
  }

  // Descarta la ropa base de piernas, torso, brazos y cabeza; conserva la jerarquía del esqueleto
  function clearBase(x) {
    x.legs.forEach(function (L) { strip(L.hip, [L.kn]); strip(L.kn, []); });
    strip(x.tor, [x.bp, x.nk, x.arms[0].sh, x.arms[1].sh]);
    x.arms.forEach(function (a) { strip(a.sh, [a.el]); strip(a.el, [a.hn]); strip(a.hn, []); });
    var headMesh = null;
    x.hd.children.forEach(function (o) { if (o.isMesh && Array.isArray(o.material)) headMesh = o; });
    strip(x.hd, headMesh ? [headMesh] : []);
    strip(x.nk, [x.hd]);
  }

  // ---------- pelo largo (liso u ondulado) ----------
  function longHair(x, o) {
    var B = x.B, hr = x.hr, hd = x.hd, tor = x.tor, r = rng(o.seed || 11), wave = o.wave || 0;
    // casquete y laterales
    B(hd, 0.205, 0.07, 0.225, 0, 0.255, 0.005, hr);
    B(hd, 0.2, 0.26, 0.07, 0, 0.12, 0.118, hr);
    B(hd, 0.026, 0.2, 0.17, -0.101, 0.14, 0.02, hr); B(hd, 0.026, 0.2, 0.17, 0.101, 0.14, 0.02, hr);
    // flequillo (cortinas a los lados de la frente) o raya al medio
    if (o.bangs) { B(hd, 0.1, 0.07, 0.04, -0.05, 0.228, -0.108, hr, 0, 0, 0.22); B(hd, 0.1, 0.07, 0.04, 0.05, 0.228, -0.108, hr, 0, 0, -0.22); B(hd, 0.05, 0.14, 0.04, -0.085, 0.15, -0.108, hr, 0, 0, 0.1); B(hd, 0.05, 0.14, 0.04, 0.085, 0.15, -0.108, hr, 0, 0, -0.1); }
    else { B(hd, 0.1, 0.06, 0.04, -0.05, 0.236, -0.108, hr, 0, 0, 0.35); B(hd, 0.1, 0.06, 0.04, 0.05, 0.236, -0.108, hr, 0, 0, -0.35); B(hd, 0.045, 0.16, 0.04, -0.088, 0.14, -0.106, hr); B(hd, 0.045, 0.16, 0.04, 0.088, 0.14, -0.106, hr); }
    // cascada por la espalda (hasta la cintura) en tres tramos que ondean un poco
    var segs = [[0.3, 0.2, 0.62, 0.15], [0.29, 0.2, 0.46, 0.165], [0.27, 0.2, 0.30, 0.17], [0.24, 0.18, 0.15, 0.17]];
    segs.forEach(function (s, i) { B(tor, s[0], s[1], 0.06, (r() - 0.5) * wave * 0.02, s[2], s[3], hr, 0.05 * i, 0, (r() - 0.5) * wave * 0.1); });
    B(hd, 0.18, 0.1, 0.07, 0, -0.01, 0.12, hr);
    // mechones por delante de los hombros
    for (var sx = -1; sx <= 1; sx += 2) {
      B(tor, 0.07, 0.2, 0.07, sx * 0.17, 0.5, -0.045, hr, 0, 0, sx * 0.1);
      B(tor, 0.06, 0.2, 0.055, sx * 0.158, 0.33, -0.125, hr, 0.05, 0, sx * 0.05);
    }
  }

  // ---------- Valentina: top negro, short de jean holgado, botines negros, pulseras ----------
  function valentina(x) {
    var c = x.c, B = x.B, Cy = x.Cy, M = x.M, tor = x.tor, hd = x.hd, legs = x.legs, arms = x.arms;
    clearBase(x);
    var sk = new x.THREE.MeshStandardMaterial({ color: c.skin, roughness: 0.8 });
    var top = M(c.panel), jean = M(0x7d97b4, 0.95), jeanD = M(0x5f7a97, 0.95), jeanL = M(0xa8bdd0, 0.95), blk = M(0x151517, 0.8), wh = M(0xe9e5dc), band = M(0x1d1d20, 0.6, 0.3);
    x.jk.color.set(c.skin); x.gl.color.set(c.skin);            // brazos en primera persona: piel
    x.bp.visible = false;
    hd.children.forEach(function (o) { if (o.isMesh && Array.isArray(o.material)) o.scale.set(1.16, 0.97, 1.08); });   // cara más redonda
    legs.forEach(function (L, i) {
      var hip = L.hip, kn = L.kn;
      B(hip, 0.21, 0.42, 0.235, 0, -0.21, 0, jean); B(hip, 0.215, 0.03, 0.24, 0, -0.425, 0, jeanL);          // short ancho hasta casi la rodilla
      B(hip, 0.04, 0.14, 0.24, (i ? 1 : -1) * 0.11, -0.23, 0, jeanD);                                          // costura lateral
      B(hip, 0.12, 0.04, 0.14, 0, -0.44, 0, sk);
      B(kn, 0.115, 0.26, 0.135, 0, -0.13, 0, sk);                                                              // pantorrilla
      B(kn, 0.125, 0.09, 0.145, 0, -0.275, 0, wh);                                                             // media blanca
      B(kn, 0.16, 0.16, 0.18, 0, -0.34, 0, blk);                                                               // bota alta
      B(kn, 0.15, 0.09, 0.14, 0, -0.395, -0.15, blk);                                                          // puntera gruesa
      B(kn, 0.17, 0.06, 0.32, 0, -0.42, -0.05, blk); B(kn, 0.172, 0.022, 0.325, 0, -0.44, -0.05, wh);          // suela de plataforma
    });
    // tronco: abdomen descubierto, top tipo bandeau, cintura del short
    B(tor, 0.34, 0.5, 0.2, 0, 0.27, 0, sk);
    B(tor, 0.36, 0.28, 0.215, 0, 0.37, 0, top); B(tor, 0.15, 0.09, 0.06, -0.085, 0.43, -0.105, top); B(tor, 0.15, 0.09, 0.06, 0.085, 0.43, -0.105, top);
    B(tor, 0.37, 0.1, 0.225, 0, 0.055, 0, jean); B(tor, 0.375, 0.02, 0.23, 0, 0.11, 0, jeanL);
    Cy(tor, 0.055, 0.12, 0, 0.6, 0, sk);
    B(tor, 0.42, 0.09, 0.21, 0, 0.5, 0, sk);                                                                   // hombros y clavículas
    // brazos descubiertos con pulseras
    arms.forEach(function (a, i) {
      B(a.sh, 0.098, 0.31, 0.108, 0, -0.145, 0, sk); B(a.sh, 0.115, 0.09, 0.12, 0, 0, 0, sk);
      B(a.el, 0.088, 0.28, 0.098, 0, -0.135, 0, sk);
      B(a.el, 0.1, 0.03, 0.11, 0, -0.245, 0, band); B(a.el, 0.1, 0.02, 0.11, 0, -0.215, 0, wh);
      B(a.hn, 0.08, 0.14, 0.09, 0, -0.06, 0, sk);
    });
    longHair(x, { seed: 5, bangs: true, wave: 0.2 });
    // cadena fina en el cuello
    B(tor, 0.1, 0.01, 0.01, 0, 0.5, -0.108, band);
  }

  // ---------- Imbachi: ropa de superviviente (chaqueta de campo, franela atada, cargo) y pelo largo rizado ----------
  function imbachi(x) {
    var c = x.c, B = x.B, M = x.M, tor = x.tor, hd = x.hd, T = x.THREE, r = rng(21);
    // se conserva la ropa base de superviviente (chaqueta, bufanda, cinturón, mochila); se cambia el pelo y se añaden detalles
    var headMesh = null;
    hd.children.forEach(function (o) { if (o.isMesh && Array.isArray(o.material)) headMesh = o; });
    strip(hd, headMesh ? [headMesh] : []);
    var hr = x.hr, sk = new T.MeshStandardMaterial({ color: c.skin, roughness: 0.8 });
    // orejas tapadas por los rizos; masa de rizos: coronilla, laterales, nuca y caída hasta los hombros
    var curl = function (p, cx, cy, cz, s) { B(p, s * (0.8 + r() * 0.5), s * (0.8 + r() * 0.5), s * (0.8 + r() * 0.5), cx, cy, cz, hr, r() * 1.2, r() * 3, r() * 1.2); };
    var i, a;
    for (i = 0; i < 26; i++) { a = r() * 6.283; var rr = 0.03 + r() * 0.09; curl(hd, Math.cos(a) * rr, 0.25 + r() * 0.1, Math.sin(a) * rr * 1.05, 0.075 + r() * 0.045); }       // coronilla
    for (i = 0; i < 16; i++) curl(hd, (i % 2 ? 1 : -1) * (0.105 + r() * 0.04), 0.02 + r() * 0.22, -0.06 + r() * 0.17, 0.07 + r() * 0.04);                                        // laterales
    for (i = 0; i < 20; i++) curl(hd, (r() - 0.5) * 0.2, -0.06 + r() * 0.3, 0.11 + r() * 0.06, 0.075 + r() * 0.04);                                                                 // nuca
    for (i = 0; i < 6; i++) curl(hd, (r() - 0.5) * 0.17, 0.22 + r() * 0.04, -0.1 - r() * 0.02, 0.05 + r() * 0.03);                                                                  // flequillo rizado
    B(hd, 0.05, 0.1, 0.04, -0.092, 0.13, -0.098, hr, 0, 0, 0.1); B(hd, 0.05, 0.1, 0.04, 0.092, 0.13, -0.098, hr, 0, 0, -0.1);                                                      // mechones junto a la cara
    for (i = 0; i < 22; i++) { a = Math.PI * (0.55 + r() * 0.9); curl(tor, Math.cos(a) * (0.12 + r() * 0.07), 0.38 + r() * 0.24, Math.sin(a) * (0.1 + r() * 0.05) + 0.02, 0.07 + r() * 0.04); }   // rizos largos sobre cuello y hombros
    for (i = 0; i < 8; i++) curl(tor, (r() - 0.5) * 0.26, 0.3 + r() * 0.12, 0.14 + r() * 0.03, 0.075 + r() * 0.03);
    B(hd, 0.02, 0.05, 0.04, -0.1, 0.12, 0, sk); B(hd, 0.02, 0.05, 0.04, 0.1, 0.12, 0, sk);
    // detalles: cadena con colgante, franela a cuadros atada a la cintura, correa al hombro
    var steel = M(0x9aa1a8, 0.35, 0.8);
    B(tor, 0.15, 0.012, 0.012, 0, 0.53, -0.125, steel); B(tor, 0.012, 0.09, 0.012, 0, 0.49, -0.128, steel); B(tor, 0.03, 0.04, 0.012, 0, 0.44, -0.13, steel);
    var plaid = new T.CanvasTexture(function () { var cv = document.createElement('canvas'); cv.width = cv.height = 32; var g = cv.getContext('2d'); g.fillStyle = '#7a1f1c'; g.fillRect(0, 0, 32, 32); g.fillStyle = 'rgba(15,15,18,.85)'; g.fillRect(0, 8, 32, 8); g.fillRect(8, 0, 8, 32); g.fillStyle = 'rgba(15,15,18,.4)'; g.fillRect(0, 24, 32, 3); g.fillRect(24, 0, 3, 32); return cv; }());
    plaid.wrapS = plaid.wrapT = T.RepeatWrapping; plaid.repeat.set(2, 1);
    var fl = new T.MeshStandardMaterial({ color: 0xffffff, map: plaid, roughness: 0.95 });
    B(tor, 0.43, 0.1, 0.275, 0, 0.0, 0, fl); B(tor, 0.1, 0.22, 0.04, -0.13, -0.11, 0.12, fl, 0.1, 0, 0.12); B(tor, 0.1, 0.18, 0.04, -0.02, -0.1, 0.13, fl, 0.05, 0, -0.08);   // se ata por detrás y cuelgan las mangas
  }

  // ---------- Wilmarys: top negro con mariposa, chaqueta caída, cargo holgado, botas, corona de flores ----------
  function wilmarys(x) {
    var c = x.c, B = x.B, Cy = x.Cy, M = x.M, tor = x.tor, hd = x.hd, legs = x.legs, arms = x.arms, T = x.THREE, r = rng(33);
    clearBase(x);
    var P = function (col, ro, me) { return new T.MeshStandardMaterial({ color: col, roughness: ro == null ? 0.9 : ro, metalness: me || 0 }); };
    var sk = P(c.skin, 0.8), blk = P(0x1a1a1d, 0.95), cargo = P(0x232326, 0.97), cargoL = P(0x2e2e32, 0.97), boot = P(0x141416, 0.8), sole = P(0x0c0c0d, 0.7),
        jk = P(0x2d2824, 1), jkD = P(0x1f1b18, 1), steel = P(0x9aa1a8, 0.35, 0.8), glv = P(0x141416, 0.9), band = P(0x1d1d20, 0.6, 0.3), wh = P(0xf4f1ea, 0.85), ye = P(0xe8c24a, 0.8), lf = P(0x4d6b3c, 0.9);
    var bf = new T.CanvasTexture(function () {
      var cv = document.createElement('canvas'); cv.width = cv.height = 64; var g = cv.getContext('2d');
      g.fillStyle = '#17171a'; g.fillRect(0, 0, 64, 64); g.fillStyle = 'rgba(235,235,235,.85)';
      [[-1], [1]].forEach(function (q) { var s = q[0]; g.beginPath(); g.ellipse(32 + s * 11, 24, 10, 14, s * 0.5, 0, 6.3); g.fill(); g.beginPath(); g.ellipse(32 + s * 8, 42, 7, 9, -s * 0.5, 0, 6.3); g.fill(); });
      g.fillStyle = '#17171a'; for (var i = 0; i < 12; i++) { g.beginPath(); g.arc(32 + (i % 2 ? 1 : -1) * (6 + (i >> 1) * 2.5), 18 + (i >> 1) * 4, 2, 0, 6.3); g.fill(); }
      g.fillStyle = '#ddd'; g.fillRect(30, 18, 4, 30); return cv; }());
    var topM = new T.MeshStandardMaterial({ color: 0xffffff, map: bf, roughness: 0.95 });
    x.jk.color.set(0x2d2824); x.gl.color.set(0x141416);        // brazos en primera persona: manga de chaqueta y guantes
    x.bp.visible = false;
    hd.children.forEach(function (o) { if (o.isMesh && Array.isArray(o.material)) o.scale.set(1.1, 0.98, 1.05); });
    // piernas: cargo holgado y arrugado, recogido en los tobillos, botas gruesas
    legs.forEach(function (L, i) {
      var hip = L.hip, kn = L.kn, sd = i ? 1 : -1;
      B(hip, 0.25, 0.46, 0.28, 0, -0.22, 0, cargo); B(hip, 0.255, 0.05, 0.285, 0, -0.03, 0, cargoL);
      B(hip, 0.06, 0.14, 0.05, sd * 0.13, -0.24, 0.0, cargoL); B(hip, 0.02, 0.1, 0.06, sd * 0.158, -0.26, 0, cargo);       // bolsillo cargo lateral
      B(hip, 0.02, 0.2, 0.01, 0, -0.2, -0.143, cargoL, 0, 0, 0.05 * sd);                                                  // arrugas
      B(kn, 0.24, 0.3, 0.27, 0, -0.14, 0, cargo); B(kn, 0.2, 0.06, 0.24, 0, -0.3, 0, cargoL);                              // bota del pantalón recogida
      B(kn, 0.17, 0.12, 0.2, 0, -0.35, 0, boot);                                                                          // caña de la bota
      B(kn, 0.16, 0.1, 0.16, 0, -0.395, -0.16, boot);                                                                     // puntera gruesa
      B(kn, 0.185, 0.06, 0.36, 0, -0.43, -0.05, sole); B(kn, 0.02, 0.03, 0.2, sd * 0.09, -0.34, -0.02, steel);            // suela + hebilla
    });
    // tronco: abdomen descubierto, crop top con mariposa, tirantes
    B(tor, 0.33, 0.48, 0.2, 0, 0.27, 0, sk);
    B(tor, 0.35, 0.22, 0.212, 0, 0.4, 0, topM); B(tor, 0.36, 0.03, 0.218, 0, 0.29, 0, blk);
    B(tor, 0.05, 0.14, 0.215, -0.11, 0.55, 0, blk); B(tor, 0.05, 0.14, 0.215, 0.11, 0.55, 0, blk);
    // cinturón tachonado con cadena y cintura del cargo
    B(tor, 0.37, 0.12, 0.23, 0, 0.03, 0, cargo); B(tor, 0.375, 0.04, 0.235, 0, 0.1, 0, blk);
    for (var k = 0; k < 7; k++) B(tor, 0.02, 0.02, 0.02, -0.15 + k * 0.05, 0.1, -0.12, steel);
    B(tor, 0.06, 0.05, 0.02, 0, 0.1, -0.123, steel);
    for (k = 0; k < 6; k++) B(tor, 0.012, 0.03, 0.012, 0.15 - k * 0.012, 0.07 - k * 0.03, -0.12 - (k % 2) * 0.012, steel, 0, 0, 0.3);   // cadena colgante
    Cy(tor, 0.055, 0.12, 0, 0.6, 0, sk);
    B(tor, 0.4, 0.08, 0.2, 0, 0.5, 0, sk);                                                                               // hombros descubiertos
    // collar con dije
    B(tor, 0.12, 0.012, 0.012, 0, 0.51, -0.108, steel); B(tor, 0.012, 0.07, 0.012, 0, 0.475, -0.11, steel); B(tor, 0.028, 0.03, 0.012, 0, 0.43, -0.112, steel);
    // chaqueta caída por los hombros: cuelga de los brazos y por la espalda
    B(tor, 0.46, 0.34, 0.07, 0, 0.36, 0.125, jk); B(tor, 0.44, 0.1, 0.075, 0, 0.55, 0.115, jkD);
    B(tor, 0.04, 0.3, 0.04, -0.17, 0.3, -0.115, jkD, 0, 0, 0.05); B(tor, 0.04, 0.3, 0.04, 0.17, 0.3, -0.115, jkD, 0, 0, -0.05);   // solapas colgando
    B(tor, 0.02, 0.18, 0.02, -0.07, 0.5, -0.11, steel); B(tor, 0.02, 0.16, 0.02, 0.07, 0.5, -0.11, jkD);                          // correa
    // brazos: chaqueta sobre el brazo, brazalete en el bíceps, guantes sin dedos
    arms.forEach(function (a, i) {
      B(a.sh, 0.115, 0.12, 0.125, 0, -0.03, 0, jk);                                                                      // hombro/caída de chaqueta
      B(a.sh, 0.11, 0.2, 0.12, 0, -0.2, 0, jk); if (i) B(a.sh, 0.12, 0.05, 0.13, 0, -0.16, 0, band);                       // manga hasta el codo + brazalete
      B(a.sh, 0.1, 0.1, 0.11, 0, -0.29, 0, sk);
      B(a.el, 0.098, 0.28, 0.108, 0, -0.14, 0, jk, 0, 0, 0); B(a.el, 0.104, 0.05, 0.114, 0, -0.01, 0, jkD);               // antebrazo: manga ancha
      B(a.el, 0.092, 0.06, 0.1, 0, -0.26, 0, sk);                                                                         // muñeca
      B(a.hn, 0.09, 0.09, 0.1, 0, -0.04, 0, glv); B(a.hn, 0.085, 0.07, 0.095, 0, -0.1, 0, sk);                             // guante sin dedos
    });
    // pelo largo rizado
    var hr = x.hr, i, a;
    var curl = function (p, cx, cy, cz, s) { B(p, s * (0.8 + r() * 0.5), s * (0.8 + r() * 0.5), s * (0.8 + r() * 0.5), cx, cy, cz, hr, r() * 1.2, r() * 3, r() * 1.2); };
    for (i = 0; i < 28; i++) { a = r() * 6.283; var rr = 0.03 + r() * 0.09; curl(hd, Math.cos(a) * rr, 0.24 + r() * 0.07, Math.sin(a) * rr * 1.05 + 0.02, 0.075 + r() * 0.04); }
    for (i = 0; i < 18; i++) curl(hd, (i % 2 ? 1 : -1) * (0.105 + r() * 0.045), 0.0 + r() * 0.25, -0.06 + r() * 0.18, 0.07 + r() * 0.045);
    for (i = 0; i < 24; i++) curl(hd, (r() - 0.5) * 0.22, -0.08 + r() * 0.32, 0.11 + r() * 0.06, 0.075 + r() * 0.045);
    for (i = 0; i < 8; i++) curl(hd, (r() - 0.5) * 0.19, 0.22 + r() * 0.04, -0.1 - r() * 0.02, 0.05 + r() * 0.03);
    for (i = 0; i < 30; i++) { a = Math.PI * r(); curl(tor, Math.cos(a) * (0.14 + r() * 0.1), 0.2 + r() * 0.42, 0.13 + Math.sin(a) * 0.05 + r() * 0.03, 0.075 + r() * 0.045); }
    for (var sx = -1; sx <= 1; sx += 2) for (i = 0; i < 4; i++) curl(tor, sx * (0.21 + r() * 0.03), 0.52 - i * 0.09, -0.02 + r() * 0.05, 0.07 + r() * 0.03);   // rizos sobre los hombros   // cascada de rizos
    for (i = 0; i < 14; i++) curl(tor, (r() - 0.5) * 0.3, 0.12 + r() * 0.2, 0.15 + r() * 0.04, 0.08 + r() * 0.035);
    // corona de flores blancas
    for (i = 0; i < 14; i++) {
      a = i / 14 * 6.283; var cx = Math.sin(a) * 0.15, cz = Math.cos(a) * 0.15;
      B(hd, 0.062, 0.05, 0.062, cx, 0.325, cz, i % 4 === 0 ? ye : wh, 0.4, a, 0.3);
      B(hd, 0.03, 0.03, 0.03, cx * 0.99, 0.35, cz * 0.99, wh, 0.2, a, 0.6);
      if (i % 2) B(hd, 0.04, 0.015, 0.06, cx * 1.12, 0.31, cz * 1.12, lf, 0, a, 0.5);
    }
  }

  var mods = { valentina: valentina, wilmarys: wilmarys, imbachi: imbachi };

  var smoke = {
    imbachi: ['Respira hondo… huele a humo y a lluvia.', 'Uno aprende a escuchar antes de ver.', 'Seguimos aquí. Eso cuenta.'],
    wilmarys: ['Si alguien se hiere, yo lo cuido.', 'Las flores siguen floreciendo… hasta aquí.', 'Respira. Yo te cubro.'],
    valentina: ['Mis manos no tiemblan… casi.', 'Nunca pensé que fumaría escondida de zombis.', 'Un cigarro y a correr otra vez.']
  };

  window.VERTICE_CHARS = { presets: presets, mods: mods, smoke: smoke };
})();
