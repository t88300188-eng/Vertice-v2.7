/*!
 * VÉRTICE · Supervivientes aliados (supervivientes.js, v2.0)
 *
 * Valentina e Imbachi también viven en el mundo como supervivientes que se pueden reclutar.
 * Se engancha a `window.VERTICE` igual que vertice-mp.js: casi todo el código está aquí.
 *
 *  - Se les habla con E (o «Usar»): reclutar, y después panel de órdenes (seguir / quedarse, dar munición, curar, despedir).
 *  - Hasta 2 siguen al jugador a la vez. Siguen por escaleras y puertas, disparan o golpean con machete, huyen del Gigante
 *    y de los infectados cuando están heridos; caídos, hay que levantarlos con una venda antes de que se desangren.
 *  - Los infectados los atacan: eligen como objetivo al más cercano entre el jugador y los supervivientes.
 *  - Valentina corre más rápido; Imbachi aguanta y dispara mejor.
 *  - Se guardan con la partida. En cooperativo los simula el anfitrión y los invitados reciben una copia (ver vertice-mp.js).
 *  - Tecla N (o el botón 👥): todos los reclutados siguen / se quedan.
 */
(function () {
  'use strict';
  var G = window.VERTICE, THREE = window.THREE, VC = window.VERTICE_CHARS;
  if (!G || !THREE || !VC || !G.Enemy || !G.buildChar || !G.dir || !G.LEVEL) return;
  var Enemy = G.Enemy, LEVEL = G.LEVEL, STORY = !!LEVEL.towerBox, KEYS = ['valentina', 'wilmarys', 'imbachi'];
  var T2 = Math.PI * 2, MAXF = 2, hyp = Math.hypot, rnd = Math.random;
  var list = [], tracers = [], started = false, pending = null, last = performance.now(), warned = false, nextHeal = 0;

  var clamp = function (v, a, b) { return Math.max(a, Math.min(b, v)); };
  var lerp = function (a, b, t) { return a + (b - a) * t; };
  var smooth = function (a, b, x) { var t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
  var wrapPi = function (a) { return a - T2 * Math.round(a / T2); };
  var turn = function (a, b, k) { return a + wrapPi(b - a) * k; };
  var toast = function (m, k, ms) { try { G.ui.toast(m, k || '', ms || 3500); } catch (e) { /* sin interfaz */ } };
  var mp = function () { return window.VERTICE_MP || null; };
  var role = function () { var m = mp(); try { return m ? m.role() : null; } catch (e) { return null; } };
  var isGuest = function () { return role() === 'guest'; };

  // ======================================================================== lugares donde se encuentran
  // Historia (Torre Mirador): Valentina en un pasillo de la torre, Imbachi en el patio. Modo libre: dentro de dos edificios del asentamiento.
  function spots() {
    if (STORY) return {
      valentina: { x: 9, z: 0.3, y: LEVEL.Yf(15), say: 'Piso 15' },
      wilmarys: { x: -9, z: 0.3, y: LEVEL.Yf(11), say: 'Piso 11' },
      imbachi: { x: 34, z: -22, y: 0 }
    };
    return { valentina: { x: 12, z: 14, y: 0 }, wilmarys: { x: 33, z: 19, y: 0 }, imbachi: { x: 11.5, z: -19, y: 0 } };
  }

  function groundY(x, z, y) {
    try { var T = G.TERRAIN; if (T && T.active && T.active(x, z)) return T.h(x, z); } catch (e) { /* sin terreno */ }
    return y || 0;
  }

  // La torre tiene una rejilla de navegación por piso; el mapa libre tiene una sola
  function inLevel(y, fn) {
    var nav = G.nav; if (typeof nav.setLevel !== 'function' || typeof nav.lvOf !== 'function') return fn();
    var prev = nav.lv; nav.setLevel(nav.lvOf(y));
    try { return fn(); } finally { nav.setLevel(prev); }
  }

  function snap(x, y, z) {   // punto transitable más cercano en la capa de ese piso
    var nav = G.nav, c = null;
    try { c = inLevel(y, function () { return nav.nearest(x, z, 6); }); } catch (e) { c = null; }
    return c ? { x: c.x, z: c.z } : null;
  }

  // ======================================================================== etiqueta con nombre y vida
  function makeLabel() {
    var cv = document.createElement('canvas'); cv.width = 256; cv.height = 72;
    var tex = new THREE.CanvasTexture(cv), mat = new THREE.SpriteMaterial({ map: tex, transparent: true, depthWrite: false, fog: false });
    var sp = new THREE.Sprite(mat); sp.scale.set(1.6, 0.45, 1); sp.renderOrder = 6; sp.userData = { cv: cv, tex: tex, key: '' };
    G.scene.add(sp); return sp;
  }
  function paintLabel(s) {
    var sp = s.label, ud = sp.userData, st = s.downed > 0 ? 'd' : s.recruited ? (s.mode === 'follow' ? 'f' : 's') : 'n';
    var key = st + '|' + Math.round(s.hp / s.maxHp * 20) + '|' + (s.near ? 1 : 0) + '|' + s.name;
    if (key === ud.key) return; ud.key = key;
    var g = ud.cv.getContext('2d'); g.clearRect(0, 0, 256, 72);
    g.font = 'bold 28px system-ui,sans-serif'; g.textAlign = 'center'; g.lineWidth = 5; g.strokeStyle = 'rgba(0,0,0,.85)';
    g.strokeText(s.name, 128, 28); g.fillStyle = st === 'd' ? '#ff8a80' : st === 'n' ? '#ffe9a8' : '#bff5c4'; g.fillText(s.name, 128, 28);
    g.font = '18px system-ui,sans-serif'; g.strokeStyle = 'rgba(0,0,0,.85)';
    var sub = st === 'n' ? (s.near ? (DIALOGOS ? 'Superviviente · E para hablar' : 'Superviviente · E para reclutar') : 'Superviviente') : st === 'd' ? 'Herida · hay que levantarla' : st === 'f' ? 'Te sigue' : 'Se queda aquí';
    g.strokeText(sub, 128, 50); g.fillStyle = '#e8e8e8'; g.fillText(sub, 128, 50);
    g.fillStyle = 'rgba(0,0,0,.65)'; g.fillRect(58, 58, 140, 8);
    var f = clamp(s.hp / s.maxHp, 0, 1); g.fillStyle = f > 0.5 ? '#6bd16f' : f > 0.25 ? '#e6b93d' : '#e0554d'; g.fillRect(59, 59, 138 * f, 6);
    ud.tex.needsUpdate = true;
  }

  // ======================================================================== el superviviente
  function Survivor(key, x, y, z, sv) {
    var P = VC.presets[key], A = P.ally; sv = sv || {};
    this.key = key; this.name = P.name; this.P = P; this.A = A; this.h = P.h;
    this.pos = { x: x, y: y, z: z }; this.yaw = sv.yaw != null ? sv.yaw : rnd() * T2;
    this.maxHp = A.hp; this.hp = sv.hp != null ? clamp(sv.hp, 1, A.hp) : A.hp;
    this.alive = true; this.downed = sv.dn > 0 ? sv.dn : 0; this.deadT = 0;
    this.recruited = !!sv.rec; this.mode = sv.mode === 'stay' ? 'stay' : 'follow'; this.owner = sv.owner || 'me';
    this.ammo = sv.ammo != null ? sv.ammo : A.ammo; this.mag = sv.mag != null ? sv.mag : 0; this.reloadT = 0; this.cool = 0;
    this.anchor = { x: sv.ax != null ? sv.ax : x, y: sv.ay != null ? sv.ay : y, z: sv.az != null ? sv.az : z };
    this.path = null; this.pi = 0; this.partial = false; this.repath = 0; this.pend = null; this.speedNow = 0; this.stuckT = 0; this.goal = null;
    this.target = null; this.giant = null; this.seeT = rnd() * 0.3; this.doorT = 0; this.aimT = 0; this.swingT = 0; this.flashT = 0; this.wid = A.gun;
    this.sinceHurt = 99; this.slot = 0; this.near = false; this.idleT = 0; this.lookDir = 1; this.cph = 0; this.lean = 0; this.t = 0;
    this.T = { name: P.name }; this.proxy = false;
    this.pl = { pos: this.pos, h: P.h, visibility: 0.6, moving: false, crouch: false, alive: true, _sv: this };
    this.model = G.buildChar(key); this.model.g.visible = true; this.model.g.position.set(x, y, z);
    this.label = makeLabel(); paintLabel(this);
  }
  // Se reutiliza la navegación y el movimiento de los infectados (A*, escaleras, colisiones con paredes y muebles)
  ['setPath', 'vertPath', 'follow', 'moveDir', 'face', 'groundSnap'].forEach(function (n) { Survivor.prototype[n] = Enemy.prototype[n]; });
  Survivor.prototype.die = function () { this.kill(); };

  Survivor.prototype.dispose = function () {
    var sc = G.scene; sc.remove(this.model.g); sc.remove(this.label);
    this.model.g.traverse(function (o) { if (o.geometry) o.geometry.dispose(); });
    if (this.label.material.map) this.label.material.map.dispose(); this.label.material.dispose();
  };

  Survivor.prototype.hurt = function (dmg, src) {
    if (!this.alive || this.downed > 0) return;
    this.hp -= dmg * 0.85; this.sinceHurt = 0; this.hurtFx = 0.35;
    if (this.hp <= 0) {
      this.hp = 0; this.downed = 40; this.target = null; this.aimT = 0; this.path = null;
      toast(this.name + ' está herida. Acércate y levántala con una venda antes de que se desangre.', 'warn', 5000);
    }
  };
  Survivor.prototype.kill = function () {
    if (!this.alive) return; this.alive = false; this.downed = 0; this.recruited = false; this.deadT = 0; this.pl.alive = false;
    toast(this.name + ' ha muerto.', 'warn', 5000);
    if (this.label) this.label.visible = false;
  };
  Survivor.prototype.revive = function (hpFrac) {
    this.downed = 0; this.hp = Math.max(this.hp, this.maxHp * hpFrac); this.sinceHurt = 0; this.stuckT = 0;
  };

  // ---- ejecuta fn con este superviviente como «jugador» (para que los infectados golpeados reaccionen hacia él)
  function asTarget(s, fn) {
    var rp = G.player, rm = G._mpTarget, rf = G.env.flashOn; G.player = s.pl; G._mpTarget = null; G.env.flashOn = false;
    try { return fn(); } finally { G.player = rp; G._mpTarget = rm; G.env.flashOn = rf; }
  }

  // ---- líder al que sigue (el jugador local; en cooperativo, quien lo reclutó)
  function leaderOf(s) {
    var m = mp();
    if (m && role() === 'host' && s.owner && s.owner !== 'me') {
      var r = m.remote && m.remote.get(s.owner);
      if (r && r.active && r.pos) return { x: r.pos.x, y: r.pos.y, z: r.pos.z, yaw: r.yaw || 0, v: r.speed || 0 };
    }
    if (G.ps && !G.ps.alive && G.state === 'dead') return null;
    var p = G.ctrl.pos; return { x: p.x, y: p.y, z: p.z, yaw: G.look.yaw, v: hyp(G.ctrl.vel.x, G.ctrl.vel.z) };
  }

  // ======================================================================== IA
  var WALK = 2.1, JOG = 3.9, RUN = 5.8;

  Survivor.prototype.moveTo = function (tx, tz, ty, speed, dt) {
    var g = this.goal;
    if (!g || hyp(g.x - tx, g.z - tz) > 1.8 || Math.abs((g.y || 0) - ty) > 1.5 || (!this.path && this.repath <= 0) || this.repath <= -1.5) {
      this.setPath(tx, tz, ty); this.goal = { x: tx, z: tz, y: ty };
    }
    var done = this.follow(dt, speed * this.A.speed);
    if (done && !this.pend) {   // llegó al final de la ruta (o no hay ruta): acércate en línea recta si falta poco
      var dx = tx - this.pos.x, dz = tz - this.pos.z, d = hyp(dx, dz);
      if (d > 0.9 && d < 6 && Math.abs(ty - this.pos.y) < 1.6) { this.moveDir(dx / d, dz / d, speed * this.A.speed * 0.8, dt); return false; }
      return true;
    }
    return false;
  };

  Survivor.prototype.pick = function () {
    var best = null, bd = 1e9, giant = null, near = 0, p = this.pos, eye = { x: p.x, y: p.y + 1.5, z: p.z }, L = G.dir.enemies;
    for (var i = 0; i < L.length; i++) {
      var e = L[i]; if (!e.alive || e.climb) continue;
      var dy = Math.abs(e.pos.y - p.y); if (dy > 3.4) continue;
      var d = hyp(e.pos.x - p.x, e.pos.z - p.z);
      if (e.isGiant) { if (d < 45 && dy < 6) giant = e; continue; }
      if (d > 26) continue;
      var hunting = e.state === 'chase' || e.state === 'investigate' || e.state === 'alert';
      if (!hunting && d > 11) continue;   // no despiertan a los infectados lejanos que no los han notado
      if (d < 6) near++;
      if (!G.lineClear(eye, { x: e.pos.x, y: e.pos.y + 1.2, z: e.pos.z }, G.boxes)) continue;
      var sc = d * (hunting ? 0.8 : 1.2); if (sc < bd) { bd = sc; best = e; }
    }
    this.target = best; this.giant = giant; this.nearCount = near;
  };

  Survivor.prototype.shoot = function (e) {
    var W = G.WEAPONS[this.A.gun]; if (!W) return;
    var p = this.pos, d = hyp(e.pos.x - p.x, e.pos.z - p.z);
    this.mag--; this.cool = (W.cd || 0.3) * (1.7 + rnd() * 0.9); this.aimT = 1.6; this.flashT = 0.07; this.wid = this.A.gun;
    var chance = clamp(this.A.acc * (1 - (d / W.range) * 0.75) * (this.speedNow > 1 ? 0.65 : 1), 0.1, 0.95), hit = rnd() < chance;
    var ox = p.x - Math.sin(this.yaw + Math.PI) * 0.45, oy = p.y + 1.35, oz = p.z - Math.cos(this.yaw + Math.PI) * 0.45;
    var tx = e.pos.x, ty = e.pos.y + 1.1, tz = e.pos.z;
    if (!hit) { tx += (rnd() - 0.5) * 2.2; ty += (rnd() - 0.5) * 1.2; tz += (rnd() - 0.5) * 2.2; }
    tracer(ox, oy, oz, tx, ty, tz);
    if (hit) {
      var head = rnd() < 0.13, dmg = W.dmg * (head ? (W.head || 2) : 1);
      asTarget(this, function () { e.hurt(dmg, { x: p.x, z: p.z }, false, W.kb); });
    }
    gunSound({ x: p.x, y: p.y + 1.4, z: p.z });
    try { G.noise(p.x, p.y + 1.2, p.z, (W.noise || 58) * 0.8, 'player', { threat: 0.8, tx: p.x, tz: p.z }); } catch (er) { /* nada */ }
  };

  Survivor.prototype.melee = function (e) {
    var M = G.WEAPONS.machete, p = this.pos; this.cool = 0.95 + rnd() * 0.35; this.swingT = 0.4; this.aimT = 0.8; this.wid = 'machete';
    var dmg = ((M && M.dmg) || 34) * 0.75;
    asTarget(this, function () { e.hurt(dmg, { x: p.x, z: p.z }, false, 0.6); });
    try { G.noise(p.x, p.y + 1, p.z, 14, 'player', { threat: 0.3, tx: p.x, tz: p.z }); } catch (er) { /* nada */ }
  };

  Survivor.prototype.openDoors = function () {
    var D = LEVEL.doors, p = this.pos;
    for (var i = 0; i < D.length; i++) {
      var d = D[i]; if (d.open || d.broken) continue;
      if (Math.abs((d.y0 || 0) + 0.1 - p.y) > 1.8) continue;
      if (hyp(d.cx - p.x, d.cz - p.z) < 1.5) { try { G.zombieDoor(d.id); } catch (e) { /* nada */ } }
    }
  };

  Survivor.prototype.teleportNear = function (L) {
    var a = L.yaw + Math.PI + (rnd() - 0.5) * 1.2, r = 3 + rnd() * 3, c = snap(L.x + Math.sin(a) * r, L.y, L.z + Math.cos(a) * r);
    if (!c) c = snap(L.x, L.y, L.z); if (!c) return;
    this.pos.x = c.x; this.pos.z = c.z; this.pos.y = L.y; this.path = null; this.goal = null; this.stuckT = 0; this.target = null;
  };

  Survivor.prototype.think = function (dt) {
    var A = this.A, W = G.WEAPONS[A.gun] || { mag: 12, reload: 1.4, range: 70 }, p = this.pos;
    this.cool -= dt; this.swingT = Math.max(0, this.swingT - dt); this.aimT = Math.max(0, this.aimT - dt); this.flashT = Math.max(0, this.flashT - dt);
    this.doorT -= dt; this.repath -= dt; this.sinceHurt += dt; this.hurtFx = Math.max(0, (this.hurtFx || 0) - dt);
    if (this.reloadT > 0) { this.reloadT -= dt; if (this.reloadT <= 0) { var n = Math.min(W.mag, this.ammo); this.mag = n; this.ammo -= n; } }
    this.speedNow = 0;
    this.groundSnap(dt);
    if (this.downed > 0) {
      this.downed -= dt; this.hp = Math.max(0.1, this.hp);
      if (this.downed <= 0) this.kill();
      return;
    }
    if (this.sinceHurt > 10 && this.hp < this.maxHp * 0.7) this.hp = Math.min(this.maxHp * 0.7, this.hp + 1.2 * dt);   // se recupera despacio si nadie la ataca
    var L = this.recruited ? leaderOf(this) : null;
    this.seeT -= dt; if (this.seeT <= 0) { this.seeT = 0.25 + rnd() * 0.1; this.pick(); }
    var e = this.target; if (e && !e.alive) e = this.target = null;
    this.pl.moving = false;
    // ---- miedo: el Gigante, o herida con enemigos encima
    var ed = e ? hyp(e.pos.x - p.x, e.pos.z - p.z) : 99;
    if (this.giant || (this.hp < this.maxHp * 0.3 && e && ed < 9)) {
      if (this.recruited && L) { if (this.moveTo(L.x, L.z, L.y, RUN, dt)) this.speedNow = 0; }
      else if (this.moveTo(this.anchor.x, this.anchor.z, this.anchor.y, RUN, dt)) this.speedNow = 0;
      this.aimT = 0; return;
    }
    // ---- combate
    if (e) {
      var dx = e.pos.x - p.x, dz = e.pos.z - p.z, d = ed, hasGun = (this.mag > 0 || this.ammo > 0) && !!G.WEAPONS[A.gun];
      var ang = Math.atan2(dx, dz), rangeMax = (W.range || 70) * 0.5;
      if (hasGun && d > 1.7 && d < rangeMax) {
        this.face(e.pos.x, e.pos.z, dt, 14); this.aimT = 1.3; this.wid = A.gun;
        if (this.mag <= 0) { if (this.reloadT <= 0) this.reloadT = W.reload || 1.4; }
        else if (this.cool <= 0 && Math.abs(wrapPi(this.yaw - ang)) < 0.22) this.shoot(e);
        if (d < 4.2) this.moveDir(-dx / d, -dz / d, WALK * 0.9 * A.speed, dt);   // da pasos atrás para ganar distancia
        return;
      }
      if (d <= 2.2) {
        this.face(e.pos.x, e.pos.z, dt, 14);
        if (this.cool <= 0 && Math.abs(wrapPi(this.yaw - ang)) < 0.5) this.melee(e);
        return;
      }
      if (!hasGun && d < 8 && (!this.recruited || this.mode === 'follow')) {   // sin balas: espera al infectado y lo recibe a machetazos
        this.face(e.pos.x, e.pos.z, dt, 10); this.aimT = 0.6; this.wid = 'machete';
        if (d < 5) this.moveDir(dx / d, dz / d, JOG * A.speed * 0.7, dt);
        return;
      }
    }
    // ---- sin enemigos a la vista
    if (this.doorT <= 0) { this.doorT = 0.3; if (this.recruited) this.openDoors(); }
    if (this.recruited && this.mode === 'follow' && L) { this.follow2(dt, L); return; }
    // reclutado en «quedarse» o sin reclutar: vuelve a su sitio si se alejó y, si hay alguien cerca, lo mira
    var da = hyp(this.anchor.x - p.x, this.anchor.z - p.z);
    if (da > 3.5 || Math.abs(this.anchor.y - p.y) > 1.5) { if (this.moveTo(this.anchor.x, this.anchor.z, this.anchor.y, WALK * 1.4, dt)) this.speedNow = 0; return; }
    var pp = G.ctrl.pos;
    if (hyp(pp.x - p.x, pp.z - p.z) < 7 && Math.abs(pp.y - p.y) < 2.5) this.face(pp.x, pp.z, dt, 3);
    else { this.idleT -= dt; if (this.idleT <= 0) { this.idleT = 2 + rnd() * 3; this.lookDir = rnd() < 0.5 ? 1 : -1; } this.yaw += this.lookDir * 0.25 * dt; }
  };

  Survivor.prototype.follow2 = function (dt, L) {
    var p = this.pos, d = hyp(L.x - p.x, L.z - p.z), dy = Math.abs(L.y - p.y);
    var side = this.slot ? 1.7 : -1.7, back = this.slot ? 3.1 : 2.4;
    var tx = L.x + Math.sin(L.yaw) * back + Math.cos(L.yaw) * side, ty = L.y, tz = L.z + Math.cos(L.yaw) * back - Math.sin(L.yaw) * side;
    if (d > 60 || (this.stuckT > 9 && d > 7) || dy > 12) { this.teleportNear(L); return; }
    if (d < 3.1 && dy < 1.6) {   // ya está junto al líder: se queda mirando hacia donde mira él
      this.stuckT = 0; this.yaw = turn(this.yaw, L.yaw + Math.PI + (this.slot ? 0.4 : -0.4), 1 - Math.exp(-3 * dt)); return;
    }
    var sp = d > 14 || L.v > 5.2 ? RUN : d > 6 || L.v > 2.8 ? JOG : WALK;
    var before = p.x * 1000 + p.z;
    this.moveTo(tx, tz, ty, sp, dt);
    this.pl.moving = true;
    if (this.speedNow < 0.3 && d > 5) this.stuckT += dt; else this.stuckT = Math.max(0, this.stuckT - dt * 2);
  };

  Survivor.prototype.update = function (dt) {
    if (!this.alive) { this.deadT += dt; animate(this, dt); return; }
    var self = this; inLevel(this.pos.y, function () { self.think(dt); });
    for (var i = 0; i < list.length; i++) {   // no se amontonan entre ellos
      var o = list[i]; if (o === this || !o.alive || Math.abs(o.pos.y - this.pos.y) > 1.5) continue;
      var ox = this.pos.x - o.pos.x, oz = this.pos.z - o.pos.z, od = hyp(ox, oz);
      if (od < 0.8) { var k = (0.8 - od) * 0.5 * Math.min(1, dt * 8), nx = od > 1e-3 ? ox / od : 1, nz = od > 1e-3 ? oz / od : 0; this.pos.x += nx * k; this.pos.z += nz * k; }
    }
    this.pl.visibility = this.speedNow > 3 ? 1 : this.speedNow > 0.4 ? 0.8 : 0.55; this.pl.moving = this.speedNow > 0.4;
    animate(this, dt);
  };

  // ======================================================================== animación (mismo esqueleto que el jugador)
  function animate(s, dt) {
    var m = s.model, ex = function (t) { return 1 - Math.exp(-t * dt); }, sp = s.speedNow, alive = s.alive && s.downed <= 0;
    s.t += dt;
    var gun = s.aimT > 0 && s.wid !== 'machete', spN = smooth(1, 6.5, sp), mv = smooth(0.15, 1.3, sp), A0 = lerp(0.32, 0.95, spN), A = A0 * mv, kb = lerp(0.65, 1.5, spN);
    var om = sp > 0.2 ? Math.min(22, Math.PI * sp / (2 * 0.9 * Math.sin(A0))) : 0;
    s.cph += om * dt; var si = Math.sin(s.cph), co = Math.cos(s.cph), hipY = 0;
    m.legs.forEach(function (L, i) {
      var sd = i ? -1 : 1, th = si * sd * A, kn = -Math.max(0, co * sd) * kb * mv;
      L.hip.rotation.x += (th - L.hip.rotation.x) * ex(32); L.kn.rotation.x += (kn - L.kn.rotation.x) * ex(32);
      hipY = Math.max(hipY, 0.45 * Math.cos(L.hip.rotation.x) + 0.45 * Math.cos(L.hip.rotation.x + L.kn.rotation.x));
    });
    s.lean += ((sp > 5 ? 0.2 : 0.07) * smooth(0.5, 3, sp) - s.lean) * ex(8);
    m.pel.position.y = hipY; m.pel.rotation.x = -s.lean;
    var sA = si * mv, sw = 0.3 + 0.35 * spN, aL = m.arms[0], aR = m.arms[1], br = Math.sin(s.t * 1.9) * (1 - mv), twist = 0;
    if (gun) { aL.sh.rotation.set(1.3, 0, 0.5); aL.el.rotation.x = 0.5; aR.sh.rotation.set(1.45, 0, -0.04); aR.el.rotation.x = 0.12; }
    else {
      aL.sh.rotation.set(-sA * sw * 1.3 + br * 0.03, 0, 0.06); aL.el.rotation.x = 0.15 + Math.abs(sA) * 0.25;
      if (s.swingT > 0) { var kk = 1 - s.swingT / 0.4, w = smooth(0, 0.25, kk), q = smooth(0.25, 0.7, kk); aR.sh.rotation.set(0.35 + 2.35 * w - 2.2 * q, 0, -0.08); aR.el.rotation.x = 0.8 - 0.5 * w + 0.5 * q; twist = 0.3 * w - 0.7 * q; }
      else { aR.sh.rotation.set(0.4 + sA * sw * 0.9, 0, -0.06); aR.el.rotation.x = 0.8; }
    }
    m.tor.rotation.y += (twist - si * 0.13 * mv * (gun ? 0.25 : 1) - m.tor.rotation.y) * ex(22);
    m.hd.rotation.x = -m.pel.rotation.x * 0.7;
    for (var n in m.pv) m.pv[n].visible = s.aimT > 0 && n === s.wid;
    m.flash.visible = s.flashT > 0; m.flash.position.z = -0.22;
    var kr = ex(10), tx = alive ? 0 : 1.45, ty = alive ? 0 : 0.22, tz = alive ? 0 : -0.85;
    if (!alive) { m.pel.rotation.x = 0; }
    m.rig.rotation.x += (tx - m.rig.rotation.x) * kr; m.rig.position.y += (ty - m.rig.position.y) * kr; m.rig.position.z += (tz - m.rig.position.z) * kr;
    m.rig.rotation.z = s.hurtFx > 0 ? Math.sin(s.hurtFx * 40) * 0.1 : 0;
    m.g.position.set(s.pos.x, s.pos.y, s.pos.z); m.g.rotation.y = s.yaw + Math.PI;
    var cam = G.camera.position, cd = hyp(cam.x - s.pos.x, cam.z - s.pos.z), vis = cd < 150;
    m.g.visible = vis; s.label.visible = vis && s.alive && cd < 28;
    if (s.alive) { s.label.position.set(s.pos.x, s.pos.y + s.h + 0.42, s.pos.z); paintLabel(s); }
  }

  // ======================================================================== disparos: trazador y sonido
  function tracer(x0, y0, z0, x1, y1, z1) {
    var geo = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(x0, y0, z0), new THREE.Vector3(x1, y1, z1)]);
    var line = new THREE.Line(geo, new THREE.LineBasicMaterial({ color: 0xffe08a, transparent: true, opacity: 0.85, fog: false }));
    G.scene.add(line); tracers.push({ line: line, t: 0.12 });
  }
  function gunSound(pos) {
    var a = G.audio;
    try {
      if (a && a.ctx) {
        a._noise({ type: 'bandpass', f: 1900, q: 0.8, dur: 0.12, gain: 0.5, attack: 0.001, pos: pos });
        a._tone({ f: 210, sweep: 60, dur: 0.16, gain: 0.45, type: 'triangle', pos: pos });
      }
    } catch (e) { /* sin audio */ }
  }

  // ======================================================================== los infectados los atacan
  function nearestSurvivorTarget(e) {
    var base = G.player, bd = hyp(base.pos.x - e.pos.x, base.pos.z - e.pos.z) + Math.abs(base.pos.y - e.pos.y) * 3, best = null;
    for (var i = 0; i < list.length; i++) {
      var s = list[i]; if (!s.alive || s.downed > 0 || s.proxy) continue;
      var d = hyp(s.pos.x - e.pos.x, s.pos.z - e.pos.z) + Math.abs(s.pos.y - e.pos.y) * 3;
      if (d < bd * 0.9) { bd = d; best = s; }
    }
    return best;
  }
  function wrapEnemy(e) {
    if (e._svw) return; e._svw = true;
    var orig = e.update;
    e.update = function (dt) {
      if (isGuest()) return orig.call(this, dt);
      var s = nearestSurvivorTarget(this);
      if (!s) return orig.call(this, dt);
      var rp = G.player, rm = G._mpTarget, rf = G.env.flashOn;
      G.player = s.pl; G._mpTarget = null; G.env.flashOn = false;
      try { return orig.call(this, dt); } finally { G.player = rp; G._mpTarget = rm; G.env.flashOn = rf; }
    };
  }
  var origHurtPlayer = G.hurtPlayer;
  G.hurtPlayer = function (dmg, e) {
    var p = G.player;
    if (p && p._sv) { p._sv.hurt(e && !e.noDiff ? dmg * (G.diff ? G.diff.dmg : 1) : dmg, e); return; }
    return origHurtPlayer.apply(this, arguments);
  };

  // ======================================================================== interacción
  function candidate() {
    if (G.state !== 'play' || G.veh) return null;
    var cam = G.camera.position, yaw = G.look.yaw, pit = G.look.pitch, cp = Math.cos(pit);
    var fx = -Math.sin(yaw) * cp, fy = Math.sin(pit), fz = -Math.cos(yaw) * cp, best = null, bs = 1e9;
    for (var i = 0; i < list.length; i++) {
      var s = list[i]; if (!s.alive) continue;
      var x = s.pos.x, y = s.pos.y + (s.downed > 0 ? 0.3 : 1.0), z = s.pos.z, dx = x - cam.x, dy = y - cam.y, dz = z - cam.z, d = Math.sqrt(dx * dx + dy * dy + dz * dz);
      if (d > 3.3) continue;
      var dot = (dx * fx + dy * fy + dz * fz) / (d || 1); if (dot < 0.55 && d > 1.1) continue;
      if (!G.lineClear({ x: cam.x, y: cam.y, z: cam.z }, { x: x, y: y, z: z }, G.boxes)) continue;
      var sc = d * (2 - dot); if (sc < bs) { bs = sc; best = s; }
    }
    return best;
  }
  function mine(s) { return s.alive && s.recruited && s.owner === 'me'; }
  function followers() { var n = 0; list.forEach(function (s) { if (mine(s) && s.downed <= 0) n++; }); return n; }

  // Diálogos de los NPC: DESACTIVADOS por ahora. Para volver a activarlos pon DIALOGOS = true.
  var DIALOGOS = false;
  var SAY = {
    wilmarys: ['«Ay, qué alivio ver a alguien vivo. Si te hieres, yo te vendo.»', '«Voy contigo. No soy fuerte, pero cuidar sí sé.»'],
    valentina: ['«Si vamos a sobrevivir, mejor juntos. Yo corro rápido… tú intenta seguirme el paso.»', '«Vale, voy contigo. Pero no me hagas cargar con nada pesado.»'],
    imbachi: ['«Soy Imbachi. Conozco este sitio. Te cubro la espalda.»', '«Vámonos antes de que nos huelan.»']
  };

  function recruit(s) {
    if (followers() >= MAXF) { toast('Ya te siguen ' + MAXF + ' supervivientes. Pídele a uno que se quede (E sobre él) para reclutar a otro.', 'warn', 4500); return; }
    if (isGuest()) { send('recruit', s); toast('Pidiendo a ' + s.name + ' que te acompañe…', '', 2000); return; }
    doRecruit(s, 'me');
  }
  function doRecruit(s, owner) {
    s.recruited = true; s.mode = 'follow'; s.owner = owner; s.slot = (list.filter(function (o) { return o !== s && o.alive && o.recruited && o.mode === 'follow'; }).length) % 2;
    s.anchor = { x: s.pos.x, y: s.pos.y, z: s.pos.z }; s.near = false; paintLabel(s);
    if (owner === 'me') { if (DIALOGOS) toast(s.name + ': ' + SAY[s.key][0], 'ok', 5500); else toast(s.name + ' se une a ti.', 'ok', 2500); showBtn(); }
  }

  function itemCount(id) { try { return G.ps.inv.count(id); } catch (e) { return 0; } }
  function takeItem(id, n) { try { G.ps.inv.remove(id, n); return true; } catch (e) { return false; } }

  function openPanel(s) {
    var W = G.WEAPONS[s.A.gun], ammoId = W && W.ammo, have = ammoId ? itemCount(ammoId) : 0, ITEMS = G.ITEMS || {};
    var an = ammoId && ITEMS[ammoId] ? ITEMS[ammoId].name : 'munición';
    var rows = [];
    rows.push({ name: s.mode === 'follow' ? 'Que se quede aquí' : 'Que me siga', desc: s.mode === 'follow' ? 'Se queda en este lugar y defiende la zona.' : 'Te acompaña, también por escaleras.', ok: true, label: s.mode === 'follow' ? 'Quedarse' : 'Seguir', ui: 'svcmd', a: 'toggle:' + s.key });
    rows.push({ name: 'Dar munición', desc: 'Tiene ' + (s.mag + s.ammo) + ' balas · tú llevas ' + have + ' de ' + an + '. Le das hasta 12.', ok: have > 0, why: 'No llevas munición compatible', label: 'Dar', ui: 'svcmd', a: 'ammo:' + s.key });
    var hurt = s.hp < s.maxHp - 1, med = itemCount('venda') + itemCount('botiquin') > 0;
    rows.push({ name: 'Curar', desc: 'Vida: ' + Math.round(s.hp) + ' / ' + s.maxHp + ' · gasta una venda o un botiquín.', ok: hurt && med, why: !hurt ? 'No está herida' : 'No llevas vendas ni botiquines', label: 'Curar', ui: 'svcmd', a: 'heal:' + s.key });
    rows.push({ name: 'Despedir', desc: 'Se queda donde está y deja de seguirte.', ok: true, label: 'Despedir', ui: 'svcmd', a: 'dismiss:' + s.key });
    G.ui.renderPanel(s.name.toUpperCase() + ' · ' + s.A.role, 'Superviviente' + (s.A.healer ? ' · te venda cuando estás herido' : s.key === 'valentina' ? ' · corre más rápido' : ' · muy buena puntería'), rows);
    G.ui.show('panel'); if (!G.coarse) try { G.input.unlock(); } catch (e) { /* nada */ }
    s._panel = true; panelFor = s;
  }
  var panelFor = null;

  function cmd(a) {
    var parts = String(a).split(':'), op = parts[0], key = parts[1], s = list.filter(function (o) { return o.key === key; })[0];
    if (!s || !s.alive) return;
    if (isGuest()) {
      var extra = {};
      if (op === 'ammo') { var Wg = G.WEAPONS[s.A.gun], idg = Wg && Wg.ammo, ng = Math.min(12, itemCount(idg)); if (ng <= 0 || !takeItem(idg, ng)) return; extra.n = ng; toast('Le diste ' + ng + ' balas a ' + s.name + '.', 'ok', 2200); }
      else if (op === 'heal') { var mg = itemCount('venda') > 0 ? 'venda' : itemCount('botiquin') > 0 ? 'botiquin' : null; if (!mg || !takeItem(mg, 1)) return; extra.m = mg; toast(s.name + ' está mejor.', 'ok', 2200); }
      send(op, s, extra);
      if (op === 'toggle') s.mode = s.mode === 'follow' ? 'stay' : 'follow';
      if (op === 'dismiss') { s.recruited = false; G.ui.hide('panel'); try { if (!G.coarse) G.input.lock(); } catch (e) { /* nada */ } showBtn(); return; }
      openPanel(s); showBtn(); return;
    }
    if (op === 'toggle') { s.mode = s.mode === 'follow' ? 'stay' : 'follow'; if (s.mode === 'stay') s.anchor = { x: s.pos.x, y: s.pos.y, z: s.pos.z }; toast(s.name + (s.mode === 'follow' ? ' te sigue.' : ' se queda aquí.'), '', 2200); }
    else if (op === 'ammo') {
      var W = G.WEAPONS[s.A.gun], id = W && W.ammo, n = Math.min(12, itemCount(id));
      if (n > 0 && takeItem(id, n)) { s.ammo += n; toast('Le diste ' + n + ' balas a ' + s.name + '.', 'ok', 2200); }
    } else if (op === 'heal') {
      var med = itemCount('botiquin') > 0 && s.hp < s.maxHp * 0.5 ? 'botiquin' : itemCount('venda') > 0 ? 'venda' : itemCount('botiquin') > 0 ? 'botiquin' : null;
      if (med && takeItem(med, 1)) { s.hp = Math.min(s.maxHp, s.hp + (med === 'botiquin' ? s.maxHp * 0.6 : s.maxHp * 0.3)); toast(s.name + ' está mejor.', 'ok', 2200); }
    } else if (op === 'dismiss') { s.recruited = false; s.mode = 'stay'; s.anchor = { x: s.pos.x, y: s.pos.y, z: s.pos.z }; toast(s.name + ' se queda aquí. Puedes volver a reclutarla.', '', 3000); }
    if (op === 'dismiss') { G.ui.hide('panel'); try { if (!G.coarse) G.input.lock(); } catch (e) { /* nada */ } showBtn(); }
    else openPanel(s);
    showBtn();
  }
  G.ui.handlers.svcmd = cmd;

  function reviveWith(s) {
    var med = itemCount('venda') > 0 ? 'venda' : itemCount('botiquin') > 0 ? 'botiquin' : null;
    if (!med) { toast('Necesitas una venda para levantar a ' + s.name + '.', 'warn', 3000); return; }
    if (isGuest()) { takeItem(med, 1); send('revive', s, { m: med }); return; }
    takeItem(med, 1); s.revive(med === 'botiquin' ? 0.6 : 0.35); toast(DIALOGOS ? s.name + ' se levanta: «Gracias… vamos.»' : s.name + ' se levanta.', 'ok', 3500);
  }

  window.VERT_SV = {
    prompt: function () {
      var s = candidate(); this._c = s; if (s && s.recruited && s.owner !== 'me') s = null;
      if (!s) { list.forEach(function (o) { o.near = false; }); return null; }
      list.forEach(function (o) { o.near = o === s; });
      var k = '<kbd>' + (G.coarse ? 'Usar' : 'E') + '</kbd>';
      if (s.downed > 0) return k + 'Levantar a ' + s.name + ' (1 venda) · ' + Math.ceil(s.downed) + ' s';
      if (!s.recruited) return k + (DIALOGOS ? 'Hablar con ' : 'Reclutar a ') + s.name;
      return k + 'Órdenes de ' + s.name;
    },
    use: function () {
      var s = candidate(); if (!s || G.sleeping || (s.recruited && s.owner !== 'me')) return false;
      if (s.downed > 0) reviveWith(s); else if (!s.recruited) recruit(s); else openPanel(s);
      return true;
    },
    list: list, toggleAll: toggleAll
  };

  function toggleAll() {
    var rec = list.filter(mine); if (!rec.length) { toast('No tienes supervivientes contigo.', '', 2000); return; }
    var follow = !rec.some(function (s) { return s.mode === 'follow'; });
    rec.forEach(function (s) { if (isGuest()) send(follow ? 'follow' : 'stay', s); s.mode = follow ? 'follow' : 'stay'; if (!follow) s.anchor = { x: s.pos.x, y: s.pos.y, z: s.pos.z }; });
    toast(follow ? 'Los supervivientes te siguen.' : 'Los supervivientes se quedan aquí.', '', 2200); showBtn();
  }

  // botón táctil 👥 (y tecla N)
  var btn = null;
  function ensureBtn() {
    if (btn) return btn;
    var st = document.createElement('style');
    st.textContent = '#svbtn{position:fixed;top:calc(54px + env(safe-area-inset-top,0px));right:calc(10px + env(safe-area-inset-right,0px));z-index:9;min-width:40px;height:40px;padding:0 10px;border-radius:20px;border:1px solid #ffffff44;background:#000a;color:#fff;font:600 15px system-ui,sans-serif}' +
      'body.touch #svbtn{min-width:var(--s,48px);height:var(--s,48px);font-size:calc(var(--s,48px) * .38);border-radius:calc(var(--s,48px) / 2)}#svbtn.hide{display:none}#svbtn small{display:block;font-size:10px;font-weight:400;opacity:.8;margin-top:-2px}';
    document.head.appendChild(st);
    btn = document.createElement('button'); btn.id = 'svbtn'; btn.className = 'hide'; btn.setAttribute('aria-label', 'Supervivientes: seguir o quedarse'); document.body.appendChild(btn);
    btn.addEventListener('click', function (e) { e.preventDefault(); toggleAll(); });
    return btn;
  }
  function showBtn() {
    var b = ensureBtn(), rec = list.filter(mine);
    if (!rec.length || G.state !== 'play') { b.classList.add('hide'); return; }
    var f = rec.some(function (s) { return s.mode === 'follow'; });
    b.innerHTML = '👥 ' + rec.length + '<small>' + (f ? 'siguen' : 'quietos') + '</small>'; b.classList.remove('hide');
  }
  document.addEventListener('keydown', function (ev) {
    if (ev.code !== 'KeyN' || ev.repeat || G.state !== 'play') return;
    if (['inv', 'loot', 'note', 'panel', 'chapter', 'selftest'].some(function (i) { try { return G.ui.visible(i); } catch (e) { return false; } })) return;
    toggleAll();
  }, true);

  // ======================================================================== Curandera (sin uso por ahora)
  function healerTick(dt) {
    nextHeal -= dt; if (nextHeal > 0) return;
    for (var i = 0; i < list.length; i++) {
      var s = list[i]; if (!s.alive || s.downed > 0 || !s.recruited || !s.A.healer || s.proxy) continue;
      var ps = G.ps, p = G.ctrl.pos; if (!ps || !ps.alive) continue;
      if ((ps.hp < 65 || ps.bleeding) && hyp(p.x - s.pos.x, p.z - s.pos.z) < 6 && Math.abs(p.y - s.pos.y) < 2.5 && !s.target) {
        ps.hp = Math.min(100, ps.hp + 22); ps.bleeding = false; nextHeal = 45; s.swingT = 0; s.sinceHurt = 0;
        toast(s.name + ' te venda la herida (+22 de vida).', 'ok', 3500); return;
      }
    }
    nextHeal = 2;
  }

  // ======================================================================== puesta en escena, guardado y bucle
  function spawnAll(saved) {
    var S = spots(), skip = G.Chars && G.Chars.id, byKey = {};
    if (saved && saved.list && saved.map === LEVEL.version) saved.list.forEach(function (o) { if (o && o.k) byKey[o.k] = o; });
    KEYS.forEach(function (k) {
      if (k === skip) return;   // el personaje que juegas no aparece también como superviviente
      var sv = byKey[k]; if (sv && sv.dead) return;
      var sp = S[k], x = sp.x, y = sp.y, z = sp.z, o = null;
      if (sv && isFinite(+sv.x + +sv.y + +sv.z)) { x = +sv.x; y = +sv.y; z = +sv.z; o = sv; }
      else { var c = snap(sp.x, sp.y, sp.z); if (c) { x = c.x; z = c.z; } y = groundY(x, z, sp.y); }
      var s = new Survivor(k, x, y, z, o ? { hp: o.hp, rec: o.rec, mode: o.mode, ammo: o.ammo, mag: o.mag, dn: o.dn, ax: o.ax, ay: o.ay, az: o.az, owner: o.owner } : null);
      s.slot = list.length % 2; list.push(s);
    });
    showBtn();
  }
  function clearAll() {
    list.forEach(function (s) { try { s.dispose(); } catch (e) { /* nada */ } }); list.length = 0;
    tracers.forEach(function (t) { G.scene.remove(t.line); t.line.geometry.dispose(); t.line.material.dispose(); }); tracers.length = 0;
    if (btn) btn.classList.add('hide');
  }
  function serialize() {
    return list.filter(function (s) { return !s.proxy; }).map(function (s) {
      return { k: s.key, x: +s.pos.x.toFixed(2), y: +s.pos.y.toFixed(2), z: +s.pos.z.toFixed(2), hp: Math.round(s.hp), rec: s.recruited ? 1 : 0, mode: s.mode, ammo: s.ammo, mag: s.mag,
        dead: s.alive ? 0 : 1, dn: s.downed > 0 ? Math.round(s.downed) : 0, ax: +s.anchor.x.toFixed(1), ay: +s.anchor.y.toFixed(2), az: +s.anchor.z.toFixed(1), owner: s.owner };
    });
  }
  if (G.SaveSys) {
    var os = G.SaveSys.save, ol = G.SaveSys.load;
    G.SaveSys.save = function (d) { try { if (started && d && typeof d === 'object') d.sv = { map: LEVEL.version, list: serialize() }; } catch (e) { /* nada */ } return os.call(this, d); };
    G.SaveSys.load = function () { var r = ol.call(this); pending = r && r.ok && r.data && r.data.sv ? r.data.sv : null; return r; };
  }

  function loop(now) {
    requestAnimationFrame(loop);
    var dt = Math.min((now - last) / 1000, 0.1); last = now;
    try {
      var st = G.state;
      if (!started && st === 'play') { started = true; if (!isGuest()) spawnAll(G.loaded ? pending : null); pending = null; }
      else if (started && st === 'menu') { started = false; clearAll(); }
      if (!started) return;
      if (!netBound) bindNet();
      if (role() === 'host') { for (var q = 0; q < list.length; q++) list[q].proxy = false; if (now - lastSnap > 150) { lastSnap = now; sendSnap(); } }
      var en = G.dir.enemies; for (var i = 0; i < en.length; i++) if (!en[i]._svw) wrapEnemy(en[i]);
      if (st === 'play' || st === 'dead') {
        for (var j = 0; j < list.length; j++) { if (list[j].proxy) { if (list[j].alive) proxyUpdate(list[j], dt); else animate(list[j], dt), list[j].deadT += dt; } else list[j].update(dt); }
        healerTick(dt);
        for (var k = list.length - 1; k >= 0; k--) { var s = list[k]; if (!s.alive && s.deadT > 45) { s.dispose(); list.splice(k, 1); } }
        if ((now | 0) % 8 === 0) showBtn();
      }
      for (var t = tracers.length - 1; t >= 0; t--) {
        var tr = tracers[t]; tr.t -= dt; tr.line.material.opacity = Math.max(0, tr.t / 0.12) * 0.85;
        if (tr.t <= 0) { G.scene.remove(tr.line); tr.line.geometry.dispose(); tr.line.material.dispose(); tracers.splice(t, 1); }
      }
      if (G.state !== 'play') { var b = btn; if (b) b.classList.add('hide'); }
    } catch (err) { if (!warned) { warned = true; console.error('[supervivientes]', err); } }
  }

  // ---- cooperativo: envío de órdenes del invitado al anfitrión (la parte de red está en vertice-mp.js)
  function nxc() { var m = mp(); return m && m.nx; }
  function hostId() { var n = nxc(); if (!n) return null; var h = n.players.filter(function (p) { return p.host; })[0]; return h ? h.id : null; }
  function send(op, s, extra) {
    var n = nxc(), h = hostId(); if (!n || !h) return;
    try { n.send('svu', Object.assign({ op: op, k: s.key }, extra || {}), { to: h }); } catch (e) { /* nada */ }
  }
  function byKey(k) { for (var i = 0; i < list.length; i++) if (list[i].key === k) return list[i]; return null; }

  // anfitrión: atiende las órdenes de los invitados
  function onOrder(d, from) {
    if (!d || typeof d.op !== 'string') return;
    var s = byKey(String(d.k)); if (!s || !s.alive || s.proxy) return; var op = d.op;
    if (op === 'recruit') {
      if (s.downed > 0 || s.recruited) return;
      var n = 0; list.forEach(function (o) { if (o.alive && o.recruited && o.owner === from) n++; });
      if (n >= MAXF) return; doRecruit(s, from); return;
    }
    if (op === 'revive') { if (s.downed > 0) s.revive(d.m === 'botiquin' ? 0.6 : 0.35); return; }
    if (!s.recruited || s.owner !== from) return;
    if (op === 'follow' || op === 'stay' || op === 'toggle') {
      s.mode = op === 'toggle' ? (s.mode === 'follow' ? 'stay' : 'follow') : op; if (s.mode === 'stay') s.anchor = { x: s.pos.x, y: s.pos.y, z: s.pos.z };
    } else if (op === 'dismiss') { s.recruited = false; s.mode = 'stay'; s.owner = 'me'; s.anchor = { x: s.pos.x, y: s.pos.y, z: s.pos.z }; }
    else if (op === 'ammo') s.ammo += clamp(d.n | 0, 0, 12);
    else if (op === 'heal') s.hp = Math.min(s.maxHp, s.hp + (d.m === 'botiquin' ? s.maxHp * 0.6 : s.maxHp * 0.3));
  }

  // anfitrión → invitados: estado de los supervivientes (≈7 veces por segundo)
  var r1 = function (v) { return Math.round(v * 10) / 10; }, r2 = function (v) { return Math.round(v * 100) / 100; };
  function sendSnap() {
    var n = nxc(), m = mp(); if (!n || !n.connected || !m || !m.remote || m.remote.size === 0 || !n.me) return;
    var out = list.filter(function (s) { return !s.proxy; }).map(function (s) {
      var fl = (s.alive ? 1 : 0) | (s.downed > 0 ? 2 : 0) | (s.recruited ? 4 : 0) | (s.mode === 'follow' ? 8 : 0) | (s.aimT > 0 ? 16 : 0) | (s.swingT > 0.2 ? 32 : 0) | (s.flashT > 0 ? 64 : 0);
      return [s.key, r1(s.pos.x), r2(s.pos.y), r1(s.pos.z), r2(s.yaw), Math.round(s.hp), fl, r1(s.speedNow), s.owner === 'me' ? n.me.id : s.owner, Math.round(s.downed), s.wid].join('|');
    });
    try { n.send('sv', { l: out.join(';') }); } catch (e) { /* nada */ }
  }
  // invitado: crea / actualiza las copias
  function applySnap(d) {
    var n = nxc(); if (!d || typeof d.l !== 'string' || !n || !n.me) return;
    d.l.split(';').slice(0, 6).forEach(function (row) {
      var a = row.split('|'); if (a.length < 11 || KEYS.indexOf(a[0]) < 0) return;
      var x = +a[1], y = +a[2], z = +a[3]; if (!isFinite(x + y + z)) return;
      var s = byKey(a[0]);
      if (!s) { if (G.state !== 'play') return; s = new Survivor(a[0], x, y, z, {}); s.proxy = true; s.netSpeed = 0; list.push(s); }
      if (!s.proxy) return;
      var fl = +a[6], was = s.recruited, owner = a[8] === n.me.id ? 'me' : a[8];
      s.tx = x; s.ty = y; s.tz = z; s.tyaw = +a[4]; s.hp = +a[5]; s.netSpeed = +a[7]; s.downed = (fl & 2) ? Math.max(1, +a[9]) : 0;
      s.recruited = !!(fl & 4); s.mode = (fl & 8) ? 'follow' : 'stay'; s.owner = owner; s.wid = a[10] || s.wid;
      if (fl & 16) s.aimT = 0.4; if ((fl & 32) && s.swingT <= 0) s.swingT = 0.4; if (fl & 64) s.flashT = 0.07;
      if (!(fl & 1) && s.alive) s.kill();
      if (s.recruited && !was && owner === 'me') { if (DIALOGOS) toast(s.name + ': ' + SAY[s.key][0], 'ok', 5000); else toast(s.name + ' se une a ti.', 'ok', 2500); showBtn(); }
      if (!s.recruited && was) showBtn();
    });
  }
  function proxyUpdate(s, dt) {
    if (s.tx == null) return;
    var k = 1 - Math.exp(-12 * dt);
    if (hyp(s.tx - s.pos.x, s.tz - s.pos.z) > 8 || Math.abs(s.ty - s.pos.y) > 3) { s.pos.x = s.tx; s.pos.y = s.ty; s.pos.z = s.tz; }
    else { s.pos.x += (s.tx - s.pos.x) * k; s.pos.y += (s.ty - s.pos.y) * k; s.pos.z += (s.tz - s.pos.z) * k; }
    s.yaw = turn(s.yaw, s.tyaw, k); s.speedNow = s.netSpeed; s.aimT = Math.max(0, s.aimT - dt); s.swingT = Math.max(0, s.swingT - dt); s.flashT = Math.max(0, s.flashT - dt);
    animate(s, dt);
  }
  var netBound = false, lastSnap = 0;
  function bindNet() {
    var n = nxc(); if (!n || netBound) return; netBound = true;
    n.on('event:svu', function (d, from) { if (role() === 'host') onOrder(d, from); });
    n.on('event:sv', function (d) { if (role() === 'guest') applySnap(d); });
  }

  window.VERT_SV.api = { sendSnap: sendSnap, applySnap: applySnap, onOrder: onOrder, list: list, spawnAll: spawnAll, clearAll: clearAll, doRecruit: doRecruit, Survivor: Survivor, serialize: serialize };
  requestAnimationFrame(loop);
})();
