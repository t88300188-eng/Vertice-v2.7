/*!
 * VÉRTICE · Menú principal y pantallas con estética postapocalíptica (menu-ui.js, v2.2)
 *
 * Se carga AL FINAL de index.html y historia.html. No cambia la lógica del juego: reutiliza los botones data-ui, los selectores
 * y el selector de personajes que ya existen, los reubica y les da otra cara:
 *   · menú principal: Continuar · Nueva partida · Multijugador · Selección de personaje · Configuración · Créditos · Salir
 *   · selección de personaje en tarjetas (altura, peso, atributo, colores)
 *   · fondo de ciudad en ruinas dibujado por código (sin imágenes externas)
 * Para quitarlo: borra la línea <script src="menu-ui.js"> y el juego vuelve al menú anterior.
 */
(function () {
  'use strict';
  var menu = document.getElementById('menu');
  if (!menu || menu.getAttribute('data-vx')) return;
  var orig = menu.querySelector('.card');
  if (!orig) return;
  menu.setAttribute('data-vx', '1');

  var G = window.VERTICE || {};
  var linkOther = orig.querySelector('a.btn[href]');           // enlace al otro modo (libre <-> historia)
  var STORY = !!(linkOther && /index\.html/.test(linkOther.getAttribute('href')));
  var $ = function (id) { return document.getElementById(id); };
  var el = function (tag, cls, html) { var e = document.createElement(tag); if (cls) e.className = cls; if (html != null) e.innerHTML = html; return e; };

  // ------------------------------------------------------------------ estilos
  var css = [
    ':root{--vx-red:#d6342b;--vx-red2:#7a1a16;--vx-ink:#cfd2d6;--vx-mut:#7e848b;--vx-line:#ffffff2b;--vx-grn:#8fae4a;--vx-font:"Bahnschrift","Oswald","Barlow Condensed","Roboto Condensed",sans-serif-condensed,"Arial Narrow","Segoe UI",system-ui,sans-serif}',
    '#menu.vx{padding:0;background:#050607;display:block;overflow:hidden;font-family:var(--vx-font);letter-spacing:.04em}',
    '#menu.vx>.card{display:none}',
    '#vxBg{position:absolute;inset:0;width:100%;height:100%;display:block}',
    '.vxL{position:absolute;left:0;top:0;bottom:calc(96px + env(safe-area-inset-bottom,0px));width:min(520px,52vw);padding:calc(14px + env(safe-area-inset-top,0px)) 20px calc(12px + env(safe-area-inset-bottom,0px)) calc(22px + env(safe-area-inset-left,0px));display:flex;flex-direction:column;background:linear-gradient(90deg,#050607f2 0%,#050607d9 62%,#05060700 100%);z-index:2}',
    '.vxLogo{flex:0 0 auto;height:clamp(64px,19vh,150px);margin-bottom:clamp(6px,2vh,18px);position:relative}',
    '.vxLogo svg{height:100%;width:auto;max-width:100%;display:block;overflow:visible}',
    '.vxList{flex:1 1 auto;min-height:0;display:flex;flex-direction:column;gap:clamp(4px,1.2vh,10px);overflow:auto;padding-right:2px;touch-action:pan-y}',
    '.vxB{flex:0 0 auto;display:flex;align-items:center;width:100%;height:clamp(34px,7.4vh,54px);padding:0;border:1px solid var(--vx-line);background:linear-gradient(180deg,#14161a,#0b0c0e);color:var(--vx-ink);border-radius:2px;text-align:left;text-transform:uppercase;font:600 clamp(13px,2.5vh,19px)/1 var(--vx-font);letter-spacing:.09em;position:relative;cursor:pointer;touch-action:manipulation;text-decoration:none;box-shadow:inset 0 1px 0 #ffffff0d,0 2px 6px #0008}',
    '.vxB .ic{flex:0 0 clamp(44px,9vh,68px);height:100%;display:flex;align-items:center;justify-content:center;color:#aab0b7;border-right:1px solid var(--vx-line);margin-right:clamp(12px,2.6vh,22px)}',
    '.vxB .ic svg{width:clamp(20px,4.2vh,30px);height:clamp(20px,4.2vh,30px);fill:none;stroke:currentColor;stroke-width:1.7;stroke-linecap:round;stroke-linejoin:round}',
    '.vxB:hover,.vxB:focus-visible{border-color:#ffffff55;background:linear-gradient(180deg,#1b1e23,#101114);color:#fff;outline:none}',
    '.vxB:active{transform:translateY(1px)}',
    '.vxB.dis{opacity:.42;pointer-events:none}',
    '.vxB.red{border-color:var(--vx-red);color:#c8a9a6;box-shadow:0 0 0 1px #d6342b44,0 0 16px #d6342b33,inset 0 0 18px #d6342b1f}',
    '.vxB.red .ic{color:#c9847f;border-right-color:#d6342b66}',
    '.vxB.red:hover{color:#fff;box-shadow:0 0 0 1px #d6342b99,0 0 22px #d6342b66,inset 0 0 24px #d6342b33}',
    '.vxB small{display:block;font-weight:400;font-size:.62em;color:var(--vx-mut);letter-spacing:.06em;margin-top:3px;text-transform:none}',
    '.vxB .tx{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
    '.vxB.tall{height:auto;min-height:clamp(52px,11vh,76px);padding:6px 0}',
    '.vxB.tall .tx{white-space:normal}',
    '.vxStatus{position:absolute;left:calc(22px + env(safe-area-inset-left,0px));bottom:calc(12px + env(safe-area-inset-bottom,0px));z-index:3;border:1px solid var(--vx-line);background:#0a0b0dd9;padding:7px 12px;font:600 clamp(10px,1.9vh,13px)/1.9 var(--vx-font);letter-spacing:.12em;text-transform:uppercase;color:#aeb3b9;max-width:340px}',
    '.vxStatus div{display:flex;align-items:center;gap:8px}',
    '.vxStatus i{width:7px;height:7px;border-radius:50%;background:var(--vx-grn);box-shadow:0 0 6px var(--vx-grn);flex:none}',
    '.vxStatus b{font-weight:700;margin-left:6px}.vxStatus .off{color:#e04a3e}.vxStatus .on{color:#8fd16b}.vxStatus .md{color:#9bb35c}',
    '.vxStatus u{display:inline-block;width:44px;height:3px;background:#8fae4a;margin-left:14px;text-decoration:none}',
    '.vxVer{position:absolute;right:12px;bottom:6px;font:11px var(--vx-font);color:#5c6269;z-index:3;letter-spacing:.1em}',
    /* subpaneles */
    '.vxH{font:700 clamp(15px,3vh,22px)/1.1 var(--vx-font);letter-spacing:.18em;text-transform:uppercase;color:#e4e6e9;margin:0 0 clamp(6px,1.6vh,12px);display:flex;align-items:center;gap:10px}',
    '.vxH:after{content:"";flex:1;height:1px;background:linear-gradient(90deg,var(--vx-red),#0000)}',
    '.vxP{font:400 clamp(12px,2.2vh,14px)/1.5 var(--vx-font);color:#9aa0a7;letter-spacing:.03em;margin:4px 0 8px}',
    '.vxBox{border:1px solid var(--vx-line);background:#0a0b0dcc;padding:10px 12px;margin:6px 0}',
    '.vxBox h4{margin:0 0 4px;font:700 12px var(--vx-font);letter-spacing:.14em;color:#d8dade;text-transform:uppercase}',
    '.vxRow{display:flex;align-items:center;gap:10px;margin:7px 0;font:600 12px var(--vx-font);letter-spacing:.1em;text-transform:uppercase;color:#a2a8af}',
    '.vxRow label{flex:0 0 clamp(96px,30%,150px)}',
    '.vxRow select,.vxRow input[type=range]{flex:1;min-width:0}',
    '.vxRow select{background:#0f1114;color:#dfe2e6;border:1px solid var(--vx-line);border-radius:2px;padding:6px 8px;font:inherit;text-transform:none;letter-spacing:.03em}',
    '.vxRow input[type=range]{accent-color:var(--vx-red)}',
    '.vxKeys{display:grid;grid-template-columns:auto 1fr;gap:4px 12px;font:400 12px/1.4 var(--vx-font);color:#8a9097;letter-spacing:.02em}.vxKeys b{color:#d3d6da;font-weight:600}',
    '.vxBack{margin-top:clamp(6px,1.6vh,12px);flex:0 0 auto}',
    '.vxScroll{flex:1 1 auto;min-height:0;overflow:auto;touch-action:pan-y;padding-right:4px}',
    '.vxSkin{margin-top:8px}.vxSkin .mpskin{margin:6px 0!important;font:600 12px var(--vx-font)!important;letter-spacing:.08em;text-transform:uppercase;color:#a2a8af!important}',
    /* selección de personaje */
    '#vxChar{position:absolute;inset:0;z-index:5;display:none;flex-direction:column;align-items:center;background:radial-gradient(ellipse at 50% 0%,#1a1c20 0%,#0b0c0e 55%,#060607 100%);overflow:hidden}',
    '#vxChar.on{display:flex}',
    '#vxChar canvas{position:absolute;inset:0;width:100%;height:100%;opacity:.45;pointer-events:none}',
    '.vxCT{position:relative;margin:clamp(8px,3.4vh,34px) 0 clamp(8px,3vh,30px);font:300 clamp(30px,9vh,76px)/1 var(--vx-font);letter-spacing:.34em;padding-left:.34em;color:#d9dbde;text-transform:uppercase;text-shadow:0 0 22px #0009}',
    '.vxCT:before{content:"";position:absolute;left:50%;top:-6px;width:.2em;height:.12em;margin-left:-.06em}',
    '.vxCards{position:relative;flex:1 1 auto;min-height:0;width:min(1180px,96vw);overflow:auto;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:clamp(8px,1.8vw,22px);padding:6px 4px 10px;align-content:start;touch-action:pan-y}',
    '.vxCard{position:relative;text-align:left;border:1px solid var(--vx-line);background:linear-gradient(180deg,#14161a,#0d0e11);border-radius:5px;padding:clamp(10px,2.4vh,20px) clamp(12px,1.6vw,22px) clamp(8px,2vh,16px);color:#dfe2e6;min-width:0;transition:border-color .15s,box-shadow .15s,transform .15s;cursor:pointer;touch-action:manipulation}',
    '.vxCard:hover{border-color:#ffffff59}',
    '.vxCard.on{border-color:var(--vx-red);box-shadow:0 0 0 1px #d6342b55,0 0 26px #d6342b44,inset 0 0 30px #d6342b18}',
    '.vxCard:before{content:"";position:absolute;right:12px;top:14px;width:1px;height:calc(50% - 18px);background:#ffffff40}',
    '.vxCard h3{margin:0;font:600 clamp(17px,3.4vh,27px)/1.15 var(--vx-font);letter-spacing:.03em;padding-right:22px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
    '.vxCard .rl{font:400 clamp(11px,2.2vh,16px)/1.3 var(--vx-font);color:#8c9299;margin-top:3px;padding-right:22px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
    '.vxCard hr{border:0;border-top:1px solid #ffffff2e;margin:clamp(8px,1.8vh,14px) 0 clamp(6px,1.4vh,10px)}',
    '.vxCard .st{display:flex;gap:10px;align-items:baseline;font:400 clamp(11px,2vh,14px)/1.7 var(--vx-font);color:#7f858c;text-transform:uppercase;letter-spacing:.06em}',
    '.vxCard .st b{font-weight:500;color:#e2e4e7;font-size:1.18em;text-transform:none;letter-spacing:.02em}',
    '.vxCard .ft{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:clamp(2px,.6vh,6px)}',
    '.vxCard .at{font:400 clamp(11px,2vh,14px)/1.4 var(--vx-font);color:#7f858c;text-transform:uppercase;letter-spacing:.06em}.vxCard .at b{font-weight:500;color:#e2e4e7;margin-left:8px}',
    '.vxCard .dots{display:flex;gap:7px;flex:none}.vxCard .dots i{width:clamp(16px,3.2vh,24px);height:clamp(16px,3.2vh,24px);border-radius:50%;border:1px solid #ffffff40;display:block}',
    '.vxCBar{position:relative;display:flex;gap:12px;align-items:center;justify-content:center;flex-wrap:wrap;width:min(1180px,96vw);padding:8px 0 calc(10px + env(safe-area-inset-bottom,0px))}',
    '.vxCBar .vxB{width:auto;min-width:min(240px,44vw);justify-content:center;padding:0 22px}',
    '.vxCBar .vxB .tx{text-align:center}',
    '.vxName{display:flex;align-items:center;gap:8px;font:600 12px var(--vx-font);letter-spacing:.12em;color:#9aa0a7;text-transform:uppercase}',
    '.vxName input{background:#0f1114;color:#e4e6e9;border:1px solid var(--vx-line);border-radius:2px;padding:8px 10px;font:500 14px var(--vx-font);width:min(190px,40vw);user-select:text;-webkit-user-select:text;touch-action:auto}',
    '#vxChar .vxSkin{position:relative}',
    '@media (max-height:520px){.vxStatus{left:auto;right:calc(12px + env(safe-area-inset-right,0px));bottom:24px;max-width:260px}.vxVer{font-size:9px}.vxLogo{height:46px;margin-bottom:6px}.vxB{height:31px}.vxB .ic{flex-basis:38px}.vxB .ic svg{width:17px;height:17px}.vxL.sub .vxLogo{display:none}.vxL.sub{width:min(560px,68vw)}.vxL{bottom:0}}',
    '@media (max-width:760px){.vxCards{grid-template-columns:repeat(2,minmax(0,1fr))}.vxL{width:min(520px,74vw)}}',
    '@media (max-width:520px){.vxCards{grid-template-columns:minmax(0,1fr)}.vxL{width:100vw}}',
    '@media (max-height:430px){.vxCards{grid-template-columns:repeat(3,minmax(0,1fr))}.vxCard hr{margin:6px 0 4px}}',
    '@media (max-height:430px) and (max-width:700px){.vxCards{grid-template-columns:repeat(2,minmax(0,1fr))}}',
    /* resto de pantallas del juego con la misma estética */
    '.screen:not(#menu){background:#050607e6}',
    '.screen .card{background:linear-gradient(180deg,#121417f5,#0a0b0df5);border:1px solid #ffffff26;border-radius:3px;box-shadow:0 10px 40px #000a;font-family:var(--vx-font)}',
    '.screen .card h1{font-weight:300;letter-spacing:.34em;text-transform:uppercase}',
    '.screen .card h2{font-weight:700;letter-spacing:.16em;text-transform:uppercase;font-size:17px}',
    '.screen .btn{border-radius:2px;text-transform:uppercase;letter-spacing:.1em;font-weight:600;font-size:14px;background:linear-gradient(180deg,#14161a,#0b0c0e);border-color:#ffffff2b;color:#d6d9dd}',
    '.screen .btn:hover{border-color:#ffffff59;background:linear-gradient(180deg,#1b1e23,#101114)}',
    '.screen .btn.pri{border-color:var(--vx-red);color:#fff;background:linear-gradient(180deg,#5a1713,#2c0c0a);box-shadow:0 0 14px #d6342b33}',
    '.screen .btn.pri:hover{background:linear-gradient(180deg,#7a1f19,#3a100d)}',
    '.screen .btn.sm{letter-spacing:.06em;font-size:12px}',
    '.chars .chc{border-radius:3px;background:linear-gradient(180deg,#14161a,#0d0e11);border-color:#ffffff2b;font-family:var(--vx-font)}',
    '.chars .chc.on{border-color:var(--vx-red);box-shadow:0 0 14px #d6342b44;background:#d6342b18}',
    '.chars .chc b{letter-spacing:.04em}'
  ].join('\n');
  var st = el('style'); st.textContent = css; document.head.appendChild(st);

  // ------------------------------------------------------------------ iconos
  var IC = {
    home: '<svg viewBox="0 0 24 24"><path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 10v10h13V10"/><path d="M10 20v-6h4v6"/></svg>',
    tools: '<svg viewBox="0 0 24 24"><path d="m4 20 9-9"/><path d="M13.5 5.5 18 3l3 3-2.5 4.5-3-1.5z"/><path d="m20 20-9-9"/><path d="M10.5 5.5 6 3 3 6l2.5 4.5 3-1.5z"/></svg>',
    people: '<svg viewBox="0 0 24 24"><circle cx="8" cy="8" r="2.8"/><circle cx="16.5" cy="8.8" r="2.4"/><path d="M2.5 19c0-3.4 2.4-5.6 5.5-5.6s5.5 2.2 5.5 5.6z"/><path d="M14.5 14c3-.5 7 .6 7 5h-5"/></svg>',
    helmet: '<svg viewBox="0 0 24 24"><path d="M4 14a8 8 0 0 1 16 0v2H4z"/><path d="M4 14h16"/><path d="M8 20h8"/><path d="M12 6v4"/></svg>',
    gear: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="3.2"/><path d="M12 2.8v3M12 18.2v3M2.8 12h3M18.2 12h3M5.5 5.5l2.1 2.1M16.4 16.4l2.1 2.1M18.5 5.5l-2.1 2.1M7.6 16.4l-2.1 2.1"/></svg>',
    book: '<svg viewBox="0 0 24 24"><path d="M3 5.5c3-1.2 6-1.2 9 .8 3-2 6-2 9-.8V19c-3-1.2-6-1.2-9 .8-3-2-6-2-9-.8z"/><path d="M12 6.3v13.5"/></svg>',
    door: '<svg viewBox="0 0 24 24"><path d="M6 21V4.5L17 3v18"/><path d="M4 21h16"/><circle cx="14" cy="12.5" r=".8"/></svg>',
    back: '<svg viewBox="0 0 24 24"><path d="M15 5 8 12l7 7"/></svg>',
    play: '<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>',
    tree: '<svg viewBox="0 0 24 24"><path d="M12 3 6 12h3l-3.5 5H11v4h2v-4h5.5L15 12h3z"/></svg>',
    tower: '<svg viewBox="0 0 24 24"><path d="M7 21V8l5-4 5 4v13"/><path d="M10 12h1M13 12h1M10 16h1M13 16h1"/></svg>',
    ok: '<svg viewBox="0 0 24 24"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg>'
  };
  var btn = function (icon, label, opts) {
    opts = opts || {};
    var b = el(opts.href ? 'a' : 'button', 'vxB' + (opts.red ? ' red' : '') + (opts.tall ? ' tall' : ''));
    if (!opts.href) b.type = 'button'; else b.href = opts.href;
    b.innerHTML = '<span class="ic">' + (IC[icon] || '') + '</span><span class="tx">' + label + (opts.sub ? '<small>' + opts.sub + '</small>' : '') + '</span>';
    if (opts.ui) { b.setAttribute('data-ui', opts.ui); }
    if (opts.on) b.addEventListener('click', opts.on);
    return b;
  };

  // ------------------------------------------------------------------ estructura
  menu.classList.add('vx');
  var bg = el('canvas'); bg.id = 'vxBg'; menu.appendChild(bg);

  // logo SVG (grietas con turbulencia)
  var logo = el('div', 'vxLogo');
  logo.innerHTML = '<svg viewBox="0 0 520 150" xmlns="http://www.w3.org/2000/svg" aria-label="VÉRTICE">' +
    '<defs><filter id="vxCr" x="-5%" y="-10%" width="110%" height="120%"><feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed="3" result="g"/><feColorMatrix in="g" type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 -0.9 1.5" result="gm"/><feComposite in="SourceGraphic" in2="gm" operator="in"/></filter>' +
    '<linearGradient id="vxGr" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f1f1f1"/><stop offset="1" stop-color="#a9acb0"/></linearGradient>' +
    '<linearGradient id="vxRd" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e5362d"/><stop offset="1" stop-color="#8e1712"/></linearGradient></defs>' +
    '<g transform="translate(206 2)" fill="none" stroke="#c9cdd2" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round"><path d="M0 34 22 2 44 34"/><path d="M8 34 22 15l14 19"/><path d="M-6 36H50" stroke-width="1" opacity=".5"/></g>' +
    '<g filter="url(#vxCr)" font-family="Impact,\'Bahnschrift\',\'Oswald\',\'Arial Black\',sans-serif" font-weight="900" font-size="112" letter-spacing="2" text-anchor="start">' +
    '<text x="0" y="132" fill="url(#vxGr)" textLength="520" lengthAdjust="spacingAndGlyphs">V<tspan fill="url(#vxRd)">É</tspan>RTICE</text></g>' +
    cracks() + '<path d="M2 142H518" stroke="#d6342b" stroke-width="2" stroke-dasharray="46 4 22 4 90 4 30 4 120 4 40 4"/></svg>';

  function cracks() {
    var sd = 5, o = '<g stroke="#08090b" stroke-width="1.6" fill="none" stroke-linecap="round" stroke-linejoin="round">';
    var r = function () { sd = (sd * 16807) % 2147483647; return sd / 2147483647; };
    for (var i = 0; i < 16; i++) { var x = 12 + r() * 496, y = 44 + r() * 70, d = 'M' + x.toFixed(0) + ' ' + y.toFixed(0); for (var k = 0; k < 4; k++) { x += (r() - 0.5) * 22; y += 6 + r() * 14; d += 'L' + x.toFixed(0) + ' ' + y.toFixed(0); } o += '<path d="' + d + '"/>'; }
    return o + '</g>';
  }
  var L = el('div', 'vxL'); menu.appendChild(L);
  L.appendChild(logo);
  var panels = {};
  function mkPanel(name) { var p = el('div', 'vxList'); p.style.display = 'none'; panels[name] = p; L.appendChild(p); return p; }
  function show(name) {
    if (name === 'char') { openChar(); return; }
    Object.keys(panels).forEach(function (k) { panels[k].style.display = k === name ? 'flex' : 'none'; });
    L.style.display = ''; $('vxChar').classList.remove('on');
    status.style.display = name === 'main' ? '' : 'none';
    if (name === 'config') syncConfig();
    if (name === 'mp') syncMP();
    cur = name; L.classList.toggle('sub', name !== 'main');
  }
  var cur = 'main';
  var back = function (to) { var b = btn('back', 'Volver', { on: function () { show(to || 'main'); } }); b.classList.add('vxBack'); return b; };

  // ---- principal
  var main = mkPanel('main');
  var bCont = btn('home', 'Continuar', { ui: 'continue-vx' });
  bCont.removeAttribute('data-ui');
  var origCont = orig.querySelector('[data-ui="continue"]');
  bCont.addEventListener('click', function () { if (origCont && !bCont.classList.contains('dis')) origCont.click(); });
  var bNew = btn('tools', 'Nueva partida', { on: function () { show('new'); } });
  var bMp = btn('people', 'Multijugador', { on: function () { show('mp'); } });
  var bCh = btn('helmet', 'Selección de personaje', { on: function () { show('char'); } });
  var bCf = btn('gear', 'Configuración', { on: function () { show('config'); } });
  var bCr = btn('book', 'Créditos', { on: function () { show('credits'); } });
  var bEx = btn('door', 'Salir', { red: true, on: function () { show('exit'); } });
  [bCont, bNew, bMp, bCh, bCf, bCr, bEx].forEach(function (b) { main.appendChild(b); });
  function syncCont() { var has = origCont && !origCont.classList.contains('hide'); bCont.classList.toggle('dis', !has); }
  if (origCont) new MutationObserver(syncCont).observe(origCont, { attributes: true, attributeFilter: ['class'] });
  syncCont();

  // estado
  var status = el('div', 'vxStatus');
  status.innerHTML = '<div><i></i>Conexión:<b class="off" id="vxConn">Offline</b></div><div><i></i>Modo:<b class="md" id="vxMode">' + (STORY ? 'Historia' : 'Supervivencia') + '</b><u></u></div>';
  menu.appendChild(status);
  var ver = $('ver'); var verBox = el('div', 'vxVer'); menu.appendChild(verBox);
  function setVer() { verBox.textContent = ver ? ver.textContent : ''; }
  setVer(); if (ver) new MutationObserver(setVer).observe(ver, { childList: true, characterData: true, subtree: true });
  function syncConn() {
    var c = $('vxConn'); if (!c) return;
    var mp = window.VERTICE_MP, on = false, txt = 'Offline';
    try { if (mp && mp.nx) { on = true; txt = 'Online · ' + (mp.role() === 'host' ? 'anfitrión' : 'invitado'); } else if (window.NexusPlay && window.NexusPlay.isEmbedded()) { txt = 'Sala · conectando'; } } catch (e) { /* sin sala */ }
    c.textContent = txt; c.className = on ? 'on' : (txt === 'Offline' ? 'off' : 'md');
  }
  setInterval(syncConn, 1200); syncConn();

  // ---- nueva partida (modo actual y el otro modo)
  var pNew = mkPanel('new');
  pNew.appendChild(el('div', 'vxH', 'Nueva partida'));
  var tNew = btn(STORY ? 'tower' : 'tree', STORY ? 'Modo historia' : 'Modo libre', { tall: true, sub: STORY ? 'Torre Mirador · 20 pisos · cooperativo en sala' : 'Mapa abierto · supervivencia · cooperativo', ui: 'new' });
  var tOther = btn(STORY ? 'tree' : 'tower', STORY ? 'Modo libre' : 'Modo historia', { tall: true, href: linkOther ? linkOther.getAttribute('href') : '#', sub: STORY ? 'Mapa abierto · supervivencia · cooperativo' : 'Torre Mirador · 20 pisos · capítulo I' });
  pNew.appendChild(el('div', 'vxP', 'Elige cómo quieres jugar. La dificultad se cambia en Configuración.'));
  pNew.appendChild(tNew); pNew.appendChild(tOther); pNew.appendChild(back());

  // ---- multijugador
  var pMp = mkPanel('mp');
  pMp.appendChild(el('div', 'vxH', 'Multijugador'));
  var mpTxt = el('div', 'vxP'); pMp.appendChild(mpTxt);
  var mpBox = el('div', 'vxBox'); pMp.appendChild(mpBox);
  var mpSkin = el('div', 'vxSkin'); pMp.appendChild(mpSkin);
  pMp.appendChild(back());
  function syncMP() {
    var mp = window.VERTICE_MP, emb = false;
    try { emb = !!(window.NexusPlay && window.NexusPlay.isEmbedded()); } catch (e) { /* nada */ }
    if (mp && mp.nx) {
      var pl = (mp.nx.players || []).map(function (p) { return (p.online ? '● ' : '○ ') + p.name + (p.host ? ' ★' : ''); });
      mpTxt.textContent = 'Sala conectada. ' + (mp.role() === 'host' ? 'Eres el anfitrión: los infectados y tus aliados corren en tu dispositivo.' : 'Te conectas al mundo del anfitrión.') + ' Pulsa Nueva partida para jugar juntos.';
      mpBox.innerHTML = '<h4>Jugadores</h4><div class="vxP" style="margin:2px 0">' + (pl.join('<br>') || '—') + '</div>';
    } else {
      mpTxt.textContent = emb ? 'Conectando con la sala de NEXUS PLAY…' : 'El multijugador funciona desde una sala de NEXUS PLAY: abre el juego desde la sala y tus amigos entran contigo, sin configurar nada. Fuera de una sala juegas solo (offline).';
      mpBox.innerHTML = '<h4>Estado</h4><div class="vxP" style="margin:2px 0">' + (emb ? 'Esperando la conexión de la sala…' : 'Sin sala · modo individual') + '</div>';
    }
  }

  // ---- configuración (reubica los controles que ya existen; los de pausa se enlazan)
  var pCf = mkPanel('config');
  pCf.appendChild(el('div', 'vxH', 'Configuración'));
  var scr = el('div', 'vxScroll'); pCf.appendChild(scr);
  var origRows = [].slice.call(orig.querySelectorAll('.row')).filter(function (r) { return r.querySelector('#sWxM,#sModeM'); });
  origRows.forEach(function (r) { r.className = 'vxRow'; scr.appendChild(r); });
  var proxies = [];
  function proxyRow(label, pauseId) {
    var src = $(pauseId); if (!src) return;
    var row = el('div', 'vxRow'); row.appendChild(el('label', null, label));
    var c = src.cloneNode(true); c.removeAttribute('id'); c.removeAttribute('data-ui');
    if (src.tagName === 'SELECT') c.value = src.value;
    row.appendChild(c); scr.appendChild(row);
    var push = function () { src.value = c.value; src.dispatchEvent(new Event('input', { bubbles: true })); src.dispatchEvent(new Event('change', { bubbles: true })); };
    c.addEventListener('input', push); c.addEventListener('change', push);
    proxies.push(function () { c.value = src.value; });
  }
  proxyRow('Sensibilidad', 'sSens'); proxyRow('Volumen', 'sVol'); proxyRow('Campo de visión', 'sFov'); proxyRow('Cámara', 'sView'); proxyRow('Calidad gráfica', 'sQual');
  var keysBox = el('div', 'vxBox'); keysBox.appendChild(el('h4', null, 'Controles'));
  var keys = orig.querySelector('.keys'); if (keys) { keys.className = 'vxKeys'; keysBox.appendChild(keys); }
  scr.appendChild(keysBox);
  pCf.appendChild(back());
  function syncConfig() { proxies.forEach(function (f) { f(); }); }

  // ---- créditos
  var pCr = mkPanel('credits');
  pCr.appendChild(el('div', 'vxH', 'Créditos'));
  var crs = el('div', 'vxScroll'); pCr.appendChild(crs);
  crs.innerHTML = '<div class="vxBox"><h4>Vértice</h4><div class="vxP" style="margin:2px 0">Juego de supervivencia zombi en primera y tercera persona, para PC y Android.</div></div>' +
    '<div class="vxBox"><h4>Diseño y dirección</h4><div class="vxP" style="margin:2px 0">Will</div></div>' +
    '<div class="vxBox"><h4>Personajes</h4><div class="vxP" style="margin:2px 0">Vértice · Lena Álvarez · Alejandro<br>Imbachi · Valentina · Wilmarys</div></div>' +
    '<div class="vxBox"><h4>Tecnología</h4><div class="vxP" style="margin:2px 0">Three.js · WebAssembly · Web Audio · NEXUS PLAY (cooperativo en sala)</div></div>';
  pCr.appendChild(back());

  // ---- salir
  var pEx = mkPanel('exit');
  pEx.appendChild(el('div', 'vxH', 'Salir'));
  var exTxt = el('div', 'vxP', '¿Quieres cerrar el juego? Tu partida guardada se conserva.'); pEx.appendChild(exTxt);
  pEx.appendChild(btn('door', 'Sí, salir', { red: true, on: function () {
    try { window.close(); } catch (e) { /* nada */ }
    setTimeout(function () { exTxt.textContent = 'Este navegador no deja cerrar la pestaña desde el juego. Puedes cerrarla tú: tu partida está guardada.'; }, 350);
  } }));
  pEx.appendChild(back());

  // ------------------------------------------------------------------ selección de personaje
  var ch = el('div'); ch.id = 'vxChar';
  var chBg = el('canvas'); ch.appendChild(chBg);
  ch.appendChild(el('div', 'vxCT', 'VÉRTICE'));
  var cards = el('div', 'vxCards'); ch.appendChild(cards);
  var bar = el('div', 'vxCBar'); ch.appendChild(bar);
  var nameBox = el('label', 'vxName', 'Nombre <input type="text" maxlength="20" autocomplete="off" spellcheck="false">'); bar.appendChild(nameBox);
  var nameIn = nameBox.querySelector('input');
  var skinHost = el('div', 'vxSkin'); bar.appendChild(skinHost);
  bar.appendChild(btn('ok', 'Confirmar', { red: true, on: function () { show('main'); } }));
  menu.appendChild(ch);

  var pickM = $('pickM');
  var hiddenHolder = el('div'); hiddenHolder.style.cssText = 'position:absolute;width:0;height:0;overflow:hidden;visibility:hidden'; menu.appendChild(hiddenHolder);
  if (pickM) hiddenHolder.appendChild(pickM);
  var WT = { vertice: 72, lena: 58, alejandro: 70, imbachi: 70, valentina: 54, wilmarys: 56 };
  var AT = { vertice: ['Velocidad', 'Alta'], lena: ['Resistencia', 'Alta'], alejandro: ['Fuerza', 'Alta'], imbachi: ['Puntería', 'Alta'], valentina: ['Velocidad', 'Muy alta'], wilmarys: ['Curación', 'Alta'] };
  function buildCards() {
    if (!pickM) return;
    var btns = [].slice.call(pickM.querySelectorAll('.chc'));
    if (!btns.length) return;
    cards.innerHTML = '';
    btns.forEach(function (b) {
      var id = b.dataset.char, CH = (G.CH && G.CH[id]) || {};
      var small = b.querySelector('small'), role = CH.role || (small ? small.firstChild.textContent : '');
      var info = CH.info || (small ? small.textContent : '');
      var h = CH.h ? CH.h.toFixed(2).replace('.', ',') : ((info.match(/(\d[,.]\d\d)\s*m/) || [0, '—'])[1]);
      var kg = (info.match(/(\d+)\s*kg/) || [0, WT[id] || '—'])[1];
      var at = AT[id] || ['Aguante', 'Media'];
      var dots = [].slice.call(b.querySelectorAll('i')).slice(0, 3).map(function (i) { return '<i style="background:' + i.style.background + '"></i>'; }).join('');
      var c = el('button', 'vxCard'); c.type = 'button'; c.dataset.char = id;
      c.innerHTML = '<h3>' + b.querySelector('b').textContent + '</h3><div class="rl">' + role + '</div><hr><div class="st">Altura <b>' + h + ' m</b></div><div class="st">Peso <b>' + kg + ' kg</b></div><div class="ft"><div class="at">' + at[0] + '<b>' + at[1] + '</b></div><div class="dots">' + dots + '</div></div>';
      c.addEventListener('click', function () { b.click(); markCards(); });
      cards.appendChild(c);
    });
    markCards();
  }
  function markCards() {
    var on = pickM && pickM.querySelector('.chc.on');
    [].forEach.call(cards.children, function (c) { c.classList.toggle('on', !!on && c.dataset.char === on.dataset.char); });
    var pin = pickM && pickM.querySelector('.pname');
    if (pin && document.activeElement !== nameIn) nameIn.value = pin.value;
  }
  nameIn.addEventListener('keydown', function (e) { e.stopPropagation(); if (e.key === 'Enter') nameIn.blur(); });
  nameIn.addEventListener('input', function () { var pin = pickM && pickM.querySelector('.pname'); if (pin) { pin.value = nameIn.value; pin.dispatchEvent(new Event('input', { bubbles: true })); } });
  if (pickM) new MutationObserver(function () { if (!cards.children.length) buildCards(); else markCards(); }).observe(pickM, { attributes: true, subtree: true, attributeFilter: ['class'], childList: true });
  function openChar() {
    buildCards(); markCards();
    var sk = pickM && pickM.querySelector('.mpskin');
    if (sk) skinHost.appendChild(sk);
    L.style.display = 'none'; ch.classList.add('on'); cur = 'char'; paintCharBg();
  }
  // el selector de color de ropa del multijugador se crea tarde: engancharlo cuando aparezca
  setInterval(function () { var sk = pickM && pickM.querySelector('.mpskin'); if (sk) { (cur === 'mp' ? mpSkin : skinHost).appendChild(sk); } }, 1500);
  var oMpShow = syncMP;
  syncMP = function () { oMpShow(); var sk = document.querySelector('.mpskin'); if (sk && sk.parentNode !== mpSkin) mpSkin.appendChild(sk); };

  // ------------------------------------------------------------------ fondo: ciudad en ruinas
  var seedv = 7; function rnd() { seedv = (seedv * 16807) % 2147483647; return seedv / 2147483647; }
  var stat = null, lights = [], puffs = [], embers = [], W = 0, H = 0;
  function paintScene() {
    var dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    W = bg.width = Math.max(320, Math.floor(window.innerWidth * dpr * 0.75)); H = bg.height = Math.max(200, Math.floor(window.innerHeight * dpr * 0.75));
    seedv = 7; lights = []; puffs = []; embers = [];
    stat = document.createElement('canvas'); stat.width = W; stat.height = H; var g = stat.getContext('2d');
    var hz = H * 0.66;
    // cielo
    var sky = g.createLinearGradient(0, 0, 0, hz); sky.addColorStop(0, '#0b0c0f'); sky.addColorStop(0.55, '#26282d'); sky.addColorStop(0.85, '#5a4a42'); sky.addColorStop(1, '#8a6a52');
    g.fillStyle = sky; g.fillRect(0, 0, W, H);
    var gl = g.createRadialGradient(W * 0.78, hz * 0.95, 0, W * 0.78, hz * 0.95, W * 0.34); gl.addColorStop(0, 'rgba(255,170,90,.55)'); gl.addColorStop(1, 'rgba(255,170,90,0)'); g.fillStyle = gl; g.fillRect(0, 0, W, H);
    var i, k;
    for (i = 0; i < 26; i++) { var cx = rnd() * W, cy = rnd() * hz * 0.8, cr = W * (0.06 + rnd() * 0.14); var cg = g.createRadialGradient(cx, cy, 0, cx, cy, cr); cg.addColorStop(0, 'rgba(20,21,24,' + (0.18 + rnd() * 0.3) + ')'); cg.addColorStop(1, 'rgba(20,21,24,0)'); g.fillStyle = cg; g.fillRect(cx - cr, cy - cr, cr * 2, cr * 2); }
    // rascacielos lejanos
    function tower(x, w, h, col, light) {
      g.fillStyle = col; g.fillRect(x, hz - h, w, h + 4);
      g.fillRect(x + w * 0.1, hz - h - h * 0.08, w * 0.8, h * 0.08);
      if (light) { g.fillRect(x + w * 0.46, hz - h - h * 0.2, w * 0.08, h * 0.12); lights.push([x + w * 0.5, hz - h - h * 0.2, rnd() * 6]); }
      g.fillStyle = 'rgba(255,255,255,.035)'; for (var wy = hz - h + 6; wy < hz - 4; wy += 7) for (var wx = x + 3; wx < x + w - 3; wx += 6) if (rnd() > 0.55) g.fillRect(wx, wy, 2, 3);
    }
    var cols = ['#1a1c20', '#16181b', '#1f2125'];
    for (i = 0; i < 18; i++) tower(W * (0.34 + rnd() * 0.5), W * (0.018 + rnd() * 0.03), H * (0.08 + rnd() * 0.16), cols[i % 3], false);
    tower(W * 0.43, W * 0.045, H * 0.34, '#111316', true); tower(W * 0.585, W * 0.05, H * 0.3, '#111316', true); tower(W * 0.73, W * 0.05, H * 0.36, '#0f1114', true);
    var hazeG = g.createLinearGradient(0, hz * 0.55, 0, hz); hazeG.addColorStop(0, 'rgba(120,100,90,0)'); hazeG.addColorStop(1, 'rgba(130,105,88,.35)'); g.fillStyle = hazeG; g.fillRect(0, hz * 0.55, W, hz * 0.45);
    // ruinas medias
    g.fillStyle = '#0d0e10';
    for (i = 0; i < 40; i++) { var rx = W * (0.3 + rnd() * 0.55), rw = W * (0.01 + rnd() * 0.035), rh = H * (0.03 + rnd() * 0.11); g.beginPath(); g.moveTo(rx, hz + 6); g.lineTo(rx, hz - rh); g.lineTo(rx + rw * 0.3, hz - rh * (0.6 + rnd() * 0.5)); g.lineTo(rx + rw * 0.7, hz - rh * (0.8 + rnd() * 0.4)); g.lineTo(rx + rw, hz - rh * 0.4); g.lineTo(rx + rw, hz + 6); g.fill(); }
    // suelo
    var gr = g.createLinearGradient(0, hz, 0, H); gr.addColorStop(0, '#16171a'); gr.addColorStop(0.4, '#0f1012'); gr.addColorStop(1, '#050506'); g.fillStyle = gr; g.fillRect(0, hz, W, H - hz);
    // charcos (reflejan el cielo)
    for (i = 0; i < 9; i++) { var px = W * (0.3 + rnd() * 0.5), py = hz + (H - hz) * (0.15 + rnd() * 0.7), pw = W * (0.05 + rnd() * 0.12); var pg = g.createLinearGradient(0, py - 6, 0, py + 6); pg.addColorStop(0, 'rgba(110,100,95,.38)'); pg.addColorStop(1, 'rgba(40,40,44,.2)'); g.fillStyle = pg; g.beginPath(); g.ellipse(px, py, pw, pw * 0.07, 0, 0, 6.3); g.fill(); }
    // coche calcinado
    var cx0 = W * 0.6, cy0 = hz + (H - hz) * 0.2, cw = W * 0.16, chh = cw * 0.3;
    g.fillStyle = '#08090a'; g.beginPath(); g.moveTo(cx0, cy0); g.lineTo(cx0 + cw * 0.05, cy0 - chh * 0.5); g.lineTo(cx0 + cw * 0.27, cy0 - chh * 0.62); g.lineTo(cx0 + cw * 0.4, cy0 - chh * 1.05); g.lineTo(cx0 + cw * 0.7, cy0 - chh * 1.05); g.lineTo(cx0 + cw * 0.83, cy0 - chh * 0.58); g.lineTo(cx0 + cw, cy0 - chh * 0.45); g.lineTo(cx0 + cw, cy0); g.closePath(); g.fill();
    g.fillStyle = 'rgba(120,125,135,.2)'; g.beginPath(); g.moveTo(cx0 + cw * 0.3, cy0 - chh * 0.62); g.lineTo(cx0 + cw * 0.42, cy0 - chh * 0.97); g.lineTo(cx0 + cw * 0.66, cy0 - chh * 0.97); g.lineTo(cx0 + cw * 0.77, cy0 - chh * 0.62); g.closePath(); g.fill();
    g.fillStyle = '#030303'; [0.2, 0.78].forEach(function (f) { g.beginPath(); g.arc(cx0 + cw * f, cy0, chh * 0.34, 0, 6.3); g.fill(); });
    // edificio en ruinas (primer plano derecho)
    var bx = W * 0.8; g.fillStyle = '#07080a'; g.beginPath(); g.moveTo(bx + W * 0.03, H * 0.9); g.lineTo(bx, H * 0.2); g.lineTo(bx + W * 0.02, 0); g.lineTo(W, 0); g.lineTo(W, H * 0.9); g.closePath(); g.fill();
    g.fillStyle = '#0d0f12'; for (var fy = H * 0.04; fy < H * 0.8; fy += H * 0.075) for (var fx = bx + W * 0.025; fx < W - 6; fx += W * 0.036) { if (rnd() < 0.18) continue; g.fillRect(fx, fy, W * 0.022, H * 0.048); }
    g.fillStyle = '#181b20'; for (fy = H * 0.04; fy < H * 0.8; fy += H * 0.075) g.fillRect(bx + W * 0.02, fy - 2, W * 0.2, 2);
    g.strokeStyle = '#08090b'; g.lineWidth = 1.2; for (i = 0; i < 26; i++) { var sx = bx + rnd() * W * 0.2, sy = rnd() * H * 0.5; g.beginPath(); g.moveTo(sx, sy); g.lineTo(sx + (rnd() - 0.5) * 30, sy + 20 + rnd() * 70); g.stroke(); }
    // escombros
    for (i = 0; i < 90; i++) { var ex = W * (0.34 + rnd() * 0.66), ey = hz + (H - hz) * (0.5 + rnd() * 0.5), es = 3 + rnd() * W * 0.015; var gv = 6 + (rnd() * 16 | 0); g.fillStyle = 'rgb(' + gv + ',' + (gv + 1) + ',' + (gv + 2) + ')'; g.beginPath(); g.moveTo(ex, ey); g.lineTo(ex + es, ey - es * 0.6); g.lineTo(ex + es * 1.6, ey + es * 0.1); g.lineTo(ex + es * 0.6, ey + es * 0.6); g.fill(); }
    // viñeta
    var vg = g.createRadialGradient(W * 0.6, H * 0.5, H * 0.3, W * 0.6, H * 0.5, W * 0.75); vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,.65)'); g.fillStyle = vg; g.fillRect(0, 0, W, H);
    for (k = 0; k < 16; k++) puffs.push({ t: rnd(), s: 0.6 + rnd() * 0.8, o: (rnd() - 0.5) * 0.04 });
    for (k = 0; k < 70; k++) embers.push({ x: rnd() * W, y: rnd() * H, v: 4 + rnd() * 10, a: 0.1 + rnd() * 0.35, r: 0.6 + rnd() * 1.2 });
  }
  var lastT = 0;
  function frame(t) {
    requestAnimationFrame(frame);
    if (menu.classList.contains('hide')) return;
    if (t - lastT < 45) return;
    var dt = Math.min(0.1, (t - lastT) / 1000); lastT = t;
    if (!stat || Math.abs(W - Math.floor(window.innerWidth * Math.min(window.devicePixelRatio || 1, 1.5) * 0.75)) > 40) paintScene();
    var g = bg.getContext('2d');
    g.drawImage(stat, 0, 0);
    var sx = W * 0.8, sy = H * 0.52, i;
    for (i = 0; i < puffs.length; i++) {
      var p = puffs[i]; p.t += dt * 0.045; if (p.t > 1) p.t -= 1;
      var u = p.t, r = (W * 0.025 + u * W * 0.14) * p.s, x = sx + u * W * 0.1 + p.o * W * u * 3, y = sy - u * H * 0.5, a = (1 - u) * Math.min(1, u * 6) * 0.42;
      var gg = g.createRadialGradient(x, y, 0, x, y, r); gg.addColorStop(0, 'rgba(24,24,27,' + a + ')'); gg.addColorStop(1, 'rgba(24,24,27,0)'); g.fillStyle = gg; g.fillRect(x - r, y - r, r * 2, r * 2);
    }
    for (i = 0; i < lights.length; i++) { var L2 = lights[i], on = Math.sin(t / 700 + L2[2]) > -0.2; g.fillStyle = on ? 'rgba(255,40,30,.95)' : 'rgba(110,20,18,.5)'; g.fillRect(L2[0] - 1, L2[1] - 1, 3, 3); if (on) { var lg = g.createRadialGradient(L2[0], L2[1], 0, L2[0], L2[1], 14); lg.addColorStop(0, 'rgba(255,50,40,.35)'); lg.addColorStop(1, 'rgba(255,50,40,0)'); g.fillStyle = lg; g.fillRect(L2[0] - 14, L2[1] - 14, 28, 28); } }
    g.fillStyle = '#c9c3bd';
    for (i = 0; i < embers.length; i++) { var e = embers[i]; e.y -= e.v * dt; e.x += Math.sin(t / 1300 + i) * 4 * dt + 3 * dt; if (e.y < -4) { e.y = H + 4; e.x = Math.random() * W; } g.globalAlpha = e.a; g.fillRect(e.x, e.y, e.r, e.r); }
    g.globalAlpha = 1;
  }
  requestAnimationFrame(frame);

  // fondo suave de la pantalla de personajes (siluetas de torres)
  function paintCharBg() {
    var w = chBg.width = Math.floor(window.innerWidth * 0.5), h = chBg.height = Math.floor(window.innerHeight * 0.5), g = chBg.getContext('2d');
    g.clearRect(0, 0, w, h); var s = 11, i; function r2() { s = (s * 16807) % 2147483647; return s / 2147483647; }
    g.fillStyle = '#1b1d21';
    for (i = 0; i < 26; i++) { var x = r2() * w, bw = w * (0.025 + r2() * 0.04), bh = h * (0.12 + r2() * 0.4); g.fillRect(x, h - bh, bw, bh); g.fillRect(x + bw * 0.4, h - bh - 8, bw * 0.2, 8); }
    var f = g.createLinearGradient(0, 0, 0, h); f.addColorStop(0, 'rgba(8,9,11,1)'); f.addColorStop(0.6, 'rgba(8,9,11,0)'); g.fillStyle = f; g.fillRect(0, 0, w, h);
  }

  window.addEventListener('resize', function () { if (!menu.classList.contains('hide')) { stat = null; if (ch.classList.contains('on')) paintCharBg(); } });
  window.VERTICE_MENU = { show: show };
  show('main');
})();
