# VÉRTICE · Modo libre cooperativo + Modo historia (Torre Mirador) · v2.7

Sube este ZIP a NEXUS PLAY (Subir juego → ZIP). Hay dos páginas:
- **index.html** — el modo libre cooperativo de siempre (mapa abierto). En su menú hay un botón **📖 Modo historia**.
- **historia.html** — el modo historia: Torre Mirador de 20 pisos, prólogo en el piso 17, misiones, final con la moto. Su menú tiene el botón **🌲 Modo libre** para volver.

El multijugador (vertice-mp.js + nexus-sdk.js) está en las dos páginas. En el modo historia funciona igual que en el libre:
avatares con skin y color, infectados compartidos (los simula el anfitrión, también en los pisos), disparos y ruido, hora del día.
Los infectados eligen al jugador más cercano contando el desnivel (un piso de diferencia pesa como ~10 m).

## Límites
- La historia (misiones, notas, construcciones), puertas, botín y coches NO se sincronizan: cada jugador avanza la suya.
- Al cambiar de página (libre ↔ historia) la sala se reconecta; cada jugador debe cambiar de modo en su dispositivo.
- Sin guardado dentro de NEXUS PLAY (el aislamiento bloquea localStorage).

## Estado de pruebas
Probado con un cliente simulado de NEXUS PLAY (anfitrión e invitado) en Chromium: el invitado ve infectados y avatares en el piso correcto,
el anfitrión envía instantáneas y envuelve a los infectados. NO probado en una sala real de NEXUS PLAY, ni con celulares, ni con más de 2 jugadores.

## Novedades v1.5 (modo libre)
- La zanja sin fondo del centro del asentamiento ahora es un **pequeño río** (0,4 m de profundidad): se vadea, hay agua animada y dos puentes bajos.
- **Campo de pruebas** rehecho (oeste): bloques de salto, parkour, túneles de agacharse y arrastre, escalera, muros, charco, tres colinas (11°/22°/33°), trampolín y slalom, con carteles (E). Pickup, moto y bici junto al puente sur.
- **Vehículos**: siguen el relieve (cabeceo y balanceo), suben montañas y cuestas (límite por tipo de vehículo), saltan en crestas y trampolines, vadean agua baja y salen por las puertas a la selva. Los ríos hondos y los riscos los frenan.
- El modo historia (historia.html) no cambia.

## Novedades v1.6 (sonido, en los dos modos)
- Quitado el **pitido de la noche** (los "grillos" de 4300 Hz que subían al oscurecer).
- **Voces de infectados nuevas**, generadas en el propio juego (sin archivos): caminante (lamento gutural o gorgoteo húmedo), corredor (alarido rasgado), arrastrado (jadeo), gordo (gorgoteo grave), gorda ácida (siseo + gorgoteo), gigante (rugido), llamada de horda.
- Nuevos sonidos: gruñido al preparar el golpe, quejido al recibir daño y estertor al morir.
- Máximo 6 voces de infectados a la vez para no saturar el celular.

## Novedades v1.7 (gritos reales de zombi)
- Nuevo archivo **zombi-audio.js** (8 gritos recortados del video que aportó Will). Va junto a index.html e historia.html; ya está enlazado en las dos páginas.
- Cada infectado usa esos gritos con otra velocidad/tono: corredor agudo, caminante grave y largo, arrastrado más corto, gordos muy graves, gigante como bramido, horda con varias voces lejanas; también en gruñido de ataque, quejido al recibir daño y grito de muerte que cae de tono.
- Si zombi-audio.js falta, el juego usa las voces procedurales de v1.6.


## Cambio (v2.6b): diálogos de NPC desactivados
- Los supervivientes ya no dicen frases al reclutarlos ni al levantarlos (solo avisos cortos). Para volver a activarlos: en `supervivientes.js` cambia `var DIALOGOS = false;` por `true`.

## Novedades v2.7 (agua: nado, ríos hondos, peces, ahogados y cofres) — solo modo libre
- Nuevo `agua.js` (cargado en index.html). `historia.html` no cambia.
- **Ríos más anchos y hondos:** Río Mayor ~21 m de ancho y 6 m de fondo, Río del Oeste ~18 m y 5,8 m, Arroyo del Norte ~13 m y 4,4 m. Puedes bajar hasta el fondo (agacharse = bucear, saltar = subir). El Río Mayor se corrió un poco al este para no inundar el Campamento del río.
- **Nado animado:** crol al avanzar (brazada alterna, patada, torso que rola, cabeza que gira a respirar), nado más lento y tendido bajo el agua, y patada de bicicleta con brazos que reman al flotar. En primera persona se ven tus brazos, la cámara rola con cada brazada y salen ondas en el agua. En cooperativo los demás te ven nadar así (vertice-mp.js).
- **Peces:** 26 bancos (~160 peces, plateados, naranjas, azules, verdes) y bagres grandes; huyen si te acercas y a veces saltan.
- **Ahogados:** zombis acuáticos, los únicos que nadan (17 guaridas en Normal; menos en Fácil, más en Difícil... según población). Esperan de pie en el fondo, te sienten al nadar (más si te mueves), suben hasta tu profundidad y muerden (17 de daño). No salen del agua; si sales y te alejas, te sueltan. Mueren con balas o golpes; reaparecen a los ~5 min si estás lejos.
- **Nadando solo se pelea cuerpo a cuerpo** (machete, bate, hacha); las armas de fuego no se pueden usar dentro del agua.
- **Cofres del fondo:** 26 (`cofre_rio_0…25`) donde el río supera 3 m, con destello dorado y burbujas; botín mejor (munición, botiquines, granadas) y ~30 % con un arma. Algunos los vigila un ahogado.
- Peces y ahogados no se sincronizan en cooperativo (cada jugador simula los suyos, como los animales). Los cofres sí son los mismos.
- Pruebas: en consola `VERT_AGUA.tpChest(0)` te lleva a un cofre; `VERT_AGUA.spawn(x,z)` crea un ahogado.

## Novedades v2.6 (celular y mapa)
- Nuevo `celular.js` (cargado en las dos páginas, después de melee-anim.js). **P** o el botón 📱 abre el celular; **M** abre el mapa; **Esc** cierra.
- **Batería propia del celular:** 100 % en el modo historia y 30 % en el modo libre. Se gasta sola (más con la pantalla encendida, la linterna o la música; «Ahorro de energía» la gasta la mitad). Se recarga con una **Batería** de la mochila (Configuración, +45 %). Sin batería el celular se apaga. Se guarda con la partida.
- **Apps:** Mensajes, Contactos, Galería, Cámara, Mapa, Notas, Configuración, Videos, Navegador, **PH (al abrirla dice «Sin señal»)**, Linterna, Calculadora y Música.
- **Cámara → Galería:** saca fotos de lo que ves (Enter o el botón) y se guardan en la Galería (hasta 12, solo durante la sesión).
- **Mapa:** minimapa arriba a la derecha (gira contigo, N = norte, punto rojo = objetivo de la misión; si queda lejos, una flecha roja en el borde). La app Mapa muestra el mapa completo: zoom, arrastrar, ⌖ para centrar, nombres de zonas y edificios; en el modo historia, el plano de cada piso de la torre (▲▼). Se puede quitar el minimapa en Configuración.
- **Notas:** objetivo actual, notas que ya leíste y una nota propia.
- **Linterna y música:** la linterna del celular y la música por altavoz hacen ruido/luz que atrae a infectados cercanos; con auriculares la música no se oye afuera.
- Límites: Mensajes, Contactos, Videos, Navegador y PH son solo ambientación (sin red). Las fotos no se guardan al cerrar la partida. El minimapa no muestra infectados.
- Para quitarlo: borra la línea `<script src="celular.js">` de index.html y historia.html.

## Novedades v2.4 (combate cuerpo a cuerpo)
- Nuevo `melee-anim.js`: machete, bate y hacha con animación en 4 tiempos (preparación, golpe, continuación, recuperación) en primera y tercera persona.
- **Combos** si golpeas seguido: machete = tajo ↘ → revés ↗ → estocada; bate = desde arriba → horizontal; hacha = vertical → diagonal.
- Estela de corte en pantalla, sacudida y bajada de cámara al impactar (más fuerte con el hacha); en tercera persona el torso gira y las dos manos sujetan bate y hacha.
- Daño, alcance y momento del impacto iguales; solo el bate pasa de windup 0,12 a 0,15 s y de espera 0,42 a 0,46 s para que se vea la preparación.

## Novedades v2.3 (animales)
- Nuevo `animales.js` (cargado en las dos páginas): **perros, gatos, vacas, cerdos, ratas, ovejas, pájaros y conejos**.
- **Sanos** (todas las modalidades): deambulan, pastan y huyen de ti, de los disparos, de los coches y de los infectados. Los perros son curiosos (se acercan y ladran: el ladrido llama la atención de infectados cercanos).
- **Infectados** (solo modalidad **Difícil**): te ven, te oyen y muerden. Perros en manada, gatos y conejos que saltan encima, vaca que embiste, ratas en enjambre, pájaros que se lanzan en picado. Al pasar a otra modalidad desaparecen.
- Reciben balas, golpes, explosiones, fuego, aturdidoras y atropellos. Solo los infectados cuentan como bajas.
- Pausa → **Animales**: Muchos / Pocos / Sin animales (en móviles flojos usa «Pocos»).
- Límites: en cooperativo cada jugador ve sus propios animales (no se sincronizan); no se guardan con la partida; los sanos no dejan botín todavía; en el modo historia solo aparecen al nivel del suelo (fuera de la torre).

## Novedades v2.2 (menú nuevo)
- `menu-ui.js` (se carga al final de index.html y historia.html) rediseña el menú: Continuar · Nueva partida · Multijugador · Selección de personaje · Configuración · Créditos · Salir, con fondo de ciudad en ruinas dibujado por código y cuadro de estado (conexión / modo).
- Nueva partida deja elegir entre modo libre y modo historia. Configuración reúne dificultad, clima, sensibilidad, volumen, FOV, cámara, calidad y controles.
- Selección de personaje en tarjetas (altura, peso, atributo y colores); el nombre y el color de ropa del multijugador están en la misma pantalla.
- Las demás pantallas (pausa, inventario…) usan la misma estética. Para volver al menú anterior, borra la línea `<script src="menu-ui.js">`.

## Novedades v2.0 / v2.1 (supervivientes y personajes nuevos)
Dos archivos nuevos, enlazados ya en las dos páginas: **personajes.js** y **supervivientes.js** (van junto a index.html e historia.html).

**Personajes jugables** (selector de personaje del menú, junto a Vértice, Lena y Alejandro):
- **Imbachi** — 1,78 m, como el protagonista. Chaqueta de campo, franela atada a la cintura, cargo, mochila, cadena y pelo largo rizado.
- **Wilmarys** (v2.1) — 1,62 m. Pelo largo rizado con corona de flores blancas, top negro con mariposa, chaqueta oscura caída por los brazos, cinturón tachonado con cadena, cargo negro holgado, guantes sin dedos, botas gruesas y collar. Aliada **sanadora**: te venda cuando estás herido o sangrando.
- **Valentina** — 1,66 m. Top negro, short de jean holgado, botines negros, pulseras, cara redonda y pelo largo liso con flequillo.
Se ven igual en cooperativo (color de ropa incluido) y caminan, apuntan y se agachan con el mismo esqueleto que los demás.

**Supervivientes aliados** (Valentina, Wilmarys e Imbachi también viven en el mundo; el que juegas tú no aparece como aliado):
- Dónde están — historia: Valentina en el pasillo del piso 15, Wilmarys en el del piso 11 e Imbachi en el patio (noreste de la torre). Modo libre: Valentina en la casa, Wilmarys al este del asentamiento e Imbachi en la bodega del asentamiento.
- **E / «Usar»** sobre ellos: hablar y reclutar. Ya reclutados, E abre el panel de órdenes: seguir / quedarse, dar munición (hasta 12 de tu mochila), curar (venda o botiquín) y despedir.
- **Tecla N** o el botón **👥** (arriba a la derecha): todos los reclutados siguen / se quedan. Máximo 2 te siguen a la vez.
- Siguen por escaleras y puertas (las abren), se colocan a tu lado, y si se quedan muy atrás o atascados aparecen junto a ti.
- Combaten: disparan con pistola (con recarga y munición limitada) o golpean con machete; dan pasos atrás al tener un infectado encima; huyen del Gigante y cuando están muy heridos.
- Los infectados los atacan: eligen como objetivo al más cercano entre tú y ellos. Con 0 de vida **caen heridos** 40 s: acércate y levántalos con una venda (E). Si se agotan los 40 s mueren para siempre.
- Valentina corre un 18 % más rápido; Imbachi tiene más vida y mejor puntería.
- Se guardan con la partida (estado, vida, munición, si te siguen).

**Cooperativo:** el anfitrión simula a los supervivientes (igual que a los infectados) y los invitados ven una copia. Un invitado también puede reclutar, dar órdenes, dar munición y curar; el superviviente sigue a quien lo reclutó.

**Límites conocidos**
- Probado con un cliente simulado de NEXUS PLAY (anfitrión + invitado) en Chromium y con partidas individuales en los dos modos; NO probado en una sala real, ni en celulares, ni con más de 2 jugadores.
- No conducen ni suben a coches; si te vas en coche, te alcanzan al bajarte.
- Los supervivientes no hablan por voz (solo texto).
- Imbachi, Valentina y Wilmarys no tienen aún cinemáticas de historia propias.
